#!/usr/bin/env python3
"""Build a standalone private Elan and Ruby/Licensee runtime for the pinned verifier."""
from __future__ import annotations
import argparse
import json
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import sys
import time
from release_tree import file_hash, tree_digest

HERE = Path(__file__).resolve().parent
MANIFEST = HERE / 'tool-inputs.json'
MANIFEST_SHA256 = 'f49f32163d37fec27c548643e00a6d82ad53a08bd5484b0d2e12a4b2d07ea9ec'
require_auth = lambda path, digest: file_hash(path) == digest

def run(args, *, cwd=None, env=None):
    return subprocess.run([str(x) for x in args], cwd=cwd, env=env, check=True,
                          text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT).stdout.strip()

def expect(condition, reason):
    if not condition:
        raise RuntimeError(reason)

def shellvar(x):
    return shlex.quote(str(x))

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--prefix', required=True, type=Path, help='fresh directory exclusively owned by this installation')
    parser.add_argument('--pipeline', required=True, type=Path, help='official PalomarSubmission Git checkout')
    parser.add_argument('--lean-root', type=Path, help='previously extracted public Linux 4.35 tree; otherwise use genuine elan install')
    parser.add_argument('--cache', type=Path, help='optional directory of immutable input filenames; missing inputs use stock trusted_download')
    args = parser.parse_args()
    before = time.time()
    expect(require_auth(MANIFEST, MANIFEST_SHA256), 'input lockfile hash mismatch')
    inputs = json.loads(MANIFEST.read_text())
    pipeline, prefix = args.pipeline.resolve(strict=True), args.prefix.resolve()
    expect(run(['git', '-c', 'safe.directory='+str(pipeline), '-C', pipeline, 'rev-parse', 'HEAD']) == inputs['workflow_commit'], 'wrong pipeline revision')
    for f, h in inputs['policy_file_sha256'].items():
        expect(require_auth(pipeline / f, h), 'modified stock input: '+f)
    expect(not prefix.exists() or (prefix.is_dir() and not any(prefix.iterdir())), 'choose an unused private prefix')
    prefix.mkdir(parents=True, exist_ok=True)
    for tool in ['git','tar','zstd','gcc','make','curl']:
        expect(shutil.which(tool), 'missing build tool '+tool)
    for d in ['archives','bin','install-home','gem-bin','gems','bundle','bundle-user','bundle-config','lock/vendor/cache']:
        (prefix/d).mkdir(parents=True, exist_ok=True)
    os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(pipeline))
    from scripts.trusted_download import download
    candidate={}
    for name, info in inputs['archives'].items():
        path = (args.cache / name) if args.cache else prefix/'archives'/name
        if not path.is_file():
            path = prefix/'archives'/name
            download(info['url'], path, info['sha256'], max_bytes=info['size'])
        expect(path.stat().st_size==info['size'] and require_auth(path,info['sha256']), 'archive mismatch: '+name)
        candidate[name] = path.resolve()
    template=prefix/'lock'
    for file in ['Gemfile','Gemfile.lock']:shutil.copyfile(pipeline/file,template/file)
    env=dict(os.environ,HOME=str(prefix/'install-home'),ELAN_HOME=str(prefix/'elan'))
    env.pop('ELAN_TOOLCHAIN',None);env.pop('RUBYOPT',None)
    temp=prefix/'bootstrap';temp.mkdir()
    run(['tar','-xzf',candidate['elan-v4.2.3-linux.tar.gz'],'-C',temp,'elan-init'])
    run([temp/'elan-init','-y','--no-modify-path','--default-toolchain','none'],env=env)
    elan=prefix/'elan/bin/elan'
    selector=inputs['lean']['selector']
    test_project=prefix/'toolchain-selection';test_project.mkdir()
    (test_project/'lean-toolchain').write_text(selector+'\n')
    if args.lean_root:
        lean_root=args.lean_root.resolve(strict=True)
        expect(tree_digest(lean_root)==inputs['lean']['full_tree'], 'retained Lean release tree differs from authenticated upstream archive')
        run([elan,'toolchain','link',selector,lean_root], cwd=test_project, env=env)
        lean_mode='Elan canonical-name registration of complete archive-matched release'
    else:
        run([elan,'toolchain','install',selector],cwd=test_project,env=env)
        lean_root=Path(run([prefix/'elan/bin/lean','--print-prefix'],cwd=test_project,env=env)).resolve()
        expect(tree_digest(lean_root)==inputs['lean']['full_tree'],'cold-install release tree differs from authenticated upstream archive')
        lean_mode='stock Elan toolchain install'
    expect(Path(run([prefix/'elan/bin/lean','--print-prefix'], cwd=test_project,env=env)).resolve()==lean_root, 'ordinary lean-toolchain selection failed')
    ruby_parent=prefix/'ruby';ruby_parent.mkdir()
    run(['tar','-xzf',candidate['ruby-3.3.12-ubuntu-24.04-x64.tar.gz'],'-C',ruby_parent,'--no-same-owner'])
    ruby_root=ruby_parent/'x64'
    actual_ruby=ruby_root/'bin/ruby'
    ruby_std=ruby_root/'lib/ruby/3.3.0'
    ruby_env={
      'GEM_HOME':str(prefix/'gems'),'GEM_PATH':str(prefix/'gems')+':'+str(ruby_root/'lib/ruby/gems/3.3.0'),
      'BUNDLE_PATH':str(prefix/'bundle'),'BUNDLE_FROZEN':'true','BUNDLE_DISABLE_VERSION_CHECK':'true',
      'BUNDLE_APP_CONFIG':str(prefix/'bundle-config'),'BUNDLE_USER_HOME':str(prefix/'bundle-user'),
      'RUBYLIB':str(ruby_std)+':'+str(ruby_std/'x86_64-linux'),
    }
    def make_wrapper(name, args):
        lines=['#!/bin/sh','set -eu']
        for key,val in ruby_env.items():lines.append('export '+key+'='+shellvar(val))
        lines.append('export LD_LIBRARY_PATH='+shellvar(ruby_root/'lib')+'${LD_LIBRARY_PATH:+":$LD_LIBRARY_PATH"}')
        lines.append('exec '+' '.join(shellvar(x) for x in [actual_ruby,*args])+' "$@"')
        out=prefix/'bin'/name;out.write_text('\n'.join(lines)+'\n');out.chmod(0o755)
    make_wrapper('ruby',[])
    make_wrapper('bundle',[prefix/'gems/gems/bundler-2.7.2/exe/bundle'])
    env.update(PATH=':'.join([str(prefix/'bin'),str(prefix/'elan/bin'),env['PATH']]),BUNDLE_GEMFILE=str(template/'Gemfile'))
    run([prefix/'bin/ruby',ruby_root/'bin/gem','install','--local',candidate['bundler-2.7.2.gem'],'--no-document','--install-dir',prefix/'gems','--bindir',prefix/'gem-bin'],env=env)
    for name,path in candidate.items():
        if name.endswith('.gem') and name!='bundler-2.7.2.gem':
            shutil.copyfile(path,template/'vendor/cache'/name)
    run([prefix/'bin/bundle','install','--local','--jobs','2'],cwd=template,env=env)
    env['BUNDLE_GEMFILE']=str(pipeline/'Gemfile')
    check=run([prefix/'bin/bundle','check'],cwd=pipeline,env=env)
    fixture=prefix/'license-positive';fixture.mkdir()
    shutil.copyfile(pipeline/'LICENSE',fixture/'LICENSE')
    detector=run([prefix/'bin/bundle','exec','ruby',pipeline/'scripts/detect_license.rb',fixture],cwd=pipeline,env=env)
    detected=json.loads(detector)
    expect(detected.get('licenses')==[{'spdx_id':'MIT'}] and detected.get('matched_files')==[{'matched_license':'MIT'}], 'official stock license helper returned '+detector)
    versions={label:run(cmd,cwd=test_project,env=env) for label,cmd in {
        'elan':[elan,'--version'],'lean':['lean','--version'],'lake':['lake','--version'],
        'ruby':['ruby','--version'],'bundler':['bundle','--version'],'licensee':['bundle','exec','licensee','version']}.items()}
    for k,s in {'elan':'4.2.3','lean':'4.35.0','ruby':'3.3.12','bundler':'2.7.2','licensee':'10.0.0'}.items():
        expect(s in versions[k], 'unexpected version '+k)
    act=prefix/'activate.sh'
    act.write_text('export ELAN_HOME='+shellvar(prefix/'elan')+'\nexport PATH='+shellvar(str(prefix/'bin')+':'+str(prefix/'elan/bin'))+':"$PATH"\n')
    report={'pipeline_commit':inputs['workflow_commit'],'input_manifest_sha256':MANIFEST_SHA256,
            'elapsed_seconds':round(time.time()-before,3),'started_epoch':before,
            'lean_selection':lean_mode,'lean_primitive_table_sha256':file_hash(lean_root/'src/lean/lake/Lake/CLI/Check.lean'),
            'lean_full_tree':inputs['lean']['full_tree'],'gem_archives_verified':sum(n.endswith('.gem') for n in candidate),
            'versions':versions,'bundle_check':check,'stock_detect_license':detected}
    out=prefix/'toolchain-readiness.json';out.write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
    print(json.dumps(report,sort_keys=True),flush=True)

if __name__=='__main__':
    try:main()
    except subprocess.CalledProcessError as e:
        sys.stderr.write((e.stdout or '')[-6000:]+'\n');raise
