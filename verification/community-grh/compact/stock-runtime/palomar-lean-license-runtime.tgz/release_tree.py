from pathlib import Path
import hashlib,os,stat,sys
def file_hash(path):
 h=hashlib.sha256()
 with open(path,'rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def tree_digest(root):
 h=hashlib.sha256(); count=0; size=0
 for p in sorted(root.rglob('*'),key=lambda x:x.relative_to(root).as_posix()):
  st=p.lstat(); key=p.relative_to(root).as_posix()
  if stat.S_ISDIR(st.st_mode):continue
  if stat.S_ISLNK(st.st_mode):item=['L',key,os.readlink(p)]
  elif stat.S_ISREG(st.st_mode):item=['F',key,'x' if st.st_mode&0o111 else '-',file_hash(p)];size+=st.st_size
  else:raise ValueError('Unexpected file in release: '+key)
  h.update(('\0'.join(item)+'\n').encode());count+=1
 return {'digest':h.hexdigest(),'entries':count,'regular_bytes':size}
