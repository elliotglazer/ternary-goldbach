from pathlib import Path
import sys,tempfile,subprocess,json,time,os,hashlib,shutil
from pathlib import Path as P
import warm_main as worker
import warm_supervisor as sup
import warm_dispatch as disp
tool=P('/tmp/tg-finite-kernel-435/lean-4.35.0-linux')
bwrap=P('/tmp/grh-challenge-repro-eolwchzr/pkg/usr/bin/bwrap')
base=P(__file__).resolve().parent
sha=lambda s:hashlib.sha256(s).hexdigest()
def git(repo,*a):
 return subprocess.check_output(['git','-C',str(repo),*a]).decode().strip()
def write_source(repo,file,text):
 f=repo/file;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(text)
def commit(repo,label):
 git(repo,'add','--','*.lean','lakefile.toml','lean-toolchain','lake-manifest.json')
 git(repo,'-c','user.name=Fixture','-c','user.email=root@localhost','commit','-qm',label)
 return git(repo,'rev-parse','HEAD')
def stage(repo,pin,work,root):
 src=work/'source';src.mkdir(parents=True);rows=worker.list_sources(repo,pin,root)
 blobs=worker.read_blobs(repo,[b for _,b in rows.values()])
 for rel,blob in rows.values():
  file=src/rel;file.parent.mkdir(parents=True,exist_ok=True);file.write_bytes(blobs[blob])
 for name in ['lakefile.toml','lean-toolchain','lake-manifest.json']:write_source(src,name,git(repo,'show',pin+':'+name)+'\n')
 for q in ['build','config','packages']:(src/'.lake'/q).mkdir(exist_ok=True,parents=True)
 gr=worker.graph(blobs,rows);assert worker.closure(root,gr)==set(rows)
 return src,rows,gr
with tempfile.TemporaryDirectory() as d:
 w=P(d);repo=w/'repo';repo.mkdir();git(repo,'init','-q')
 write_source(repo,'lakefile.toml','name="RootFixture"\n[[lean_lib]]\nname="G"\nsrcDir="CompactGRH/src"\nroots=["Main"]\n[[lean_lib]]\nname="F"\nroots=["FiniteBase","FiniteLeaf","CompletedFiniteRows"]\n')
 write_source(repo,'lean-toolchain','leanprover/lean4:v4.35.0\n')
 write_source(repo,'lake-manifest.json',json.dumps({'version':'1.1.0','packagesDir':'.lake/packages','packages':[],'name':'RootFixture','lakeDir':'.lake'})+'\n')
 write_source(repo,'CompactGRH/src/Main.lean','module\n@[expose] public def body : Nat := unrelatedMissing\n')
 write_source(repo,'FiniteBase.lean','module\n@[expose] public def baseValue : Nat := 10\n')
 write_source(repo,'FiniteLeaf.lean','module\npublic import FiniteBase\n@[expose] public def check : Nat := missingWitness\n')
 write_source(repo,'CompletedFiniteRows.lean','module\npublic import FiniteLeaf\npublic theorem answered : check = 11 := rfl\n')
 write_source(repo,'GoldbachSolution.lean','module\npublic import Main\npublic import CompletedFiniteRows\n')
 old=commit(repo,'base');mains,mr,mg=stage(repo,old,w/'main','Main');n=worker.run_lake(tool,mains,mains/'.lake/packages',w/'main',bwrap,time.time()+600);assert n['root']=='+Main' and n['exit']==1 and any('Main.lean' in x for x in n['failed_source_locations']),n
 early,er,eg=stage(repo,old,w/'early','CompletedFiniteRows');e=worker.run_lake(tool,early,early/'.lake/packages',w/'early',bwrap,time.time()+600,'CompletedFiniteRows');assert e['exit']==1 and e['newly_built']==['FiniteBase'] and e['root']=='+CompletedFiniteRows',e
 write_source(repo,'FiniteLeaf.lean','module\npublic import FiniteBase\n@[expose] public def check : Nat := baseValue + 1\n');pin=commit(repo,'repair');late,lr,lg=stage(repo,pin,w/(pin+'-'+'2'*32),'CompletedFiniteRows')
 seeds=worker.stage_seed(early,late,er,lr,lg,set(e['newly_built']),tool,base/'WarmArtifactHashes.lean',late.parent)
 assert seeds['accepted']==['FiniteBase'],seeds
 passed=worker.run_lake(tool,late,late/'.lake/packages',late.parent,bwrap,time.time()+600,'CompletedFiniteRows');assert passed['exit']==0 and passed['root']=='+CompletedFiniteRows' and set(passed['newly_built'])=={'CompletedFiniteRows','FiniteLeaf'},passed
 # Chain a finite-to-finite layer with root-owned evidence, then reject its reuse as Main.
 import tempfile
 with tempfile.TemporaryDirectory(dir="/var/lib") as tr:
  queue=P(tr);token="2"*32;job=queue/token;job.mkdir()
  subprocess.check_call(["git","clone","-q","--bare",str(repo),str(job/"candidate.git")])
  result=passed|{"source_commit":pin,"source_tree":git(repo,"rev-parse",pin+"^{tree}"),"parent_receipt":worker.RECEIPT,"eligible":1}
  (late.parent/"result.json").write_text(json.dumps(result))
  status={"job":{"token":token,"main":True,"receipt_sha":worker.RECEIPT,"commit":pin,"tree":result["source_tree"],"root":"CompletedFiniteRows"},"kind":"warm diagnostics only","finished_unix":time.time(),"old_receipt_sha256":worker.RECEIPT,"warm_main_exit":0,"warm_main_output":str(late.parent)}
  (job/"status.json").write_text(json.dumps(status));(job/"warm-main-driver.log").write_text(json.dumps({k:result[k] for k in ["kind","root","exit","log_sha256","eligible"]})+"\n")
  ready,rr,rg=stage(repo,pin,w/"chained","CompletedFiniteRows")
  primary=worker.stage_seed(early,ready,er,rr,rg,set(e["newly_built"]),tool,base/"WarmArtifactHashes.lean",ready.parent)
  layer=worker.validate_previous(token,ready.parent,rr,rg,tool,set(primary["accepted"]),queue=queue,root="CompletedFiniteRows")
  assert set(layer["accepted"])=={"FiniteLeaf","CompletedFiniteRows"},layer
  again=worker.run_lake(tool,ready,ready/".lake/packages",ready.parent,bwrap,time.time()+600,"CompletedFiniteRows");assert again["exit"]==0 and again["newly_built"]==[],again
  try:worker.validate_previous(token,ready.parent,rr,rg,tool,set(),queue=queue,root="Main")
  except ValueError as ex: cross_error=str(ex);assert cross_error=="Previous diagnostic root differs"
  else:raise RuntimeError("cross-root layer admitted")
 # Reject unsupported input at the supervisor boundary and the compiler even if called directly.
 good={'token':'1'*32,'checks':[],'commit':pin,'tree':git(repo,'rev-parse',pin+'^{tree}'),'receipt_sha':sup.PARENT_SHA,'main':True}
 sup.validate_request(good);sup.validate_request(good|{'root':'CompletedFiniteRows'})
 reject={}
 for key,case in [('unknown',good|{'root':'GoldbachSolution'}),('option',good|{'root':'--help'}),('probe_with_root',good|{'main':False,'checks':[['Test','a'*64]],'root':'CompletedFiniteRows'})]:
  try:sup.validate_request(case)
  except ValueError as ex:reject[key]=str(ex)
  else:raise RuntimeError('bad request accepted')
 try:worker.run_lake(tool,late,late/'.lake/packages',late.parent,bwrap,time.time()+600,'GoldbachSolution')
 except ValueError as ex:reject['invalid_direct_target']=str(ex)
 else:raise RuntimeError('bad direct target accepted')
 # CLI parser only; no dispatch, network, or host actions.
 for script in ['warm_main.py','warm_dispatch.py']:
  helptext=subprocess.check_output([sys.executable,'-B',str(base/script),'--help'],text=True)
  assert '--root {Main,CompletedFiniteRows}' in helptext
 version=subprocess.check_output([tool/'bin'/'lake','--version'],text=True).strip()
 result={'scope':'local stock Linux Lake diagnostic target selection and real facet validation','version':version,'default':n,'finite_initial':e,'accepted_from_initial':seeds['accepted'],'finite_after_patch':passed,'rejected':reject,'accepted_finite_layer':layer['accepted'],'fully_warm':again,'cross_root_rejected':cross_error,'runtime_files':{x:worker.hashfile(base/x) for x in ['warm_main.py','warm_dispatch.py','warm_supervisor.py','WarmArtifactHashes.lean','warm_probe.py']},'host_archive_sha256':sha(disp.archive())}
 P(sys.argv[1]).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'default':n['exit'],'initial':e['exit'],'after':passed['exit'],'accepted':seeds['accepted'],'archive':result['host_archive_sha256']}))
