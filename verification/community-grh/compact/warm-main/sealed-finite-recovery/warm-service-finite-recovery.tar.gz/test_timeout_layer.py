#!/usr/bin/env python3
"""Exercise a real clock-limited Linux Lake build, its authenticated partial cache, and a clean retry."""
import json
import sys
import tempfile
import time
from pathlib import Path

import warm_main as worker
from test_warm_layers import call, commit
from test_warm_main import prep


def main(tool, bwrap, output):
    with tempfile.TemporaryDirectory() as scratch, tempfile.TemporaryDirectory(dir="/var/lib") as trusted:
        work = Path(scratch)
        queue = Path(trusted)
        repo = work / "git"
        call(["git", "init", "-q", str(repo)])
        original = work / "original"
        prep(original, fixed=True)
        deep_path = Path("CompactGRH/src/Deep.lean")
        slow = (original / deep_path).read_text().replace("public import Intermediate", "public import Intermediate\nimport Lean")
        slow = slow.replace("laterMissing", "intermediate")
        (original / deep_path).write_text(slow + "\nrun_cmd do IO.sleep 120000\n")
        pin, tree, _, _ = commit("clock-limited fixture", original, repo)
        token = "3" * 32
        previous = work / (pin + "-" + token)
        previous.mkdir()
        original.rename(previous / "source")
        source = previous / "source"
        previous_packages = source / ".lake/packages"
        stopped = worker.run_lake(tool, source, previous_packages, previous, bwrap, time.time() + 182)
        assert stopped["exit"] == 124, stopped
        assert 60 <= stopped["time_limit_seconds"] <= 62
        expected = {"Base", "Changed", "Reader", "Stable", "Intermediate"}
        assert set(stopped["newly_built"]) == expected, stopped
        stopped.update(source_commit=pin, source_tree=tree, parent_receipt=worker.RECEIPT, eligible=0)
        (previous / "result.json").write_text(json.dumps(stopped))
        job = queue / token
        job.mkdir()
        call(["git", "clone", "-q", "--bare", str(repo), str(job / "candidate.git")])
        request = {"token": token, "main": True, "receipt_sha": worker.RECEIPT, "commit": pin, "tree": tree}
        status = {"kind": "warm diagnostics only", "job": request, "finished_unix": time.time(),
                  "old_receipt_sha256": worker.RECEIPT, "warm_main_exit": 124, "warm_main_output": str(previous)}
        status_file = job / "status.json"
        status_file.write_text(json.dumps(status))
        driver_file = job / "warm-main-driver.log"
        summary = {key: stopped[key] for key in ("kind", "root", "exit", "wall_seconds", "log_sha256", "eligible", "time_limit_seconds")}
        current = work / "retry"
        current.mkdir()
        retry_source = current / "source"
        prep(retry_source, fixed=True)
        (retry_source / deep_path).write_text(slow)
        _, _, rows, graph = commit("remove test delay", retry_source, repo)

        def check_layer():
            return worker.validate_previous(token, current, rows, graph, tool, set(), queue=queue)

        for key, value in (("time_limit_seconds", 900), ("time_limit_seconds", None), ("wall_seconds", 0), ("exit", 0)):
            altered = dict(summary)
            if value is None:
                altered.pop(key)
            else:
                altered[key] = value
            driver_file.write_text(json.dumps(altered) + "\n")
            try:
                check_layer()
            except ValueError:
                pass
            else:
                raise AssertionError("Accepted an inconsistent supervisor summary")
        driver_file.write_text(json.dumps(summary) + "\n")
        status_file.write_text(json.dumps(status | {"error": "outer process stopped before finalization"}))
        try:
            check_layer()
        except ValueError as error:
            assert "completed supervisor receipt" in str(error)
        else:
            raise AssertionError("Accepted an unfinished worker")
        status_file.write_text(json.dumps(status))
        verified = check_layer()
        assert set(verified["accepted"]) == expected
        final = worker.run_lake(tool, retry_source, retry_source / ".lake/packages", current, bwrap, time.time() + 600)
        assert final["exit"] == 0 and set(final["newly_built"]) == {"Deep", "Main"}, final
        result = {"scope": "Real local Linux Lean diagnostic timeout and artifact reuse. No protected proof check.",
                  "lake": call([tool / "bin/lake", "--version"]), "interrupted": stopped,
                  "reused": verified["accepted"], "retry": final, "controls_rejected": 5}
        output.write_text(json.dumps(result, indent=2) + "\n")
        print(json.dumps({k: result[k] for k in ("lake", "reused", "controls_rejected")}), flush=True)


if __name__ == "__main__":
    main(*(Path(x).resolve() for x in sys.argv[1:]))
