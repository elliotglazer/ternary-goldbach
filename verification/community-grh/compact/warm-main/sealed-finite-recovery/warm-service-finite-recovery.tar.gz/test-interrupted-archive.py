from pathlib import Path
import contextlib,hashlib,json,os,shutil,sys,tempfile,time
from unittest.mock import patch
sys.path.insert(0,'/tmp/tg-recover-finite-d845-20261126')
import warm_main as w
D=Path('/mnt/c/Users/glaze/Documents/Codex/2026-11-25/new-chat-2/outputs')
original=D/'finite-d8457751-interrupted';prefix=D/'finite-d8457751-snapshot1';observed=D/'stock-runtime-and-recovery'
repo=Path('/verification/tg-community-20261125/goldbach-compact-branch')
tool=Path('/tmp/tg-finite-kernel-435/lean-4.35.0-linux');helper=Path(w.__file__).parent/'WarmArtifactHashes.lean'
seen=json.loads((observed/'job-recovery.json').read_bytes());newboot=seen['boot_id'];oldboot=w.INTERRUPTED_BOOT;token=w.INTERRUPTED_JOB
bootfile=Path('/proc/sys/kernel/random/boot_id');statfile=Path('/proc/stat');positive=[];negative=[]
def fail(fn):
 try:fn()
 except (ValueError,AssertionError) as e:
  negative.append(str(e));return
 raise AssertionError("failed to reject control")
with tempfile.TemporaryDirectory(dir='/var/lib',prefix='tg-interrupt-control-') as temp:
 base=Path(temp);queue=base/'queue';job=queue/'jobs'/token;job.mkdir(parents=True);(queue/'claimed').mkdir();prior=base/'retained';prior.mkdir()
 for n in ('status.json','warm-main-driver.log'):shutil.copyfile(original/n,job/n)
 for n in ('warm-main.log','seeds.json','seed-layers.json'):shutil.copyfile(original/n,prior/n)
 claim=queue/'claimed'/(token+'.json');shutil.copyfile(observed/(token+'.json'),claim)
 status=json.loads((job/'status.json').read_bytes());log=prior/'warm-main.log';driver=job/'warm-main-driver.log'
 assert log.read_bytes().startswith((prefix/'warm-main.log').read_bytes()) and w.hashfile(prefix/'warm-main.log')==w.INTERRUPTED_PREFIX
 assert seen['jobs'][token]['log_sha256']==w.hashfile(log) and newboot=='9a5c7774-579a-4e95-83ce-62d43e353f62'
 source=w.list_sources(repo,w.INTERRUPTED_PIN,'CompletedFiniteRows'); b=w.read_blobs(repo,[v for _,v in source.values()]);g=w.graph(b,source);assert w.closure('CompletedFiniteRows',g)==set(source)
 def check(root='CompletedFiniteRows',boot=newboot,epoch=int(status['started_unix'])+1000):
  old=Path.read_text
  def read(self,*a,**k):
   if self==bootfile:return boot+'\n'
   if self==statfile:return "btime "+str(epoch)+"\n"
   return old(self,*a,**k)
  with patch.object(Path,'read_text',read):
   return w.interrupted_anchor(job,prior,status,root,driver,log)
 names,meta=check();assert len(names)==454 and names<=set(source) and not meta['completed_job'];positive.append('actual recorded status, claim, seed ledgers, complete log, prefix and changed boot')
 fail(lambda:check(root='Main'));fail(lambda:check(boot=oldboot));fail(lambda:check(epoch=int(status['started_unix'])-1))
 for file in [log,claim,job/'status.json',prior/'seeds.json',prior/'seed-layers.json',driver]:
  good=file.read_bytes();file.write_bytes((b'!' + good[1:]) if good else b'!')
  fail(check);file.write_bytes(good)
 log.write_bytes(log.read_bytes()[:-1]);fail(check);shutil.copyfile(original/'warm-main.log',log)
 (prior/'result.json').write_text('{}');fail(check);(prior/'result.json').unlink()
 (prior/'result.json').symlink_to(prior/'absent');fail(check);(prior/'result.json').unlink()
 # Host archive contains logs only. Missing retained facets must recover zero modules.
 empty=base/'new';empty.mkdir();(prior/'source/.lake/build').mkdir(parents=True);(empty/'source/.lake/build').mkdir(parents=True)
 emptyrec=w.stage_seed(prior/'source',empty/'source',source,source,g,names,tool,helper,empty)
 assert not emptyrec['accepted'] and set(emptyrec['rejected'])==names;positive.append('all 454 production names withheld without their actual Lake traces')
 # Genuine production leaf source in an explicitly separate small Lake test.
 # This test checks the facet hasher independent of the historical AWS workspace.
 roots=['FastHex','GoldbachNatPowMod']
 for name in roots:assert name in names and not g[name]
 bwrap=Path("/tmp/grh-challenge-repro-eolwchzr/pkg/usr/bin/bwrap")
 ldir=base/'leaf-project';ldir.mkdir()
 for nm,content in {'lean-toolchain':'leanprover/lean4:v4.35.0\n','lakefile.toml':'name = "observed"\nversion = "0.1.0"\n[[lean_lib]]\nname = "FastHex"\n[[lean_lib]]\nname = "GoldbachNatPowMod"\n','lake-manifest.json':'{"version":"1.1.0","packages":[],"name":"observed","lakeDir":".lake"}\n'}.items():(ldir/nm).write_text(content)
 for name in roots:(ldir/source[name][0]).write_bytes(b[source[name][1]])
 for sub in ['build','packages','config']:(ldir/'.lake'/sub).mkdir(parents=True)
 import subprocess
 cmd=w.project_box(tool,ldir,ldir/'.lake/packages',['/tool/bin/lake','--no-cache','build',*['+'+n for n in roots]],bwrap)
 run=subprocess.run(cmd,capture_output=True);assert run.returncode==0,(run.stdout,run.stderr)
 stocklog=run.stdout+run.stderr;assert w.built_names(stocklog.decode())>=set(roots)
 native=base/'leaf-dest';native.mkdir();(native/'source/.lake/build').mkdir(parents=True)
 real=w.stage_seed(ldir,native/'source',source,source,g,set(roots),tool,helper,native);assert sorted(real['accepted'])==sorted(roots),real
 bad=base/'damage-dest';bad.mkdir();(bad/'source/.lake/build').mkdir(parents=True)
 badfile=ldir/'.lake/build/lib/lean/GoldbachNatPowMod.olean';data=badfile.read_bytes();badfile.write_bytes(bytes([data[0]^1])+data[1:])
 damaged=w.stage_seed(ldir,bad/'source',source,source,g,set(roots),tool,helper,bad);assert damaged['accepted']==['FastHex'] and 'actual artifact bytes' in damaged['rejected']['GoldbachNatPowMod']
 positive.append('real exact production FastHex and GoldbachNatPowMod source: original stock Lake facets accepted, corrupt binary rejected')
 out={'source':w.INTERRUPTED_PIN,'source_tree':w.INTERRUPTED_TREE,'root':'CompletedFiniteRows','log_sha256':w.INTERRUPTED_LOG,'original_prefix_sha256':w.INTERRUPTED_PREFIX,'completed_job':False,'production_log_names':len(names),'source_modules':len(source),'empty_archive_candidates_accepted':0,'empty_archive_candidates_rejected':len(emptyrec['rejected']),'microproject':{'stock_log_sha256':hashlib.sha256(stocklog).hexdigest(),'exact_source_modules':{n:hashlib.sha256(b[source[n][1]]).hexdigest() for n in roots},'accepted':real['accepted'],'copied_files':real['copied_files'],'corruption':damaged['rejected']},'genuine_positive_inputs':positive,'negative_controls':negative,'scope':'Original cloud evidence and exact source are genuine. Changed boot observation is injected locally from archived host facts; private WSL clock is different. The two real sources were compiled locally in a separate small Lake project. Actual retained EC2 facets will be checked on the host; this receipt does not mark the interrupted root complete.'}
 outpath=Path(w.__file__).parent/'interrupted-control.json';outpath.write_text(json.dumps(out,indent=2)+'\n');print(w.hashfile(outpath),len(names),len(negative),real['accepted'],flush=True)
