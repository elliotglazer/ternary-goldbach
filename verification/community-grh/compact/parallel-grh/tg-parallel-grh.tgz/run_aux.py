#!/usr/bin/env python3
"""Run one Main diagnostic alongside an active finite worker, preserving normal lineage records."""
import fcntl
import json
import os
from pathlib import Path
import pwd
import shutil
import sys
import time
import warm_supervisor as w
import warm_main as wm

UNIT="tg-warm-grh-aux.service"
PRIMARY="tg-warm-main.service"
BINARY="tg-binary-7ef89daf.service"
FINITE_TOKEN="7ef89dafd4de4d2473336f60c2c16246"
FINITE_PIN="24954b2814714e7fe324bcdc0304c0a9ddefb909"
FINITE_TREE="ffbd19a22cf91aab3933995029b20d5cbce0a246"
BINARY_PATH=Path("/run/tg-binary-7ef89daf/binary_endpoint.py")
BINARY_HASH="65ce0a4ace395459efa319eba1bff721e0158c71e31f2b674827ac4b013bdaa7"
BIN_EVIDENCE=Path("/work/tg-binary-7ef89daf-evidence/proof")
CG=Path("/sys/fs/cgroup/system.slice")

def check(ok,message):
    if not ok:
        raise ValueError(message)

def processes(unit,uid):
    try:
        pids=(CG/unit/"cgroup.procs").read_text().splitlines()
    except FileNotFoundError:
        return
    for pid in pids:
        path=Path("/proc")/pid
        try:
            if path.stat().st_uid==uid:
                argv=(path/"cmdline").read_bytes().decode(errors="replace").split("\\0")
                yield path,argv[:-1] if argv and not argv[-1] else argv
        except (FileNotFoundError,ProcessLookupError):
            continue

def primary_roots(uid):
    roots=set()
    for _,args in processes(PRIMARY,uid):
        if any(s.endswith("/warm_main.py") for s in args):
            if "--root" in args and args.index("--root")+1<len(args):
                roots.add(args[args.index("--root")+1])
            else:
                roots.add("Main")
    return roots

def exact_binary_argv(argv):
    if len(argv)<3 or argv[:3] not in (["python3","-B",str(BINARY_PATH)],["/usr/bin/python3","-B",str(BINARY_PATH)]):
        return False
    rest=argv[3:]
    if len(rest)%2:
        return False
    opts=dict(zip(rest[::2],rest[1::2]))
    source=w.RESULTS/(FINITE_PIN+"-"+FINITE_TOKEN)/"source"
    expected={"--repo":str(w.QUEUE/"jobs"/FINITE_TOKEN/"candidate.git"),"--commit":FINITE_PIN,"--tree":FINITE_TREE,
              "--source-tree":str(source),"--packages":"/work/compact-joint-runs/"+w.BASE+"-"+w.OLD+"/run/source/.lake/packages",
              "--toolchain":"/work/compact-joint-435-verified-tools/lean-4.35.0-linux","--bwrap":"/usr/bin/bwrap","--out":str(BIN_EVIDENCE)}
    optset=set(expected)|{"--bwrap-sha256","--expected-object-sha256","--deadline-seconds"}
    return (len(rest)==2*len(opts) and set(opts)==optset and all(opts[k]==val for k,val in expected.items())
            and w.DIGEST.fullmatch(opts["--bwrap-sha256"]) is not None
            and w.DIGEST.fullmatch(opts["--expected-object-sha256"]) is not None
            and opts["--deadline-seconds"].isascii() and opts["--deadline-seconds"].isdigit()
            and 0<int(opts["--deadline-seconds"])<=36000)

def binary_is_running(uid):
    if w.status(BINARY)!="active":
        return False
    for proc,argv in processes(BINARY,uid):
        if not exact_binary_argv(argv):
            continue
        try:
            if not (proc/"exe").samefile("/usr/bin/python3") or (proc/"fd/8").resolve()!=w.DISPATCH_LOCK:
                continue
            if w.hash_file(wm.rooted_evidence(BINARY_PATH))!=BINARY_HASH:
                return False
            # These two variable hash arguments refer to the OS installation and actual finite artifact.
            opts=dict(zip(argv[3::2],argv[4::2]))
            endpoint=w.RESULTS/(FINITE_PIN+"-"+FINITE_TOKEN)/"source/.lake/build/lib/lean/ProductPrefix564386325504.olean"
            if w.hash_file(Path("/usr/bin/bwrap"))!=opts["--bwrap-sha256"] or w.hash_file(endpoint)!=opts["--expected-object-sha256"]:
                return False
            return True
        except (FileNotFoundError,ProcessLookupError):
            continue
    return False

def previous_terminal(token):
    # The source worker independently runs validate_previous for every one of these tokens:
    # root supervisor/driver authentication, original trace and source checks, exact source
    # ancestry and input bytes. This smaller synchronous check rejects unfinished submissions.
    record=json.loads(wm.rooted_evidence(w.QUEUE/"jobs"/token/"status.json").read_bytes())
    req=record["job"]
    w.validate_request(req)
    check(req["token"]==token and req.get("root","Main")=="Main" and req["main"] and
          record.get("finished_unix") and not record.get("error") and record.get("kind")=="warm diagnostics only"
          and record.get("old_receipt_sha256")==w.PARENT_SHA and record.get("warm_main_exit") in (0,1,124,137),
          "Prior +Main lacks a completed original supervisor record: "+token)

def eligible_peer(uid):
    direct=primary_roots(uid)
    if direct=={"CompletedFiniteRows"}:
        return "finite-source"
    if direct:
        return None
    return "binary-endpoint" if binary_is_running(uid) else None

def ready(job):
    w.validate_request(job)
    check(job.get("root")=="Main" and job["main"] and not job["checks"],"Expected a Main-only GRH request")
    for token in job.get("previous_jobs",[]):
        previous_terminal(token)
    boot=Path("/proc/sys/kernel/random/boot_id").read_text().strip()
    closed=w.QUEUE/"closed"
    check(not closed.exists() or closed.read_text().strip()!=boot,"Warm host is closing")
    check(w.cold_inactive() and w.status("tg-warm-patch-probe.service") in ("inactive","failed"),"Cold or probe job is active")
    check(eligible_peer(pwd.getpwnam("grhreplay").pw_uid) is not None,
          "Waiting for the actual finite source worker or pinned live endpoint checker")
    for path in (w.QUEUE/"pending").glob("*.json"):
        request=json.loads(wm.rooted_evidence(path).read_bytes())
        check(not (request.get("main") and request.get("root","Main")=="Main"),"A normal Main job is already queued")
    for path in (w.QUEUE/"jobs").glob("*/status.json"):
        record=json.loads(wm.rooted_evidence(path).read_bytes())
        existing=record.get("job",{})
        if (existing.get("commit")==job["commit"] and existing.get("tree")==job["tree"] and
            existing.get("main") and existing.get("root","Main")=="Main"):
            check(record.get("finished_unix") and record.get("warm_main_exit")!=0,
                  "This source already has a live or passing Main job")
    check(w.DEADLINE-time.time()>420,"Less than seven minutes before the original account stop")
    check(shutil.disk_usage("/work").free>=24*2**30,"Need 24 GiB free on the retained mount")

def bounded_service():
    check(Path("/proc/self/cgroup").read_text().strip()=="0::/system.slice/"+UNIT,"Wrong bounded auxiliary service")
    cap=CG/UNIT
    q,p=map(int,(cap/"cpu.max").read_text().split())
    check(0<q<=8*p and int((cap/"memory.high").read_text())==32*2**30 and int((cap/"memory.max").read_text())==40*2**30 and (cap/"memory.swap.max").read_text().strip()=="0","Incorrect auxiliary limits")

def main():
    preflight=sys.argv[1:2]==["--preflight"]
    check(len(sys.argv)==(3 if preflight else 2) and os.geteuid()==0,"Expected root admission and one immutable job")
    path=Path(sys.argv[-1])
    check(path.resolve()==path and path.stat().st_uid==0 and not path.stat().st_mode&0o022,"Untrusted job file")
    job=json.loads(path.read_bytes())
    # The original warm supervisor must acquire this lock exclusively before its idle poweroff.
    # Finite compilation and consuming its already-admitted queue use different locks.
    with w.DISPATCH_LOCK.open("rb") as lease:
        fcntl.flock(lease,fcntl.LOCK_SH|fcntl.LOCK_NB)
        ready(job)
        job_dir=w.QUEUE/"jobs"/job["token"]
        check(not job_dir.exists() and not (w.RESULTS/(job["commit"]+"-"+job["token"])).exists(),"This auxiliary attempt already exists")
        if preflight:
            print("Authenticated +Main lineage and active peer; retained shared shutdown lock.",flush=True)
            return 0
        bounded_service()
        w.handle(job)
        result=json.loads((job_dir/"status.json").read_bytes())
        check(result.get("finished_unix") and not result.get("error") and result.get("warm_main_exit") in (0,1,124,137),
              "GRH diagnostic ended without an eligible terminal supervisor receipt")
        print(json.dumps({"token":job["token"],"candidate":job["commit"],"lake_exit":result["warm_main_exit"],"evidence":str(job_dir)}))
        return result["warm_main_exit"]

if __name__=="__main__":
    raise SystemExit(main())
