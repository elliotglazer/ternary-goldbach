#!/usr/bin/env python3
"""Run one Main diagnostic alongside an active finite worker, preserving normal lineage records."""
import fcntl
import json
import os
from pathlib import Path
import pwd
import shutil
import sys
import time
import warm_supervisor as w

UNIT="tg-warm-grh-aux.service"
PRIMARY="tg-warm-main.service"
LINEAGE=["0c296855616fd2f1d288aae9c2f27f55","c5b595a6ca6bc4f7ef9ada59593b9a26","cc2ba2e764eca88b6ed1ad9d08d1cad7"]
CG=Path("/sys/fs/cgroup/system.slice")

def check(ok,message):
    if not ok:
        raise ValueError(message)

def has_finite():
    uid=pwd.getpwnam("grhreplay").pw_uid
    for line in (CG/PRIMARY/"cgroup.procs").read_text().splitlines():
        path=Path("/proc")/line
        try:
            if path.stat().st_uid!=uid:
                continue
            args=(path/"cmdline").read_bytes().decode(errors="replace").split("\0")
            if any(x.endswith("/warm_main.py") for x in args) and "--root" in args and args[args.index("--root")+1]=="CompletedFiniteRows":
                return True
        except (FileNotFoundError,ProcessLookupError,IndexError):
            continue
    return False

def admit(job):
    w.validate_request(job)
    check(job.get("root")=="Main" and job["main"] and not job["checks"] and job.get("previous_jobs")==LINEAGE,"Unexpected GRH request or seed lineage")
    check(os.geteuid()==0 and Path("/proc/self/cgroup").read_text().strip()=="0::/system.slice/"+UNIT,"Wrong bounded auxiliary service")
    boot=Path("/proc/sys/kernel/random/boot_id").read_text().strip()
    closed=w.QUEUE/"closed"
    check(not closed.exists() or closed.read_text().strip()!=boot,"Warm host is closing")
    check(w.cold_inactive() and w.status("tg-warm-patch-probe.service") in ("inactive","failed") and has_finite(),"An active finite primary and idle cold jobs are required")
    check(w.DEADLINE-time.time()>420,"Less than seven minutes before the original account stop")
    check(shutil.disk_usage("/work").free>=24*2**30,"Need 24 GiB free on the retained mount")
    cap=CG/UNIT
    q,p=map(int,(cap/"cpu.max").read_text().split())
    check(0<q<=8*p and int((cap/"memory.high").read_text())==32*2**30 and int((cap/"memory.max").read_text())==40*2**30 and (cap/"memory.swap.max").read_text().strip()=="0","Incorrect auxiliary limits")

def main():
    check(len(sys.argv)==2,"Pass one separate, immutable root-owned job JSON")
    path=Path(sys.argv[1])
    check(path.resolve()==path and path.stat().st_uid==0 and not path.stat().st_mode&0o022,"Untrusted job file")
    job=json.loads(path.read_bytes())
    # The original warm supervisor must acquire this lock exclusively before its idle poweroff.
    # Finite compilation and consuming its already-admitted queue use different locks.
    with w.DISPATCH_LOCK.open("rb") as lease:
        fcntl.flock(lease,fcntl.LOCK_SH|fcntl.LOCK_NB)
        admit(job)
        job_dir=w.QUEUE/"jobs"/job["token"]
        check(not job_dir.exists() and not (w.RESULTS/(job["commit"]+"-"+job["token"])).exists(),"This auxiliary attempt already exists")
        w.handle(job)
        result=json.loads((job_dir/"status.json").read_bytes())
        check(result.get("finished_unix") and not result.get("error") and result.get("warm_main_exit") in (0,1,124,137),
              "GRH diagnostic ended without an eligible terminal supervisor receipt")
        print(json.dumps({"token":job["token"],"candidate":job["commit"],"lake_exit":result["warm_main_exit"],"evidence":str(job_dir)}))
        return result["warm_main_exit"]

if __name__=="__main__":
    raise SystemExit(main())
