structure Q10004CompressedTheory :> Q10004CompressedTheory =
struct
  
  val _ = if !Globals.print_thy_loads
    then TextIO.print "Loading Q10004CompressedTheory ... "
    else ()
  
  open Type Term Thm
  local open Q10004AllTheory in end;
  
  structure TDB = struct
    val path =
      OS.Path.base (#(FILE)) ^ ".dat"
    val timestamp = HOLFileSys.modTime path
    val thydata = 
      TheoryReader.load_thydata {
        thyname = "Q10004Compressed",
        hash = "7a77d2aa0fa55968ac39cc1db955ad8cd2be8e92",
        path = path
      }
    fun find s = #1 (valOf (Symtab.lookup thydata s))
  end
  val () = Theory.record_metadata
    "Q10004Compressed" {timestamp=TDB.timestamp, path=TDB.path}
  
  fun op words_def _ = () val op words_def = TDB.find "words_def"
  fun op shared_kernels_def _ = ()
  val op shared_kernels_def = TDB.find "shared_kernels_def"
  fun op probe_list_7707_def _ = ()
  val op probe_list_7707_def = TDB.find "probe_list_7707_def"
  fun op probe_list_7659_def _ = ()
  val op probe_list_7659_def = TDB.find "probe_list_7659_def"
  fun op probe_list_6559_def _ = ()
  val op probe_list_6559_def = TDB.find "probe_list_6559_def"
  fun op probe_list_5499_def _ = ()
  val op probe_list_5499_def = TDB.find "probe_list_5499_def"
  fun op normsum_def _ = () val op normsum_def = TDB.find "normsum_def"
  fun op find_span_def _ = ()
  val op find_span_def = TDB.find "find_span_def"
  fun op digits_def _ = () val op digits_def = TDB.find "digits_def"
  fun op digits_compute _ = ()
  val op digits_compute = TDB.find "digits_compute"
  fun op cv_words_thm _ = () val op cv_words_thm = TDB.find "cv_words_thm"
  fun op cv_words_ind _ = () val op cv_words_ind = TDB.find "cv_words_ind"
  fun op cv_words_def _ = () val op cv_words_def = TDB.find "cv_words_def"
  fun op cv_normsum_thm _ = ()
  val op cv_normsum_thm = TDB.find "cv_normsum_thm"
  fun op cv_normsum_ind _ = ()
  val op cv_normsum_ind = TDB.find "cv_normsum_ind"
  fun op cv_normsum_def_primitive _ = ()
  val op cv_normsum_def_primitive = TDB.find "cv_normsum_def_primitive"
  fun op cv_normsum_def _ = ()
  val op cv_normsum_def = TDB.find "cv_normsum_def"
  fun op cv_int_exp_thm _ = ()
  val op cv_int_exp_thm = TDB.find "cv_int_exp_thm"
  fun op cv_int_exp_ind _ = ()
  val op cv_int_exp_ind = TDB.find "cv_int_exp_ind"
  fun op cv_int_exp_def _ = ()
  val op cv_int_exp_def = TDB.find "cv_int_exp_def"
  fun op cv_find_span_thm _ = ()
  val op cv_find_span_thm = TDB.find "cv_find_span_thm"
  fun op cv_find_span_def _ = ()
  val op cv_find_span_def = TDB.find "cv_find_span_def"
  fun op cv_digits_thm _ = ()
  val op cv_digits_thm = TDB.find "cv_digits_thm"
  fun op cv_digits_ind _ = ()
  val op cv_digits_ind = TDB.find "cv_digits_ind"
  fun op cv_digits_def _ = ()
  val op cv_digits_def = TDB.find "cv_digits_def"
  fun op cv_compact_jobs_thm _ = ()
  val op cv_compact_jobs_thm = TDB.find "cv_compact_jobs_thm"
  fun op cv_compact_jobs_def _ = ()
  val op cv_compact_jobs_def = TDB.find "cv_compact_jobs_def"
  fun op cv_MAP_lam_int_mul_int_of_num_cut_thm _ = ()
  val op cv_MAP_lam_int_mul_int_of_num_cut_thm = TDB.find
    "cv_MAP_lam_int_mul_int_of_num_cut_thm"
  fun op cv_MAP_lam_int_mul_int_of_num_cut_ind _ = ()
  val op cv_MAP_lam_int_mul_int_of_num_cut_ind = TDB.find
    "cv_MAP_lam_int_mul_int_of_num_cut_ind"
  fun op cv_MAP_lam_int_mul_int_of_num_cut_def _ = ()
  val op cv_MAP_lam_int_mul_int_of_num_cut_def = TDB.find
    "cv_MAP_lam_int_mul_int_of_num_cut_def"
  fun op cv_APPEND_thm _ = ()
  val op cv_APPEND_thm = TDB.find "cv_APPEND_thm"
  fun op cv_APPEND_ind _ = ()
  val op cv_APPEND_ind = TDB.find "cv_APPEND_ind"
  fun op cv_APPEND_def _ = ()
  val op cv_APPEND_def = TDB.find "cv_APPEND_def"
  fun op cv_ABS_thm _ = () val op cv_ABS_thm = TDB.find "cv_ABS_thm"
  fun op cv_ABS_def _ = () val op cv_ABS_def = TDB.find "cv_ABS_def"
  fun op compressed_spans_7707_def _ = ()
  val op compressed_spans_7707_def = TDB.find "compressed_spans_7707_def"
  fun op compressed_spans_7659_def _ = ()
  val op compressed_spans_7659_def = TDB.find "compressed_spans_7659_def"
  fun op compressed_spans_6559_def _ = ()
  val op compressed_spans_6559_def = TDB.find "compressed_spans_6559_def"
  fun op compressed_spans_5499_def _ = ()
  val op compressed_spans_5499_def = TDB.find "compressed_spans_5499_def"
  fun op compressed_repair_bits_7707 _ = ()
  val op compressed_repair_bits_7707 = TDB.find
    "compressed_repair_bits_7707"
  fun op compressed_repair_bits_7659 _ = ()
  val op compressed_repair_bits_7659 = TDB.find
    "compressed_repair_bits_7659"
  fun op compressed_repair_bits_6559 _ = ()
  val op compressed_repair_bits_6559 = TDB.find
    "compressed_repair_bits_6559"
  fun op compressed_repair_bits_5499 _ = ()
  val op compressed_repair_bits_5499 = TDB.find
    "compressed_repair_bits_5499"
  fun op compact_jobs_def _ = ()
  val op compact_jobs_def = TDB.find "compact_jobs_def"
  fun op MAP_lam_int_mul_int_of_num_cut_ho _ = ()
  val op MAP_lam_int_mul_int_of_num_cut_ho = TDB.find
    "MAP_lam_int_mul_int_of_num_cut_ho"
  fun op MAP_lam_int_mul_int_of_num_cut_def _ = ()
  val op MAP_lam_int_mul_int_of_num_cut_def = TDB.find
    "MAP_lam_int_mul_int_of_num_cut_def"
  
val _ = if !Globals.print_thy_loads then TextIO.print "done\n" else ()
val _ = Theory.load_complete "Q10004Compressed"

end
