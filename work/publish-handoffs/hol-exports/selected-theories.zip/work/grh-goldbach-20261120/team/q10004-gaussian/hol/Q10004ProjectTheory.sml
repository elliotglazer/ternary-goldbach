structure Q10004ProjectTheory :> Q10004ProjectTheory =
struct
  
  val _ = if !Globals.print_thy_loads
    then TextIO.print "Loading Q10004ProjectTheory ... "
    else ()
  
  open Type Term Thm
  local open Q10004CompressedTheory in end;
  
  structure TDB = struct
    val path =
      OS.Path.base (#(FILE)) ^ ".dat"
    val timestamp = HOLFileSys.modTime path
    val thydata = 
      TheoryReader.load_thydata {
        thyname = "Q10004Project",
        hash = "96af80d4f2d63910af66d5c96f5aa87504b3ce22",
        path = path
      }
    fun find s = #1 (valOf (Symtab.lookup thydata s))
  end
  val () = Theory.record_metadata
    "Q10004Project" {timestamp=TDB.timestamp, path=TDB.path}
  
  fun op within_def _ = () val op within_def = TDB.find "within_def"
  fun op raw_projection_7707 _ = ()
  val op raw_projection_7707 = TDB.find "raw_projection_7707"
  fun op raw_projection_7659 _ = ()
  val op raw_projection_7659 = TDB.find "raw_projection_7659"
  fun op raw_projection_6559 _ = ()
  val op raw_projection_6559 = TDB.find "raw_projection_6559"
  fun op raw_projection_5499 _ = ()
  val op raw_projection_5499 = TDB.find "raw_projection_5499"
  fun op projects_ind _ = () val op projects_ind = TDB.find "projects_ind"
  fun op projects_def _ = () val op projects_def = TDB.find "projects_def"
  fun op cv_within_thm _ = ()
  val op cv_within_thm = TDB.find "cv_within_thm"
  fun op cv_within_def _ = ()
  val op cv_within_def = TDB.find "cv_within_def"
  fun op cv_projects_thm _ = ()
  val op cv_projects_thm = TDB.find "cv_projects_thm"
  fun op cv_projects_def _ = ()
  val op cv_projects_def = TDB.find "cv_projects_def"
  
val _ = if !Globals.print_thy_loads then TextIO.print "done\n" else ()
val _ = Theory.load_complete "Q10004Project"

end
