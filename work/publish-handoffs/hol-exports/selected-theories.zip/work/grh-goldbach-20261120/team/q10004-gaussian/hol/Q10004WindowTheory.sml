structure Q10004WindowTheory :> Q10004WindowTheory =
struct
  
  val _ = if !Globals.print_thy_loads
    then TextIO.print "Loading Q10004WindowTheory ... "
    else ()
  
  open Type Term Thm
  local open Q10004ReceiptTheory in end;
  
  structure TDB = struct
    val path =
      OS.Path.base (#(FILE)) ^ ".dat"
    val timestamp = HOLFileSys.modTime path
    val thydata = 
      TheoryReader.load_thydata {
        thyname = "Q10004Window",
        hash = "c632a203962aec1694aaa6d1d56d0ef1f4244d90",
        path = path
      }
    fun find s = #1 (valOf (Symtab.lookup thydata s))
  end
  val () = Theory.record_metadata
    "Q10004Window" {timestamp=TDB.timestamp, path=TDB.path}
  
  fun op window_def _ = () val op window_def = TDB.find "window_def"
  fun op weights_7707_def _ = ()
  val op weights_7707_def = TDB.find "weights_7707_def"
  fun op weights_7659_def _ = ()
  val op weights_7659_def = TDB.find "weights_7659_def"
  fun op weights_6559_def _ = ()
  val op weights_6559_def = TDB.find "weights_6559_def"
  fun op weights_5499_def _ = ()
  val op weights_5499_def = TDB.find "weights_5499_def"
  fun op triple_def _ = () val op triple_def = TDB.find "triple_def"
  fun op signs_def _ = () val op signs_def = TDB.find "signs_def"
  fun op selected_ind _ = () val op selected_ind = TDB.find "selected_ind"
  fun op selected_def _ = () val op selected_def = TDB.find "selected_def"
  fun op raw_to_count_packet_7707 _ = ()
  val op raw_to_count_packet_7707 = TDB.find "raw_to_count_packet_7707"
  fun op raw_to_count_packet_7659 _ = ()
  val op raw_to_count_packet_7659 = TDB.find "raw_to_count_packet_7659"
  fun op raw_to_count_packet_6559 _ = ()
  val op raw_to_count_packet_6559 = TDB.find "raw_to_count_packet_6559"
  fun op raw_to_count_packet_5499 _ = ()
  val op raw_to_count_packet_5499 = TDB.find "raw_to_count_packet_5499"
  fun op raw_7707_def _ = () val op raw_7707_def = TDB.find "raw_7707_def"
  fun op raw_7659_def _ = () val op raw_7659_def = TDB.find "raw_7659_def"
  fun op raw_6559_def _ = () val op raw_6559_def = TDB.find "raw_6559_def"
  fun op raw_5499_def _ = () val op raw_5499_def = TDB.find "raw_5499_def"
  fun op inner_def _ = () val op inner_def = TDB.find "inner_def"
  fun op cv_window_thm _ = ()
  val op cv_window_thm = TDB.find "cv_window_thm"
  fun op cv_window_def _ = ()
  val op cv_window_def = TDB.find "cv_window_def"
  fun op cv_triple_thm _ = ()
  val op cv_triple_thm = TDB.find "cv_triple_thm"
  fun op cv_triple_def _ = ()
  val op cv_triple_def = TDB.find "cv_triple_def"
  fun op cv_signs_thm _ = () val op cv_signs_thm = TDB.find "cv_signs_thm"
  fun op cv_signs_def _ = () val op cv_signs_def = TDB.find "cv_signs_def"
  fun op cv_selected_thm _ = ()
  val op cv_selected_thm = TDB.find "cv_selected_thm"
  fun op cv_selected_def _ = ()
  val op cv_selected_def = TDB.find "cv_selected_def"
  fun op cv_inner_thm _ = () val op cv_inner_thm = TDB.find "cv_inner_thm"
  fun op cv_inner_ind _ = () val op cv_inner_ind = TDB.find "cv_inner_ind"
  fun op cv_inner_def _ = () val op cv_inner_def = TDB.find "cv_inner_def"
  fun op cv_at_three_thm _ = ()
  val op cv_at_three_thm = TDB.find "cv_at_three_thm"
  fun op cv_at_three_def _ = ()
  val op cv_at_three_def = TDB.find "cv_at_three_def"
  fun op cv_LENGTH_thm _ = ()
  val op cv_LENGTH_thm = TDB.find "cv_LENGTH_thm"
  fun op cv_LENGTH_ind _ = ()
  val op cv_LENGTH_ind = TDB.find "cv_LENGTH_ind"
  fun op cv_LENGTH_def_primitive _ = ()
  val op cv_LENGTH_def_primitive = TDB.find "cv_LENGTH_def_primitive"
  fun op cv_LENGTH_def _ = ()
  val op cv_LENGTH_def = TDB.find "cv_LENGTH_def"
  fun op at_three_def _ = () val op at_three_def = TDB.find "at_three_def"
  
val _ = if !Globals.print_thy_loads then TextIO.print "done\n" else ()
val _ = Theory.load_complete "Q10004Window"

end
