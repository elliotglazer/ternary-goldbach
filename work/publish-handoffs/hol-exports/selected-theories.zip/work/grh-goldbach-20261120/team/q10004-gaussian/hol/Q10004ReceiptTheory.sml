structure Q10004ReceiptTheory :> Q10004ReceiptTheory =
struct
  
  val _ = if !Globals.print_thy_loads
    then TextIO.print "Loading Q10004ReceiptTheory ... "
    else ()
  
  open Type Term Thm
  local open Q10004ScanTheory in end;
  
  structure TDB = struct
    val path =
      OS.Path.base (#(FILE)) ^ ".dat"
    val timestamp = HOLFileSys.modTime path
    val thydata = 
      TheoryReader.load_thydata {
        thyname = "Q10004Receipt",
        hash = "d2a732242fe061ec8297447c56667b8f02f02006",
        path = path
      }
    fun find s = #1 (valOf (Symtab.lookup thydata s))
  end
  val () = Theory.record_metadata
    "Q10004Receipt" {timestamp=TDB.timestamp, path=TDB.path}
  
  fun op runs_311_def _ = () val op runs_311_def = TDB.find "runs_311_def"
  fun op runs_311_checked _ = ()
  val op runs_311_checked = TDB.find "runs_311_checked"
  fun op runs_310_def _ = () val op runs_310_def = TDB.find "runs_310_def"
  fun op runs_310_checked _ = ()
  val op runs_310_checked = TDB.find "runs_310_checked"
  fun op runs_301_def _ = () val op runs_301_def = TDB.find "runs_301_def"
  fun op runs_301_checked _ = ()
  val op runs_301_checked = TDB.find "runs_301_checked"
  fun op runs_300_def _ = () val op runs_300_def = TDB.find "runs_300_def"
  fun op runs_300_checked _ = ()
  val op runs_300_checked = TDB.find "runs_300_checked"
  fun op runs_211_def _ = () val op runs_211_def = TDB.find "runs_211_def"
  fun op runs_211_checked _ = ()
  val op runs_211_checked = TDB.find "runs_211_checked"
  fun op runs_210_def _ = () val op runs_210_def = TDB.find "runs_210_def"
  fun op runs_210_checked _ = ()
  val op runs_210_checked = TDB.find "runs_210_checked"
  fun op runs_201_def _ = () val op runs_201_def = TDB.find "runs_201_def"
  fun op runs_201_checked _ = ()
  val op runs_201_checked = TDB.find "runs_201_checked"
  fun op runs_200_def _ = () val op runs_200_def = TDB.find "runs_200_def"
  fun op runs_200_checked _ = ()
  val op runs_200_checked = TDB.find "runs_200_checked"
  fun op runs_111_def _ = () val op runs_111_def = TDB.find "runs_111_def"
  fun op runs_111_checked _ = ()
  val op runs_111_checked = TDB.find "runs_111_checked"
  fun op runs_110_def _ = () val op runs_110_def = TDB.find "runs_110_def"
  fun op runs_110_checked _ = ()
  val op runs_110_checked = TDB.find "runs_110_checked"
  fun op runs_101_def _ = () val op runs_101_def = TDB.find "runs_101_def"
  fun op runs_101_checked _ = ()
  val op runs_101_checked = TDB.find "runs_101_checked"
  fun op runs_100_def _ = () val op runs_100_def = TDB.find "runs_100_def"
  fun op runs_100_checked _ = ()
  val op runs_100_checked = TDB.find "runs_100_checked"
  fun op runs_011_def _ = () val op runs_011_def = TDB.find "runs_011_def"
  fun op runs_011_checked _ = ()
  val op runs_011_checked = TDB.find "runs_011_checked"
  fun op runs_010_def _ = () val op runs_010_def = TDB.find "runs_010_def"
  fun op runs_010_checked _ = ()
  val op runs_010_checked = TDB.find "runs_010_checked"
  fun op runs_001_def _ = () val op runs_001_def = TDB.find "runs_001_def"
  fun op runs_001_checked _ = ()
  val op runs_001_checked = TDB.find "runs_001_checked"
  fun op runs_000_def _ = () val op runs_000_def = TDB.find "runs_000_def"
  fun op runs_000_checked _ = ()
  val op runs_000_checked = TDB.find "runs_000_checked"
  fun op pair_test_def _ = ()
  val op pair_test_def = TDB.find "pair_test_def"
  fun op pair3_full_count_test _ = ()
  val op pair3_full_count_test = TDB.find "pair3_full_count_test"
  fun op pair2_full_count_test _ = ()
  val op pair2_full_count_test = TDB.find "pair2_full_count_test"
  fun op pair1_full_count_test _ = ()
  val op pair1_full_count_test = TDB.find "pair1_full_count_test"
  fun op pair0_full_count_test _ = ()
  val op pair0_full_count_test = TDB.find "pair0_full_count_test"
  fun op cv_pair_test_thm _ = ()
  val op cv_pair_test_thm = TDB.find "cv_pair_test_thm"
  fun op cv_pair_test_def _ = ()
  val op cv_pair_test_def = TDB.find "cv_pair_test_def"
  
val _ = if !Globals.print_thy_loads then TextIO.print "done\n" else ()
val _ = Theory.load_complete "Q10004Receipt"

end
