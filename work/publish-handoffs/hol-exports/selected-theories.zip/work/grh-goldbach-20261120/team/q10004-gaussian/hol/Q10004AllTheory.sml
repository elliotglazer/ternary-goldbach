structure Q10004AllTheory :> Q10004AllTheory =
struct
  
  val _ = if !Globals.print_thy_loads
    then TextIO.print "Loading Q10004AllTheory ... "
    else ()
  
  open Type Term Thm
  local open Q10004WindowTheory in end;
  
  structure TDB = struct
    val path =
      OS.Path.base (#(FILE)) ^ ".dat"
    val timestamp = HOLFileSys.modTime path
    val thydata = 
      TheoryReader.load_thydata {
        thyname = "Q10004All",
        hash = "9a7a9c7127f0c9993ec982b7ff0a407eb7eaf585",
        path = path
      }
    fun find s = #1 (valOf (Symtab.lookup thydata s))
  end
  val () = Theory.record_metadata
    "Q10004All" {timestamp=TDB.timestamp, path=TDB.path}
  
  fun op weights_for_ind _ = ()
  val op weights_for_ind = TDB.find "weights_for_ind"
  fun op weights_for_def _ = ()
  val op weights_for_def = TDB.find "weights_for_def"
  fun op slice_ind _ = () val op slice_ind = TDB.find "slice_ind"
  fun op slice_def _ = () val op slice_def = TDB.find "slice_def"
  fun op shared_kernels_def _ = ()
  val op shared_kernels_def = TDB.find "shared_kernels_def"
  fun op probe_list_7707_def _ = ()
  val op probe_list_7707_def = TDB.find "probe_list_7707_def"
  fun op probe_list_7659_def _ = ()
  val op probe_list_7659_def = TDB.find "probe_list_7659_def"
  fun op probe_list_6559_def _ = ()
  val op probe_list_6559_def = TDB.find "probe_list_6559_def"
  fun op probe_list_5499_def _ = ()
  val op probe_list_5499_def = TDB.find "probe_list_5499_def"
  fun op grid_spans_7707_def _ = ()
  val op grid_spans_7707_def = TDB.find "grid_spans_7707_def"
  fun op grid_spans_7659_def _ = ()
  val op grid_spans_7659_def = TDB.find "grid_spans_7659_def"
  fun op grid_spans_6559_def _ = ()
  val op grid_spans_6559_def = TDB.find "grid_spans_6559_def"
  fun op grid_spans_5499_def _ = ()
  val op grid_spans_5499_def = TDB.find "grid_spans_5499_def"
  fun op cv_weights_for_thm _ = ()
  val op cv_weights_for_thm = TDB.find "cv_weights_for_thm"
  fun op cv_weights_for_def _ = ()
  val op cv_weights_for_def = TDB.find "cv_weights_for_def"
  fun op cv_slice_thm _ = () val op cv_slice_thm = TDB.find "cv_slice_thm"
  fun op cv_slice_def _ = () val op cv_slice_def = TDB.find "cv_slice_def"
  fun op cv_cut_thm _ = () val op cv_cut_thm = TDB.find "cv_cut_thm"
  fun op cv_cut_ind _ = () val op cv_cut_ind = TDB.find "cv_cut_ind"
  fun op cv_cut_def _ = () val op cv_cut_def = TDB.find "cv_cut_def"
  fun op cv_all_jobs_thm _ = ()
  val op cv_all_jobs_thm = TDB.find "cv_all_jobs_thm"
  fun op cv_all_jobs_def _ = ()
  val op cv_all_jobs_def = TDB.find "cv_all_jobs_def"
  fun op cut_def _ = () val op cut_def = TDB.find "cut_def"
  fun op all_jobs_def _ = () val op all_jobs_def = TDB.find "all_jobs_def"
  fun op all_interior_repair_bits_7707 _ = ()
  val op all_interior_repair_bits_7707 = TDB.find
    "all_interior_repair_bits_7707"
  fun op all_interior_repair_bits_7659 _ = ()
  val op all_interior_repair_bits_7659 = TDB.find
    "all_interior_repair_bits_7659"
  fun op all_interior_repair_bits_6559 _ = ()
  val op all_interior_repair_bits_6559 = TDB.find
    "all_interior_repair_bits_6559"
  fun op all_interior_repair_bits_5499 _ = ()
  val op all_interior_repair_bits_5499 = TDB.find
    "all_interior_repair_bits_5499"
  
val _ = if !Globals.print_thy_loads then TextIO.print "done\n" else ()
val _ = Theory.load_complete "Q10004All"

end
