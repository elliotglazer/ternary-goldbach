signature Q10004WindowTheory =
sig
  type thm = Thm.thm
  
  (*  Definitions  *)
    val at_three_def : thm
    val cv_LENGTH_def_primitive : thm
    val cv_at_three_def : thm
    val cv_selected_def : thm
    val cv_signs_def : thm
    val cv_triple_def : thm
    val cv_window_def : thm
    val inner_def : thm
    val raw_5499_def : thm
    val raw_6559_def : thm
    val raw_7659_def : thm
    val raw_7707_def : thm
    val signs_def : thm
    val triple_def : thm
    val weights_5499_def : thm
    val weights_6559_def : thm
    val weights_7659_def : thm
    val weights_7707_def : thm
    val window_def : thm
  
  (*  Theorems  *)
    val cv_LENGTH_def : thm
    val cv_LENGTH_ind : thm
    val cv_LENGTH_thm : thm
    val cv_at_three_thm : thm
    val cv_inner_def : thm
    val cv_inner_ind : thm
    val cv_inner_thm : thm
    val cv_selected_thm : thm
    val cv_signs_thm : thm
    val cv_triple_thm : thm
    val cv_window_thm : thm
    val raw_to_count_packet_5499 : thm
    val raw_to_count_packet_6559 : thm
    val raw_to_count_packet_7659 : thm
    val raw_to_count_packet_7707 : thm
    val selected_def : thm
    val selected_ind : thm
end
