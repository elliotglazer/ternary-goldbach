signature Q10004FusedTheory =
sig
  type thm = Thm.thm
  
  (*  Definitions  *)
    val MAP_lam_int_mul_int_of_num_cut_def : thm
    val accepted_def : thm
    val compact_jobs_def : thm
    val compressed_spans_5499_def : thm
    val compressed_spans_6559_def : thm
    val compressed_spans_7659_def : thm
    val compressed_spans_7707_def : thm
    val cut_def : thm
    val cv_ABS_def : thm
    val cv_accepted_def : thm
    val cv_compact_jobs_def : thm
    val cv_find_span_def : thm
    val cv_normsum_def_primitive : thm
    val cv_projects_def : thm
    val cv_weights_for_def : thm
    val cv_within_def : thm
    val digits_def : thm
    val find_span_def : thm
    val normsum_def : thm
    val probe_list_5499_def : thm
    val probe_list_6559_def : thm
    val probe_list_7659_def : thm
    val probe_list_7707_def : thm
    val shared_kernels_def : thm
    val source_raw_5499_def : thm
    val source_raw_6559_def : thm
    val source_raw_7659_def : thm
    val source_raw_7707_def : thm
    val within_def : thm
    val words_def : thm
  
  (*  Theorems  *)
    val MAP_lam_int_mul_int_of_num_cut_ho : thm
    val cv_ABS_thm : thm
    val cv_APPEND_def : thm
    val cv_APPEND_ind : thm
    val cv_APPEND_thm : thm
    val cv_MAP_lam_int_mul_int_of_num_cut_def : thm
    val cv_MAP_lam_int_mul_int_of_num_cut_ind : thm
    val cv_MAP_lam_int_mul_int_of_num_cut_thm : thm
    val cv_accepted_thm : thm
    val cv_compact_jobs_thm : thm
    val cv_cut_def : thm
    val cv_cut_ind : thm
    val cv_cut_thm : thm
    val cv_digits_def : thm
    val cv_digits_ind : thm
    val cv_digits_thm : thm
    val cv_find_span_thm : thm
    val cv_int_exp_def : thm
    val cv_int_exp_ind : thm
    val cv_int_exp_thm : thm
    val cv_normsum_def : thm
    val cv_normsum_ind : thm
    val cv_normsum_thm : thm
    val cv_projects_thm : thm
    val cv_weights_for_thm : thm
    val cv_within_thm : thm
    val cv_words_def : thm
    val cv_words_ind : thm
    val cv_words_thm : thm
    val digits_compute : thm
    val fused_repair_bits_5499 : thm
    val fused_repair_bits_6559 : thm
    val fused_repair_bits_7659 : thm
    val fused_repair_bits_7707 : thm
    val projects_def : thm
    val projects_ind : thm
    val weights_for_def : thm
    val weights_for_ind : thm
end
