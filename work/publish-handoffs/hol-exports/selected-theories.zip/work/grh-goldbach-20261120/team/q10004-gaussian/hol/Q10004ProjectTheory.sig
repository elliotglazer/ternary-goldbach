signature Q10004ProjectTheory =
sig
  type thm = Thm.thm
  
  (*  Definitions  *)
    val cv_projects_def : thm
    val cv_within_def : thm
    val within_def : thm
  
  (*  Theorems  *)
    val cv_projects_thm : thm
    val cv_within_thm : thm
    val projects_def : thm
    val projects_ind : thm
    val raw_projection_5499 : thm
    val raw_projection_6559 : thm
    val raw_projection_7659 : thm
    val raw_projection_7707 : thm
end
