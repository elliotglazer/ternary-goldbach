structure Q10004ScanTheory :> Q10004ScanTheory =
struct
  
  val _ = if !Globals.print_thy_loads
    then TextIO.print "Loading Q10004ScanTheory ... "
    else ()
  
  open Type Term Thm
  local open cv_primTheory in end;
  
  structure TDB = struct
    val path =
      OS.Path.base (#(FILE)) ^ ".dat"
    val timestamp = HOLFileSys.modTime path
    val thydata = 
      TheoryReader.load_thydata {
        thyname = "Q10004Scan",
        hash = "a115776267b8ddd15145fb583a87f87a8f652e4e",
        path = path
      }
    fun find s = #1 (valOf (Symtab.lookup thydata s))
  end
  val () = Theory.record_metadata
    "Q10004Scan" {timestamp=TDB.timestamp, path=TDB.path}
  
  fun op strict_inequality _ = ()
  val op strict_inequality = TDB.find "strict_inequality"
  fun op steps_def _ = () val op steps_def = TDB.find "steps_def"
  fun op steps_compute _ = ()
  val op steps_compute = TDB.find "steps_compute"
  fun op scan_ind _ = () val op scan_ind = TDB.find "scan_ind"
  fun op scan_def _ = () val op scan_def = TDB.find "scan_def"
  fun op scan_between_def _ = ()
  val op scan_between_def = TDB.find "scan_between_def"
  fun op saturates_def _ = ()
  val op saturates_def = TDB.find "saturates_def"
  fun op exact_count_of_parity _ = ()
  val op exact_count_of_parity = TDB.find "exact_count_of_parity"
  fun op endpoint_parity _ = ()
  val op endpoint_parity = TDB.find "endpoint_parity"
  fun op endpoint_def _ = () val op endpoint_def = TDB.find "endpoint_def"
  fun op cv_steps_thm _ = () val op cv_steps_thm = TDB.find "cv_steps_thm"
  fun op cv_steps_def _ = () val op cv_steps_def = TDB.find "cv_steps_def"
  fun op cv_scan_thm _ = () val op cv_scan_thm = TDB.find "cv_scan_thm"
  fun op cv_scan_def _ = () val op cv_scan_def = TDB.find "cv_scan_def"
  fun op cv_scan_between_thm _ = ()
  val op cv_scan_between_thm = TDB.find "cv_scan_between_thm"
  fun op cv_scan_between_def _ = ()
  val op cv_scan_between_def = TDB.find "cv_scan_between_def"
  fun op cv_saturates_thm _ = ()
  val op cv_saturates_thm = TDB.find "cv_saturates_thm"
  fun op cv_saturates_def _ = ()
  val op cv_saturates_def = TDB.find "cv_saturates_def"
  fun op cv_rep_pair_datatype _ = ()
  val op cv_rep_pair_datatype = TDB.find "cv_rep_pair_datatype"
  fun op cv_rep_option_datatype _ = ()
  val op cv_rep_option_datatype = TDB.find "cv_rep_option_datatype"
  fun op cv_rep_list_datatype _ = ()
  val op cv_rep_list_datatype = TDB.find "cv_rep_list_datatype"
  
val _ = if !Globals.print_thy_loads then TextIO.print "done\n" else ()
val _ = Theory.load_complete "Q10004Scan"

end
