structure PanelJoinTheory :> PanelJoinTheory =
struct
  
  val _ = if !Globals.print_thy_loads
    then TextIO.print "Loading PanelJoinTheory ... "
    else ()
  
  open Type Term Thm
  local open PanelBatchTheory PanelUnaryTheory in end;
  
  structure TDB = struct
    val path =
      OS.Path.base (#(FILE)) ^ ".dat"
    val timestamp = HOLFileSys.modTime path
    val thydata = 
      TheoryReader.load_thydata {
        thyname = "PanelJoin",
        hash = "1d89f437ea1e23572b4532ba37beb92dd34545c0",
        path = path
      }
    fun find s = #1 (valOf (Symtab.lookup thydata s))
  end
  val () = Theory.record_metadata
    "PanelJoin" {timestamp=TDB.timestamp, path=TDB.path}
  
  fun op same_270_from_unary _ = ()
  val op same_270_from_unary = TDB.find "same_270_from_unary"
  fun op panels_append _ = ()
  val op panels_append = TDB.find "panels_append"
  
val _ = if !Globals.print_thy_loads then TextIO.print "done\n" else ()
val _ = Theory.load_complete "PanelJoin"

end
