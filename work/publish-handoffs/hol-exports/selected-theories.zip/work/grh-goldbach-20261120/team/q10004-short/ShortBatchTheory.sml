structure ShortBatchTheory :> ShortBatchTheory =
struct
  
  val _ = if !Globals.print_thy_loads
    then TextIO.print "Loading ShortBatchTheory ... "
    else ()
  
  open Type Term Thm
  local open ShortKernelTheory in end;
  
  structure TDB = struct
    val path =
      OS.Path.base (#(FILE)) ^ ".dat"
    val timestamp = HOLFileSys.modTime path
    val thydata = 
      TheoryReader.load_thydata {
        thyname = "ShortBatch",
        hash = "7b124dd50aa6bffaa53e8de3823ad5214a3a4fd7",
        path = path
      }
    fun find s = #1 (valOf (Symtab.lookup thydata s))
  end
  val () = Theory.record_metadata
    "ShortBatch" {timestamp=TDB.timestamp, path=TDB.path}
  
  fun op weights_exact _ = ()
  val op weights_exact = TDB.find "weights_exact"
  fun op source_0_def _ = () val op source_0_def = TDB.find "source_0_def"
  fun op kernels_def _ = () val op kernels_def = TDB.find "kernels_def"
  fun op checked_0 _ = () val op checked_0 = TDB.find "checked_0"
  
val _ = if !Globals.print_thy_loads then TextIO.print "done\n" else ()
val _ = Theory.load_complete "ShortBatch"

end
