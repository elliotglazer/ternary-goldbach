signature ShortKernelTheory =
sig
  type thm = Thm.thm
  
  (*  Definitions  *)
    val cv_ABS_def : thm
    val cv_find_def : thm
    val cv_short_all_def : thm
    val cv_short_def : thm
    val cv_weight_ok_def : thm
    val cv_weights_def : thm
    val find_def : thm
    val product16_def : thm
    val short_all_def : thm
    val short_def : thm
    val sourcefold_def : thm
    val weight_ok_def : thm
    val weights_def : thm
  
  (*  Theorems  *)
    val cv_ABS_thm : thm
    val cv_find_thm : thm
    val cv_product16_def : thm
    val cv_product16_ind : thm
    val cv_product16_thm : thm
    val cv_short_all_thm : thm
    val cv_short_thm : thm
    val cv_sourcefold_def : thm
    val cv_sourcefold_ind : thm
    val cv_sourcefold_thm : thm
    val cv_weight_ok_thm : thm
    val cv_weights_thm : thm
    val product16_compute : thm
end
