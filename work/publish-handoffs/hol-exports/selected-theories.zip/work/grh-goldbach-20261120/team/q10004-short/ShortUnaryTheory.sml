structure ShortUnaryTheory :> ShortUnaryTheory =
struct
  
  val _ = if !Globals.print_thy_loads
    then TextIO.print "Loading ShortUnaryTheory ... "
    else ()
  
  open Type Term Thm
  local open ShortKernelTheory in end;
  
  structure TDB = struct
    val path =
      OS.Path.base (#(FILE)) ^ ".dat"
    val timestamp = HOLFileSys.modTime path
    val thydata = 
      TheoryReader.load_thydata {
        thyname = "ShortUnary",
        hash = "c2e92d75aa352f5817f50ee160860c8f413e0b66",
        path = path
      }
    fun find s = #1 (valOf (Symtab.lookup thydata s))
  end
  val () = Theory.record_metadata
    "ShortUnary" {timestamp=TDB.timestamp, path=TDB.path}
  
  fun op weights_exact _ = ()
  val op weights_exact = TDB.find "weights_exact"
  fun op source_9_def _ = () val op source_9_def = TDB.find "source_9_def"
  fun op source_8_def _ = () val op source_8_def = TDB.find "source_8_def"
  fun op source_7_def _ = () val op source_7_def = TDB.find "source_7_def"
  fun op source_6_def _ = () val op source_6_def = TDB.find "source_6_def"
  fun op source_5_def _ = () val op source_5_def = TDB.find "source_5_def"
  fun op source_4_def _ = () val op source_4_def = TDB.find "source_4_def"
  fun op source_3_def _ = () val op source_3_def = TDB.find "source_3_def"
  fun op source_2_def _ = () val op source_2_def = TDB.find "source_2_def"
  fun op source_1_def _ = () val op source_1_def = TDB.find "source_1_def"
  fun op source_12_def _ = ()
  val op source_12_def = TDB.find "source_12_def"
  fun op source_11_def _ = ()
  val op source_11_def = TDB.find "source_11_def"
  fun op source_10_def _ = ()
  val op source_10_def = TDB.find "source_10_def"
  fun op source_0_def _ = () val op source_0_def = TDB.find "source_0_def"
  fun op kernels_def _ = () val op kernels_def = TDB.find "kernels_def"
  fun op checked_9 _ = () val op checked_9 = TDB.find "checked_9"
  fun op checked_8 _ = () val op checked_8 = TDB.find "checked_8"
  fun op checked_7 _ = () val op checked_7 = TDB.find "checked_7"
  fun op checked_6 _ = () val op checked_6 = TDB.find "checked_6"
  fun op checked_5 _ = () val op checked_5 = TDB.find "checked_5"
  fun op checked_4 _ = () val op checked_4 = TDB.find "checked_4"
  fun op checked_3 _ = () val op checked_3 = TDB.find "checked_3"
  fun op checked_2 _ = () val op checked_2 = TDB.find "checked_2"
  fun op checked_12 _ = () val op checked_12 = TDB.find "checked_12"
  fun op checked_11 _ = () val op checked_11 = TDB.find "checked_11"
  fun op checked_10 _ = () val op checked_10 = TDB.find "checked_10"
  fun op checked_1 _ = () val op checked_1 = TDB.find "checked_1"
  fun op checked_0 _ = () val op checked_0 = TDB.find "checked_0"
  
val _ = if !Globals.print_thy_loads then TextIO.print "done\n" else ()
val _ = Theory.load_complete "ShortUnary"

end
