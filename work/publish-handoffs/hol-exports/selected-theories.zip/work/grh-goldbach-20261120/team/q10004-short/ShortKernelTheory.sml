structure ShortKernelTheory :> ShortKernelTheory =
struct
  
  val _ = if !Globals.print_thy_loads
    then TextIO.print "Loading ShortKernelTheory ... "
    else ()
  
  open Type Term Thm
  local open cv_stdTheory in end;
  
  structure TDB = struct
    val path =
      OS.Path.base (#(FILE)) ^ ".dat"
    val timestamp = HOLFileSys.modTime path
    val thydata = 
      TheoryReader.load_thydata {
        thyname = "ShortKernel",
        hash = "82fc66dfc7650faac6cc3540a502b8688a8e592f",
        path = path
      }
    fun find s = #1 (valOf (Symtab.lookup thydata s))
  end
  val () = Theory.record_metadata
    "ShortKernel" {timestamp=TDB.timestamp, path=TDB.path}
  
  fun op weights_def _ = () val op weights_def = TDB.find "weights_def"
  fun op weight_ok_def _ = ()
  val op weight_ok_def = TDB.find "weight_ok_def"
  fun op sourcefold_def _ = ()
  val op sourcefold_def = TDB.find "sourcefold_def"
  fun op short_def _ = () val op short_def = TDB.find "short_def"
  fun op short_all_def _ = ()
  val op short_all_def = TDB.find "short_all_def"
  fun op product16_def _ = ()
  val op product16_def = TDB.find "product16_def"
  fun op product16_compute _ = ()
  val op product16_compute = TDB.find "product16_compute"
  fun op find_def _ = () val op find_def = TDB.find "find_def"
  fun op cv_weights_thm _ = ()
  val op cv_weights_thm = TDB.find "cv_weights_thm"
  fun op cv_weights_def _ = ()
  val op cv_weights_def = TDB.find "cv_weights_def"
  fun op cv_weight_ok_thm _ = ()
  val op cv_weight_ok_thm = TDB.find "cv_weight_ok_thm"
  fun op cv_weight_ok_def _ = ()
  val op cv_weight_ok_def = TDB.find "cv_weight_ok_def"
  fun op cv_sourcefold_thm _ = ()
  val op cv_sourcefold_thm = TDB.find "cv_sourcefold_thm"
  fun op cv_sourcefold_ind _ = ()
  val op cv_sourcefold_ind = TDB.find "cv_sourcefold_ind"
  fun op cv_sourcefold_def _ = ()
  val op cv_sourcefold_def = TDB.find "cv_sourcefold_def"
  fun op cv_short_thm _ = () val op cv_short_thm = TDB.find "cv_short_thm"
  fun op cv_short_def _ = () val op cv_short_def = TDB.find "cv_short_def"
  fun op cv_short_all_thm _ = ()
  val op cv_short_all_thm = TDB.find "cv_short_all_thm"
  fun op cv_short_all_def _ = ()
  val op cv_short_all_def = TDB.find "cv_short_all_def"
  fun op cv_product16_thm _ = ()
  val op cv_product16_thm = TDB.find "cv_product16_thm"
  fun op cv_product16_ind _ = ()
  val op cv_product16_ind = TDB.find "cv_product16_ind"
  fun op cv_product16_def _ = ()
  val op cv_product16_def = TDB.find "cv_product16_def"
  fun op cv_find_thm _ = () val op cv_find_thm = TDB.find "cv_find_thm"
  fun op cv_find_def _ = () val op cv_find_def = TDB.find "cv_find_def"
  fun op cv_ABS_thm _ = () val op cv_ABS_thm = TDB.find "cv_ABS_thm"
  fun op cv_ABS_def _ = () val op cv_ABS_def = TDB.find "cv_ABS_def"
  
val _ = if !Globals.print_thy_loads then TextIO.print "done\n" else ()
val _ = Theory.load_complete "ShortKernel"

end
