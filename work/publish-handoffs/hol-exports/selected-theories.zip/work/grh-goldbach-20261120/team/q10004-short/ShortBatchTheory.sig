signature ShortBatchTheory =
sig
  type thm = Thm.thm
  
  (*  Definitions  *)
    val kernels_def : thm
    val source_0_def : thm
  
  (*  Theorems  *)
    val checked_0 : thm
    val weights_exact : thm
end
