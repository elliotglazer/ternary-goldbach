signature ActualSignTheory =
sig
  type thm = Thm.thm
  
  (*  Definitions  *)
    val actual_def : thm
  
  (*  Theorems  *)
    val actual_metrics : thm
    val actual_radius : thm
    val q10000_label3_tick8010240_negative : thm
end
