signature PanelBatchTheory =
sig
  type thm = Thm.thm
  
  (*  Definitions  *)
    val tsv_0_def : thm
  
  (*  Theorems  *)
    val proved_0 : thm
end
