structure PanelBatchTheory :> PanelBatchTheory =
struct
  
  val _ = if !Globals.print_thy_loads
    then TextIO.print "Loading PanelBatchTheory ... "
    else ()
  
  open Type Term Thm
  local open PanelKernelTheory in end;
  
  structure TDB = struct
    val path =
      OS.Path.base (#(FILE)) ^ ".dat"
    val timestamp = HOLFileSys.modTime path
    val thydata = 
      TheoryReader.load_thydata {
        thyname = "PanelBatch",
        hash = "0b600a1c2bce72100edc50294ad59d1121891c6c",
        path = path
      }
    fun find s = #1 (valOf (Symtab.lookup thydata s))
  end
  val () = Theory.record_metadata
    "PanelBatch" {timestamp=TDB.timestamp, path=TDB.path}
  
  fun op tsv_0_def _ = () val op tsv_0_def = TDB.find "tsv_0_def"
  fun op proved_0 _ = () val op proved_0 = TDB.find "proved_0"
  
val _ = if !Globals.print_thy_loads then TextIO.print "done\n" else ()
val _ = Theory.load_complete "PanelBatch"

end
