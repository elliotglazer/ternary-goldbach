structure ActualSignTheory :> ActualSignTheory =
struct
  
  val _ = if !Globals.print_thy_loads
    then TextIO.print "Loading ActualSignTheory ... "
    else ()
  
  open Type Term Thm
  local open CompactSignTheory PanelBatchTheory in end;
  
  structure TDB = struct
    val path =
      OS.Path.base (#(FILE)) ^ ".dat"
    val timestamp = HOLFileSys.modTime path
    val thydata = 
      TheoryReader.load_thydata {
        thyname = "ActualSign",
        hash = "8280d370171899f974bf6218461e158bf6a0985f",
        path = path
      }
    fun find s = #1 (valOf (Symtab.lookup thydata s))
  end
  val () = Theory.record_metadata
    "ActualSign" {timestamp=TDB.timestamp, path=TDB.path}
  
  fun op q10000_label3_tick8010240_negative _ = ()
  val op q10000_label3_tick8010240_negative = TDB.find
    "q10000_label3_tick8010240_negative"
  fun op actual_radius _ = ()
  val op actual_radius = TDB.find "actual_radius"
  fun op actual_metrics _ = ()
  val op actual_metrics = TDB.find "actual_metrics"
  fun op actual_def _ = () val op actual_def = TDB.find "actual_def"
  
val _ = if !Globals.print_thy_loads then TextIO.print "done\n" else ()
val _ = Theory.load_complete "ActualSign"

end
