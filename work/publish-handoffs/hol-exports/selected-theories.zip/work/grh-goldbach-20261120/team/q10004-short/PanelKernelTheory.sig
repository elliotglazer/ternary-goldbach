signature PanelKernelTheory =
sig
  type thm = Thm.thm
  
  (*  Definitions  *)
    val checkdot_def : thm
    val cv_panel_def : thm
    val cv_panels_def : thm
    val panel_def : thm
    val panels_def : thm
    val partition12_def : thm
  
  (*  Theorems  *)
    val cv_checkdot_def : thm
    val cv_checkdot_ind : thm
    val cv_checkdot_thm : thm
    val cv_panel_thm : thm
    val cv_panels_thm : thm
    val cv_partition12_def : thm
    val cv_partition12_ind : thm
    val cv_partition12_thm : thm
    val partition12_compute : thm
end
