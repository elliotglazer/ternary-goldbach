signature PanelJoinTheory =
sig
  type thm = Thm.thm
  
  (*  Theorems  *)
    val panels_append : thm
    val same_270_from_unary : thm
end
