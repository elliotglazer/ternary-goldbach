structure PanelKernelTheory :> PanelKernelTheory =
struct
  
  val _ = if !Globals.print_thy_loads
    then TextIO.print "Loading PanelKernelTheory ... "
    else ()
  
  open Type Term Thm
  local open ShortKernelTheory in end;
  
  structure TDB = struct
    val path =
      OS.Path.base (#(FILE)) ^ ".dat"
    val timestamp = HOLFileSys.modTime path
    val thydata = 
      TheoryReader.load_thydata {
        thyname = "PanelKernel",
        hash = "d9e2a7b860095d88ce9ef9feb1077f45d249809d",
        path = path
      }
    fun find s = #1 (valOf (Symtab.lookup thydata s))
  end
  val () = Theory.record_metadata
    "PanelKernel" {timestamp=TDB.timestamp, path=TDB.path}
  
  fun op partition12_def _ = ()
  val op partition12_def = TDB.find "partition12_def"
  fun op partition12_compute _ = ()
  val op partition12_compute = TDB.find "partition12_compute"
  fun op panels_def _ = () val op panels_def = TDB.find "panels_def"
  fun op panel_def _ = () val op panel_def = TDB.find "panel_def"
  fun op cv_partition12_thm _ = ()
  val op cv_partition12_thm = TDB.find "cv_partition12_thm"
  fun op cv_partition12_ind _ = ()
  val op cv_partition12_ind = TDB.find "cv_partition12_ind"
  fun op cv_partition12_def _ = ()
  val op cv_partition12_def = TDB.find "cv_partition12_def"
  fun op cv_panels_thm _ = ()
  val op cv_panels_thm = TDB.find "cv_panels_thm"
  fun op cv_panels_def _ = ()
  val op cv_panels_def = TDB.find "cv_panels_def"
  fun op cv_panel_thm _ = () val op cv_panel_thm = TDB.find "cv_panel_thm"
  fun op cv_panel_def _ = () val op cv_panel_def = TDB.find "cv_panel_def"
  fun op cv_checkdot_thm _ = ()
  val op cv_checkdot_thm = TDB.find "cv_checkdot_thm"
  fun op cv_checkdot_ind _ = ()
  val op cv_checkdot_ind = TDB.find "cv_checkdot_ind"
  fun op cv_checkdot_def _ = ()
  val op cv_checkdot_def = TDB.find "cv_checkdot_def"
  fun op checkdot_def _ = () val op checkdot_def = TDB.find "checkdot_def"
  
val _ = if !Globals.print_thy_loads then TextIO.print "done\n" else ()
val _ = Theory.load_complete "PanelKernel"

end
