signature ShortUnaryTheory =
sig
  type thm = Thm.thm
  
  (*  Definitions  *)
    val kernels_def : thm
    val source_0_def : thm
    val source_10_def : thm
    val source_11_def : thm
    val source_12_def : thm
    val source_1_def : thm
    val source_2_def : thm
    val source_3_def : thm
    val source_4_def : thm
    val source_5_def : thm
    val source_6_def : thm
    val source_7_def : thm
    val source_8_def : thm
    val source_9_def : thm
  
  (*  Theorems  *)
    val checked_0 : thm
    val checked_1 : thm
    val checked_10 : thm
    val checked_11 : thm
    val checked_12 : thm
    val checked_2 : thm
    val checked_3 : thm
    val checked_4 : thm
    val checked_5 : thm
    val checked_6 : thm
    val checked_7 : thm
    val checked_8 : thm
    val checked_9 : thm
    val weights_exact : thm
end
