signature Q265800ReceiptTheory =
sig
  type thm = Thm.thm
  
  (*  Definitions  *)
    val cv_pair_test_def : thm
    val pair_test_def : thm
    val runs_000_def : thm
    val runs_001_def : thm
    val runs_010_def : thm
    val runs_011_def : thm
    val runs_100_def : thm
    val runs_101_def : thm
    val runs_110_def : thm
    val runs_111_def : thm
    val runs_200_def : thm
    val runs_201_def : thm
    val runs_210_def : thm
    val runs_211_def : thm
    val runs_300_def : thm
    val runs_301_def : thm
    val runs_310_def : thm
    val runs_311_def : thm
  
  (*  Theorems  *)
    val cv_pair_test_thm : thm
    val pair0_full_count_test : thm
    val pair1_full_count_test : thm
    val pair2_full_count_test : thm
    val pair3_full_count_test : thm
    val runs_000_checked : thm
    val runs_001_checked : thm
    val runs_010_checked : thm
    val runs_011_checked : thm
    val runs_100_checked : thm
    val runs_101_checked : thm
    val runs_110_checked : thm
    val runs_111_checked : thm
    val runs_200_checked : thm
    val runs_201_checked : thm
    val runs_210_checked : thm
    val runs_211_checked : thm
    val runs_300_checked : thm
    val runs_301_checked : thm
    val runs_310_checked : thm
    val runs_311_checked : thm
end
