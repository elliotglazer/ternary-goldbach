signature Q265800ScanTheory =
sig
  type thm = Thm.thm
  
  (*  Definitions  *)
    val cv_saturates_def : thm
    val cv_scan_between_def : thm
    val cv_scan_def : thm
    val cv_steps_def : thm
    val endpoint_def : thm
    val saturates_def : thm
    val scan_between_def : thm
    val steps_def : thm
  
  (*  Theorems  *)
    val cv_rep_list_datatype : thm
    val cv_rep_option_datatype : thm
    val cv_rep_pair_datatype : thm
    val cv_saturates_thm : thm
    val cv_scan_between_thm : thm
    val cv_scan_thm : thm
    val cv_steps_thm : thm
    val endpoint_parity : thm
    val exact_count_of_parity : thm
    val scan_def : thm
    val scan_ind : thm
    val steps_compute : thm
    val strict_inequality : thm
end
