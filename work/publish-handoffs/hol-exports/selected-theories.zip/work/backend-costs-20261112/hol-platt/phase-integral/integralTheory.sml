structure integralTheory :> integralTheory =
struct
  
  val _ = if !Globals.print_thy_loads
    then TextIO.print "Loading integralTheory ... "
    else ()
  
  open Type Term Thm
  local open integrationTheory powserTheory in end;
  
  structure TDB = struct
    val path =
      OS.Path.base (#(FILE)) ^ ".dat"
    val timestamp = HOLFileSys.modTime path
    val thydata = 
      TheoryReader.load_thydata {
        thyname = "integral",
        hash = "4923cbe1d3258510e183d7655910474700cf7458",
        path = path
      }
    fun find s = #1 (valOf (Symtab.lookup thydata s))
  end
  val () = Theory.record_metadata
    "integral" {timestamp=TDB.timestamp, path=TDB.path}
  
  fun op tdiv _ = () val op tdiv = TDB.find "tdiv"
  fun op rsum _ = () val op rsum = TDB.find "rsum"
  fun op integral_old_to_new _ = ()
  val op integral_old_to_new = TDB.find "integral_old_to_new"
  fun op integral_new_to_old _ = ()
  val op integral_new_to_old = TDB.find "integral_new_to_old"
  fun op integral _ = () val op integral = TDB.find "integral"
  fun op integrable_eq_integrable_on _ = ()
  val op integrable_eq_integrable_on = TDB.find
    "integrable_eq_integrable_on"
  fun op integrable _ = () val op integrable = TDB.find "integrable"
  fun op gauge_alt_univ _ = ()
  val op gauge_alt_univ = TDB.find "gauge_alt_univ"
  fun op gauge_alt _ = () val op gauge_alt = TDB.find "gauge_alt"
  fun op gauge' _ = () val op gauge' = TDB.find "gauge'"
  fun op gauge _ = () val op gauge = TDB.find "gauge"
  fun op fine _ = () val op fine = TDB.find "fine"
  fun op dsize _ = () val op dsize = TDB.find "dsize"
  fun op division _ = () val op division = TDB.find "division"
  fun op TDIV_LE _ = () val op TDIV_LE = TDB.find "TDIV_LE"
  fun op TDIV_BOUNDS _ = () val op TDIV_BOUNDS = TDB.find "TDIV_BOUNDS"
  fun op SUP_INTERVAL _ = () val op SUP_INTERVAL = TDB.find "SUP_INTERVAL"
  fun op STRADDLE_LEMMA _ = ()
  val op STRADDLE_LEMMA = TDB.find "STRADDLE_LEMMA"
  fun op RSUM_DIFF_BOUND _ = ()
  val op RSUM_DIFF_BOUND = TDB.find "RSUM_DIFF_BOUND"
  fun op RSUM_BOUND _ = () val op RSUM_BOUND = TDB.find "RSUM_BOUND"
  fun op INTEGRATION_BY_PARTS _ = ()
  val op INTEGRATION_BY_PARTS = TDB.find "INTEGRATION_BY_PARTS"
  fun op INTEGRAL_SUB _ = () val op INTEGRAL_SUB = TDB.find "INTEGRAL_SUB"
  fun op INTEGRAL_NULL _ = ()
  val op INTEGRAL_NULL = TDB.find "INTEGRAL_NULL"
  fun op INTEGRAL_MVT1 _ = ()
  val op INTEGRAL_MVT1 = TDB.find "INTEGRAL_MVT1"
  fun op INTEGRAL_LE _ = () val op INTEGRAL_LE = TDB.find "INTEGRAL_LE"
  fun op INTEGRAL_EQ _ = () val op INTEGRAL_EQ = TDB.find "INTEGRAL_EQ"
  fun op INTEGRAL_CONST _ = ()
  val op INTEGRAL_CONST = TDB.find "INTEGRAL_CONST"
  fun op INTEGRAL_COMBINE _ = ()
  val op INTEGRAL_COMBINE = TDB.find "INTEGRAL_COMBINE"
  fun op INTEGRAL_CMUL _ = ()
  val op INTEGRAL_CMUL = TDB.find "INTEGRAL_CMUL"
  fun op INTEGRAL_BY_PARTS _ = ()
  val op INTEGRAL_BY_PARTS = TDB.find "INTEGRAL_BY_PARTS"
  fun op INTEGRAL_ADD _ = () val op INTEGRAL_ADD = TDB.find "INTEGRAL_ADD"
  fun op INTEGRAL_0 _ = () val op INTEGRAL_0 = TDB.find "INTEGRAL_0"
  fun op INTEGRABLE_SUBINTERVAL_RIGHT _ = ()
  val op INTEGRABLE_SUBINTERVAL_RIGHT = TDB.find
    "INTEGRABLE_SUBINTERVAL_RIGHT"
  fun op INTEGRABLE_SUBINTERVAL_LEFT _ = ()
  val op INTEGRABLE_SUBINTERVAL_LEFT = TDB.find
    "INTEGRABLE_SUBINTERVAL_LEFT"
  fun op INTEGRABLE_SUBINTERVAL _ = ()
  val op INTEGRABLE_SUBINTERVAL = TDB.find "INTEGRABLE_SUBINTERVAL"
  fun op INTEGRABLE_SPLIT_SIDES _ = ()
  val op INTEGRABLE_SPLIT_SIDES = TDB.find "INTEGRABLE_SPLIT_SIDES"
  fun op INTEGRABLE_POINT_SPIKE _ = ()
  val op INTEGRABLE_POINT_SPIKE = TDB.find "INTEGRABLE_POINT_SPIKE"
  fun op INTEGRABLE_LIMIT _ = ()
  val op INTEGRABLE_LIMIT = TDB.find "INTEGRABLE_LIMIT"
  fun op INTEGRABLE_DINT _ = ()
  val op INTEGRABLE_DINT = TDB.find "INTEGRABLE_DINT"
  fun op INTEGRABLE_CONTINUOUS _ = ()
  val op INTEGRABLE_CONTINUOUS = TDB.find "INTEGRABLE_CONTINUOUS"
  fun op INTEGRABLE_CONST _ = ()
  val op INTEGRABLE_CONST = TDB.find "INTEGRABLE_CONST"
  fun op INTEGRABLE_COMBINE _ = ()
  val op INTEGRABLE_COMBINE = TDB.find "INTEGRABLE_COMBINE"
  fun op INTEGRABLE_CMUL _ = ()
  val op INTEGRABLE_CMUL = TDB.find "INTEGRABLE_CMUL"
  fun op INTEGRABLE_CAUCHY _ = ()
  val op INTEGRABLE_CAUCHY = TDB.find "INTEGRABLE_CAUCHY"
  fun op INTEGRABLE_ADD _ = ()
  val op INTEGRABLE_ADD = TDB.find "INTEGRABLE_ADD"
  fun op GAUGE_MIN_FINITE _ = ()
  val op GAUGE_MIN_FINITE = TDB.find "GAUGE_MIN_FINITE"
  fun op GAUGE_MIN _ = () val op GAUGE_MIN = TDB.find "GAUGE_MIN"
  fun op FTC1 _ = () val op FTC1 = TDB.find "FTC1"
  fun op FINE_MIN _ = () val op FINE_MIN = TDB.find "FINE_MIN"
  fun op Dint_has_integral _ = ()
  val op Dint_has_integral = TDB.find "Dint_has_integral"
  fun op Dint _ = () val op Dint = TDB.find "Dint"
  fun op DSIZE_EQ _ = () val op DSIZE_EQ = TDB.find "DSIZE_EQ"
  fun op DIVISION_UBOUND_LT _ = ()
  val op DIVISION_UBOUND_LT = TDB.find "DIVISION_UBOUND_LT"
  fun op DIVISION_UBOUND _ = ()
  val op DIVISION_UBOUND = TDB.find "DIVISION_UBOUND"
  fun op DIVISION_THM _ = () val op DIVISION_THM = TDB.find "DIVISION_THM"
  fun op DIVISION_SINGLE _ = ()
  val op DIVISION_SINGLE = TDB.find "DIVISION_SINGLE"
  fun op DIVISION_RHS _ = () val op DIVISION_RHS = TDB.find "DIVISION_RHS"
  fun op DIVISION_MONO_LE_SUC _ = ()
  val op DIVISION_MONO_LE_SUC = TDB.find "DIVISION_MONO_LE_SUC"
  fun op DIVISION_MONO_LE _ = ()
  val op DIVISION_MONO_LE = TDB.find "DIVISION_MONO_LE"
  fun op DIVISION_LT_GEN _ = ()
  val op DIVISION_LT_GEN = TDB.find "DIVISION_LT_GEN"
  fun op DIVISION_LT _ = () val op DIVISION_LT = TDB.find "DIVISION_LT"
  fun op DIVISION_LHS _ = () val op DIVISION_LHS = TDB.find "DIVISION_LHS"
  fun op DIVISION_LE_SUC _ = ()
  val op DIVISION_LE_SUC = TDB.find "DIVISION_LE_SUC"
  fun op DIVISION_LE _ = () val op DIVISION_LE = TDB.find "DIVISION_LE"
  fun op DIVISION_LBOUND_LT _ = ()
  val op DIVISION_LBOUND_LT = TDB.find "DIVISION_LBOUND_LT"
  fun op DIVISION_LBOUND _ = ()
  val op DIVISION_LBOUND = TDB.find "DIVISION_LBOUND"
  fun op DIVISION_INTERMEDIATE' _ = ()
  val op DIVISION_INTERMEDIATE' = TDB.find "DIVISION_INTERMEDIATE'"
  fun op DIVISION_INTERMEDIATE _ = ()
  val op DIVISION_INTERMEDIATE = TDB.find "DIVISION_INTERMEDIATE"
  fun op DIVISION_GT _ = () val op DIVISION_GT = TDB.find "DIVISION_GT"
  fun op DIVISION_EXISTS _ = ()
  val op DIVISION_EXISTS = TDB.find "DIVISION_EXISTS"
  fun op DIVISION_EQ _ = () val op DIVISION_EQ = TDB.find "DIVISION_EQ"
  fun op DIVISION_DSIZE_LE _ = ()
  val op DIVISION_DSIZE_LE = TDB.find "DIVISION_DSIZE_LE"
  fun op DIVISION_DSIZE_GE _ = ()
  val op DIVISION_DSIZE_GE = TDB.find "DIVISION_DSIZE_GE"
  fun op DIVISION_DSIZE_EQ_ALT _ = ()
  val op DIVISION_DSIZE_EQ_ALT = TDB.find "DIVISION_DSIZE_EQ_ALT"
  fun op DIVISION_DSIZE_EQ _ = ()
  val op DIVISION_DSIZE_EQ = TDB.find "DIVISION_DSIZE_EQ"
  fun op DIVISION_BOUNDS _ = ()
  val op DIVISION_BOUNDS = TDB.find "DIVISION_BOUNDS"
  fun op DIVISION_APPEND_STRONG _ = ()
  val op DIVISION_APPEND_STRONG = TDB.find "DIVISION_APPEND_STRONG"
  fun op DIVISION_APPEND _ = ()
  val op DIVISION_APPEND = TDB.find "DIVISION_APPEND"
  fun op DIVISION_1 _ = () val op DIVISION_1 = TDB.find "DIVISION_1"
  fun op DIVISION_0 _ = () val op DIVISION_0 = TDB.find "DIVISION_0"
  fun op DINT_WRONG _ = () val op DINT_WRONG = TDB.find "DINT_WRONG"
  fun op DINT_UNIQ _ = () val op DINT_UNIQ = TDB.find "DINT_UNIQ"
  fun op DINT_TRIANGLE _ = ()
  val op DINT_TRIANGLE = TDB.find "DINT_TRIANGLE"
  fun op DINT_SUB _ = () val op DINT_SUB = TDB.find "DINT_SUB"
  fun op DINT_POINT_SPIKE _ = ()
  val op DINT_POINT_SPIKE = TDB.find "DINT_POINT_SPIKE"
  fun op DINT_NEG _ = () val op DINT_NEG = TDB.find "DINT_NEG"
  fun op DINT_LINEAR _ = () val op DINT_LINEAR = TDB.find "DINT_LINEAR"
  fun op DINT_LE _ = () val op DINT_LE = TDB.find "DINT_LE"
  fun op DINT_INTEGRAL _ = ()
  val op DINT_INTEGRAL = TDB.find "DINT_INTEGRAL"
  fun op DINT_FINITE_SPIKE _ = ()
  val op DINT_FINITE_SPIKE = TDB.find "DINT_FINITE_SPIKE"
  fun op DINT_EQ _ = () val op DINT_EQ = TDB.find "DINT_EQ"
  fun op DINT_DELTA_RIGHT _ = ()
  val op DINT_DELTA_RIGHT = TDB.find "DINT_DELTA_RIGHT"
  fun op DINT_DELTA_LEFT _ = ()
  val op DINT_DELTA_LEFT = TDB.find "DINT_DELTA_LEFT"
  fun op DINT_DELTA _ = () val op DINT_DELTA = TDB.find "DINT_DELTA"
  fun op DINT_CONST _ = () val op DINT_CONST = TDB.find "DINT_CONST"
  fun op DINT_COMBINE _ = () val op DINT_COMBINE = TDB.find "DINT_COMBINE"
  fun op DINT_CMUL _ = () val op DINT_CMUL = TDB.find "DINT_CMUL"
  fun op DINT_ADD _ = () val op DINT_ADD = TDB.find "DINT_ADD"
  fun op DINT_0 _ = () val op DINT_0 = TDB.find "DINT_0"
  fun op CONT_UNIFORM _ = () val op CONT_UNIFORM = TDB.find "CONT_UNIFORM"
  
val _ = if !Globals.print_thy_loads then TextIO.print "done\n" else ()
val _ = Theory.load_complete "integral"

end
