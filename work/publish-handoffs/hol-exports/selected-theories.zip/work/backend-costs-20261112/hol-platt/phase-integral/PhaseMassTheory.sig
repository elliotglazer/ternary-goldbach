signature PhaseMassTheory =
sig
  type thm = Thm.thm
  
  (*  Definitions  *)
    val pm_cutoff_def : thm
    val pm_den_def : thm
    val pm_slope_def : thm
  
  (*  Theorems  *)
    val cutoff_bound : thm
    val cutoff_mono : thm
    val finite_mass_bound : thm
    val improper_mass_bound : thm
    val kernel_integral_exists : thm
    val pm_dominates : thm
    val pm_positive : thm
    val pm_primitive : thm
    val positive_mass_sup_bound : thm
end
