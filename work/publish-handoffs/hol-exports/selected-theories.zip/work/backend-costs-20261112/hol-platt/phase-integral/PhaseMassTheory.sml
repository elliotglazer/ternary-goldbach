structure PhaseMassTheory :> PhaseMassTheory =
struct
  
  val _ = if !Globals.print_thy_loads
    then TextIO.print "Loading PhaseMassTheory ... "
    else ()
  
  open Type Term Thm
  local open integralTheory in end;
  
  structure TDB = struct
    val path =
      OS.Path.base (#(FILE)) ^ ".dat"
    val timestamp = HOLFileSys.modTime path
    val thydata = 
      TheoryReader.load_thydata {
        thyname = "PhaseMass",
        hash = "33fdf862f56a135b05a96db53ce49aed92ce1b19",
        path = path
      }
    fun find s = #1 (valOf (Symtab.lookup thydata s))
  end
  val () = Theory.record_metadata
    "PhaseMass" {timestamp=TDB.timestamp, path=TDB.path}
  
  fun op positive_mass_sup_bound _ = ()
  val op positive_mass_sup_bound = TDB.find "positive_mass_sup_bound"
  fun op pm_slope_def _ = () val op pm_slope_def = TDB.find "pm_slope_def"
  fun op pm_primitive _ = () val op pm_primitive = TDB.find "pm_primitive"
  fun op pm_positive _ = () val op pm_positive = TDB.find "pm_positive"
  fun op pm_dominates _ = () val op pm_dominates = TDB.find "pm_dominates"
  fun op pm_den_def _ = () val op pm_den_def = TDB.find "pm_den_def"
  fun op pm_cutoff_def _ = ()
  val op pm_cutoff_def = TDB.find "pm_cutoff_def"
  fun op kernel_integral_exists _ = ()
  val op kernel_integral_exists = TDB.find "kernel_integral_exists"
  fun op improper_mass_bound _ = ()
  val op improper_mass_bound = TDB.find "improper_mass_bound"
  fun op finite_mass_bound _ = ()
  val op finite_mass_bound = TDB.find "finite_mass_bound"
  fun op cutoff_mono _ = () val op cutoff_mono = TDB.find "cutoff_mono"
  fun op cutoff_bound _ = () val op cutoff_bound = TDB.find "cutoff_bound"
  
val _ = if !Globals.print_thy_loads then TextIO.print "done\n" else ()
val _ = Theory.load_complete "PhaseMass"

end
