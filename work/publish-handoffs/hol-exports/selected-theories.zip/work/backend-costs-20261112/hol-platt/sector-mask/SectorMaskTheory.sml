structure SectorMaskTheory :> SectorMaskTheory =
struct
  
  val _ = if !Globals.print_thy_loads
    then TextIO.print "Loading SectorMaskTheory ... "
    else ()
  
  open Type Term Thm
  local open SectorTheory in end;
  
  structure TDB = struct
    val path =
      OS.Path.base (#(FILE)) ^ ".dat"
    val timestamp = HOLFileSys.modTime path
    val thydata = 
      TheoryReader.load_thydata {
        thyname = "SectorMask",
        hash = "799f5162fbebe49d940f1c36cf364612c68582d0",
        path = path
      }
    fun find s = #1 (valOf (Symtab.lookup thydata s))
  end
  val () = Theory.record_metadata
    "SectorMask" {timestamp=TDB.timestamp, path=TDB.path}
  
  fun op unpack_def _ = () val op unpack_def = TDB.find "unpack_def"
  fun op unpack_compute _ = ()
  val op unpack_compute = TDB.find "unpack_compute"
  fun op selected_range _ = ()
  val op selected_range = TDB.find "selected_range"
  fun op selected_def _ = () val op selected_def = TDB.find "selected_def"
  fun op packet_masks _ = () val op packet_masks = TDB.find "packet_masks"
  fun op decode_cons _ = () val op decode_cons = TDB.find "decode_cons"
  fun op code_rows_ind _ = ()
  val op code_rows_ind = TDB.find "code_rows_ind"
  fun op code_rows_def _ = ()
  val op code_rows_def = TDB.find "code_rows_def"
  fun op changes_ind _ = () val op changes_ind = TDB.find "changes_ind"
  fun op changes_def_primitive _ = ()
  val op changes_def_primitive = TDB.find "changes_def_primitive"
  fun op changes_def _ = () val op changes_def = TDB.find "changes_def"
  
val _ = if !Globals.print_thy_loads then TextIO.print "done\n" else ()
val _ = Theory.load_complete "SectorMask"

end
