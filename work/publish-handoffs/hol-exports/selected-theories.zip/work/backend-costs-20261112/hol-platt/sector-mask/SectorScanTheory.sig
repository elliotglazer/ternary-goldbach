signature SectorScanTheory =
sig
  type thm = Thm.thm
  
  (*  Theorems  *)
    val code_rows_length : thm
    val sector_lane_scan : thm
    val two_codes_scan : thm
    val unpack_codes : thm
    val unpack_el : thm
    val unpack_length : thm
end
