signature SectorMaskTheory =
sig
  type thm = Thm.thm
  
  (*  Definitions  *)
    val changes_def_primitive : thm
    val selected_def : thm
    val unpack_def : thm
  
  (*  Theorems  *)
    val changes_def : thm
    val changes_ind : thm
    val code_rows_def : thm
    val code_rows_ind : thm
    val decode_cons : thm
    val packet_masks : thm
    val selected_range : thm
    val unpack_compute : thm
end
