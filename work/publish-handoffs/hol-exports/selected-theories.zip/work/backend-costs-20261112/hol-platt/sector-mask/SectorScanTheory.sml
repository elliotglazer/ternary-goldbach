structure SectorScanTheory :> SectorScanTheory =
struct
  
  val _ = if !Globals.print_thy_loads
    then TextIO.print "Loading SectorScanTheory ... "
    else ()
  
  open Type Term Thm
  local open FullCountTheory SectorMaskTheory in end;
  
  structure TDB = struct
    val path =
      OS.Path.base (#(FILE)) ^ ".dat"
    val timestamp = HOLFileSys.modTime path
    val thydata = 
      TheoryReader.load_thydata {
        thyname = "SectorScan",
        hash = "2aa022253c6f5c3abe69ae984c84e5cbdfcf7f9e",
        path = path
      }
    fun find s = #1 (valOf (Symtab.lookup thydata s))
  end
  val () = Theory.record_metadata
    "SectorScan" {timestamp=TDB.timestamp, path=TDB.path}
  
  fun op unpack_length _ = ()
  val op unpack_length = TDB.find "unpack_length"
  fun op unpack_el _ = () val op unpack_el = TDB.find "unpack_el"
  fun op unpack_codes _ = () val op unpack_codes = TDB.find "unpack_codes"
  fun op two_codes_scan _ = ()
  val op two_codes_scan = TDB.find "two_codes_scan"
  fun op sector_lane_scan _ = ()
  val op sector_lane_scan = TDB.find "sector_lane_scan"
  fun op code_rows_length _ = ()
  val op code_rows_length = TDB.find "code_rows_length"
  
val _ = if !Globals.print_thy_loads then TextIO.print "done\n" else ()
val _ = Theory.load_complete "SectorScan"

end
