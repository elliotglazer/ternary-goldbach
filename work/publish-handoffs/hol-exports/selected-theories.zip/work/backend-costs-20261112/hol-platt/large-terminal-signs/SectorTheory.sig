signature SectorTheory =
sig
  type thm = Thm.thm
  
  (*  Definitions  *)
    val cv_one_def : thm
    val cv_sector_checked_def : thm
    val cv_sector_times_def : thm
    val cv_sector_trial_def : thm
    val cv_sector_verified_def : thm
    val one_def : thm
    val sector_checked_def : thm
    val sector_times_def : thm
    val sector_trial_def : thm
  
  (*  Theorems  *)
    val cv_one_thm : thm
    val cv_sector_checked_thm : thm
    val cv_sector_packet_def : thm
    val cv_sector_packet_ind : thm
    val cv_sector_packet_thm : thm
    val cv_sector_times_thm : thm
    val cv_sector_trial_thm : thm
    val cv_sector_verified_thm : thm
    val sector_packet_def : thm
    val sector_packet_ind : thm
    val sector_times_compute : thm
    val sector_verified_def : thm
    val sector_verified_ind : thm
end
