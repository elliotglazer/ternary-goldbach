signature RootSignChainTheory =
sig
  type thm = Thm.thm
  
  (*  Theorems  *)
    val certified_crossings_def : thm
    val certified_crossings_ind : thm
    val crossing_chain_endpoint : thm
    val crossing_chain_parity : thm
    val factored_crossing : thm
end
