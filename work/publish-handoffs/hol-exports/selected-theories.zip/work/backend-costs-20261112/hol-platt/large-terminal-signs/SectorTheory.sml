structure SectorTheory :> SectorTheory =
struct
  
  val _ = if !Globals.print_thy_loads
    then TextIO.print "Loading SectorTheory ... "
    else ()
  
  open Type Term Thm
  local open LargeTerminalTheory in end;
  
  structure TDB = struct
    val path =
      OS.Path.base (#(FILE)) ^ ".dat"
    val timestamp = HOLFileSys.modTime path
    val thydata = 
      TheoryReader.load_thydata {
        thyname = "Sector",
        hash = "d742d0e08261e8627326d76c776ffb2c7e40c42f",
        path = path
      }
    fun find s = #1 (valOf (Symtab.lookup thydata s))
  end
  val () = Theory.record_metadata
    "Sector" {timestamp=TDB.timestamp, path=TDB.path}
  
  fun op sector_verified_ind _ = ()
  val op sector_verified_ind = TDB.find "sector_verified_ind"
  fun op sector_verified_def _ = ()
  val op sector_verified_def = TDB.find "sector_verified_def"
  fun op sector_trial_def _ = ()
  val op sector_trial_def = TDB.find "sector_trial_def"
  fun op sector_times_def _ = ()
  val op sector_times_def = TDB.find "sector_times_def"
  fun op sector_times_compute _ = ()
  val op sector_times_compute = TDB.find "sector_times_compute"
  fun op sector_packet_ind _ = ()
  val op sector_packet_ind = TDB.find "sector_packet_ind"
  fun op sector_packet_def _ = ()
  val op sector_packet_def = TDB.find "sector_packet_def"
  fun op sector_checked_def _ = ()
  val op sector_checked_def = TDB.find "sector_checked_def"
  fun op one_def _ = () val op one_def = TDB.find "one_def"
  fun op cv_sector_verified_thm _ = ()
  val op cv_sector_verified_thm = TDB.find "cv_sector_verified_thm"
  fun op cv_sector_verified_def _ = ()
  val op cv_sector_verified_def = TDB.find "cv_sector_verified_def"
  fun op cv_sector_trial_thm _ = ()
  val op cv_sector_trial_thm = TDB.find "cv_sector_trial_thm"
  fun op cv_sector_trial_def _ = ()
  val op cv_sector_trial_def = TDB.find "cv_sector_trial_def"
  fun op cv_sector_times_thm _ = ()
  val op cv_sector_times_thm = TDB.find "cv_sector_times_thm"
  fun op cv_sector_times_def _ = ()
  val op cv_sector_times_def = TDB.find "cv_sector_times_def"
  fun op cv_sector_packet_thm _ = ()
  val op cv_sector_packet_thm = TDB.find "cv_sector_packet_thm"
  fun op cv_sector_packet_ind _ = ()
  val op cv_sector_packet_ind = TDB.find "cv_sector_packet_ind"
  fun op cv_sector_packet_def _ = ()
  val op cv_sector_packet_def = TDB.find "cv_sector_packet_def"
  fun op cv_sector_checked_thm _ = ()
  val op cv_sector_checked_thm = TDB.find "cv_sector_checked_thm"
  fun op cv_sector_checked_def _ = ()
  val op cv_sector_checked_def = TDB.find "cv_sector_checked_def"
  fun op cv_one_thm _ = () val op cv_one_thm = TDB.find "cv_one_thm"
  fun op cv_one_def _ = () val op cv_one_def = TDB.find "cv_one_def"
  
val _ = if !Globals.print_thy_loads then TextIO.print "done\n" else ()
val _ = Theory.load_complete "Sector"

end
