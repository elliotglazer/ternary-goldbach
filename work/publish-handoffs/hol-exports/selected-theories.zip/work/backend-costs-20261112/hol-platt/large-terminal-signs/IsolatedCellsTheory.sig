signature IsolatedCellsTheory =
sig
  type thm = Thm.thm
  
  (*  Definitions  *)
    val root_cell_def : thm
  
  (*  Theorems  *)
    val cells_def : thm
    val cells_endpoint : thm
    val cells_ind : thm
    val cells_parity : thm
    val exterior_gap : thm
    val inner_points : thm
    val root_cell_sign : thm
end
