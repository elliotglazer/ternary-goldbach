signature LargeTerminalTheory =
sig
  type thm = Thm.thm
  
  (*  Definitions  *)
    val checked_def : thm
    val cv_ABS_def : thm
    val cv_checked_def : thm
    val cv_score_def : thm
    val cv_sink_def : thm
    val cv_skim_def : thm
    val cv_times_def : thm
    val cv_trial_def : thm
    val cv_verified_def : thm
    val score_def : thm
    val sink_def : thm
    val times_def : thm
    val trial_def : thm
  
  (*  Theorems  *)
    val cv_ABS_thm : thm
    val cv_checked_thm : thm
    val cv_packet_def : thm
    val cv_packet_ind : thm
    val cv_packet_thm : thm
    val cv_rep_list_datatype : thm
    val cv_rep_option_datatype : thm
    val cv_rep_pair_datatype : thm
    val cv_score_thm : thm
    val cv_sink_thm : thm
    val cv_skim_thm : thm
    val cv_times_thm : thm
    val cv_trial_thm : thm
    val cv_verified_thm : thm
    val packet_def : thm
    val packet_ind : thm
    val skim_def : thm
    val skim_ind : thm
    val times_compute : thm
    val verified_def : thm
    val verified_ind : thm
end
