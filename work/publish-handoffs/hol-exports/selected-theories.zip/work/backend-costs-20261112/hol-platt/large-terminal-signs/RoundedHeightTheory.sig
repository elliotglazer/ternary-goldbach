signature RoundedHeightTheory =
sig
  type thm = Thm.thm
  
  (*  Theorems  *)
    val closed_height_restrict : thm
    val rounded_index : thm
end
