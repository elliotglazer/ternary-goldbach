signature ZeroFreeGapTheory =
sig
  type thm = Thm.thm
  
  (*  Definitions  *)
    val bracket_def : thm
    val zero_free_gap_def : thm
  
  (*  Theorems  *)
    val bracket_sign : thm
    val gap_sign : thm
    val ordered_brackets_def : thm
    val ordered_brackets_ind : thm
    val ordered_endpoint : thm
    val ordered_parity : thm
end
