structure CofactorNeighbourhoodTheory :> CofactorNeighbourhoodTheory =
struct
  
  val _ = if !Globals.print_thy_loads
    then TextIO.print "Loading CofactorNeighbourhoodTheory ... "
    else ()
  
  open Type Term Thm
  local open ZeroFreeGapTheory in end;
  
  structure TDB = struct
    val path =
      OS.Path.base (#(FILE)) ^ ".dat"
    val timestamp = HOLFileSys.modTime path
    val thydata = 
      TheoryReader.load_thydata {
        thyname = "CofactorNeighbourhood",
        hash = "d743b1b2fbc0f559d3c49400b5cd2a226b9bfd67",
        path = path
      }
    fun find s = #1 (valOf (Symtab.lookup thydata s))
  end
  val () = Theory.record_metadata
    "CofactorNeighbourhood" {timestamp=TDB.timestamp, path=TDB.path}
  
  fun op local_factor_brackets _ = ()
  val op local_factor_brackets = TDB.find "local_factor_brackets"
  fun op continuous_cofactor_sign _ = ()
  val op continuous_cofactor_sign = TDB.find "continuous_cofactor_sign"
  
val _ = if !Globals.print_thy_loads then TextIO.print "done\n" else ()
val _ = Theory.load_complete "CofactorNeighbourhood"

end
