structure RootSignChainTheory :> RootSignChainTheory =
struct
  
  val _ = if !Globals.print_thy_loads
    then TextIO.print "Loading RootSignChainTheory ... "
    else ()
  
  open Type Term Thm
  local open FullCountTheory RealFieldContextTheory in end;
  
  structure TDB = struct
    val path =
      OS.Path.base (#(FILE)) ^ ".dat"
    val timestamp = HOLFileSys.modTime path
    val thydata = 
      TheoryReader.load_thydata {
        thyname = "RootSignChain",
        hash = "042fb9bac905a63af1c270b95172bb368f845c77",
        path = path
      }
    fun find s = #1 (valOf (Symtab.lookup thydata s))
  end
  val () = Theory.record_metadata
    "RootSignChain" {timestamp=TDB.timestamp, path=TDB.path}
  
  fun op factored_crossing _ = ()
  val op factored_crossing = TDB.find "factored_crossing"
  fun op crossing_chain_parity _ = ()
  val op crossing_chain_parity = TDB.find "crossing_chain_parity"
  fun op crossing_chain_endpoint _ = ()
  val op crossing_chain_endpoint = TDB.find "crossing_chain_endpoint"
  fun op certified_crossings_ind _ = ()
  val op certified_crossings_ind = TDB.find "certified_crossings_ind"
  fun op certified_crossings_def _ = ()
  val op certified_crossings_def = TDB.find "certified_crossings_def"
  
val _ = if !Globals.print_thy_loads then TextIO.print "done\n" else ()
val _ = Theory.load_complete "RootSignChain"

end
