signature CofactorNeighbourhoodTheory =
sig
  type thm = Thm.thm
  
  (*  Theorems  *)
    val continuous_cofactor_sign : thm
    val local_factor_brackets : thm
end
