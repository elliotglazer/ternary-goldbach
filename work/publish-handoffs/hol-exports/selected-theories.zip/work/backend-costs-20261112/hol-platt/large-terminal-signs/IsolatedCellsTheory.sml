structure IsolatedCellsTheory :> IsolatedCellsTheory =
struct
  
  val _ = if !Globals.print_thy_loads
    then TextIO.print "Loading IsolatedCellsTheory ... "
    else ()
  
  open Type Term Thm
  local open CofactorNeighbourhoodTheory in end;
  
  structure TDB = struct
    val path =
      OS.Path.base (#(FILE)) ^ ".dat"
    val timestamp = HOLFileSys.modTime path
    val thydata = 
      TheoryReader.load_thydata {
        thyname = "IsolatedCells",
        hash = "bc5c0c342bdce3094c67ab260af517cb7460c045",
        path = path
      }
    fun find s = #1 (valOf (Symtab.lookup thydata s))
  end
  val () = Theory.record_metadata
    "IsolatedCells" {timestamp=TDB.timestamp, path=TDB.path}
  
  fun op root_cell_sign _ = ()
  val op root_cell_sign = TDB.find "root_cell_sign"
  fun op root_cell_def _ = ()
  val op root_cell_def = TDB.find "root_cell_def"
  fun op inner_points _ = () val op inner_points = TDB.find "inner_points"
  fun op exterior_gap _ = () val op exterior_gap = TDB.find "exterior_gap"
  fun op cells_parity _ = () val op cells_parity = TDB.find "cells_parity"
  fun op cells_ind _ = () val op cells_ind = TDB.find "cells_ind"
  fun op cells_endpoint _ = ()
  val op cells_endpoint = TDB.find "cells_endpoint"
  fun op cells_def _ = () val op cells_def = TDB.find "cells_def"
  
val _ = if !Globals.print_thy_loads then TextIO.print "done\n" else ()
val _ = Theory.load_complete "IsolatedCells"

end
