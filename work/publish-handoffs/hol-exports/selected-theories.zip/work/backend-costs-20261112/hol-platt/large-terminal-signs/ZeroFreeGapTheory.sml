structure ZeroFreeGapTheory :> ZeroFreeGapTheory =
struct
  
  val _ = if !Globals.print_thy_loads
    then TextIO.print "Loading ZeroFreeGapTheory ... "
    else ()
  
  open Type Term Thm
  local open RootSignChainTheory limTheory in end;
  
  structure TDB = struct
    val path =
      OS.Path.base (#(FILE)) ^ ".dat"
    val timestamp = HOLFileSys.modTime path
    val thydata = 
      TheoryReader.load_thydata {
        thyname = "ZeroFreeGap",
        hash = "8445bdab05f55fbb88da3b1265a9a1598e442a21",
        path = path
      }
    fun find s = #1 (valOf (Symtab.lookup thydata s))
  end
  val () = Theory.record_metadata
    "ZeroFreeGap" {timestamp=TDB.timestamp, path=TDB.path}
  
  fun op zero_free_gap_def _ = ()
  val op zero_free_gap_def = TDB.find "zero_free_gap_def"
  fun op ordered_parity _ = ()
  val op ordered_parity = TDB.find "ordered_parity"
  fun op ordered_endpoint _ = ()
  val op ordered_endpoint = TDB.find "ordered_endpoint"
  fun op ordered_brackets_ind _ = ()
  val op ordered_brackets_ind = TDB.find "ordered_brackets_ind"
  fun op ordered_brackets_def _ = ()
  val op ordered_brackets_def = TDB.find "ordered_brackets_def"
  fun op gap_sign _ = () val op gap_sign = TDB.find "gap_sign"
  fun op bracket_sign _ = () val op bracket_sign = TDB.find "bracket_sign"
  fun op bracket_def _ = () val op bracket_def = TDB.find "bracket_def"
  
val _ = if !Globals.print_thy_loads then TextIO.print "done\n" else ()
val _ = Theory.load_complete "ZeroFreeGap"

end
