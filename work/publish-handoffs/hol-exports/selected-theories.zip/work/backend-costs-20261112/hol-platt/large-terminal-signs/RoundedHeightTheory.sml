structure RoundedHeightTheory :> RoundedHeightTheory =
struct
  
  val _ = if !Globals.print_thy_loads
    then TextIO.print "Loading RoundedHeightTheory ... "
    else ()
  
  open Type Term Thm
  local open realTheory in end;
  
  structure TDB = struct
    val path =
      OS.Path.base (#(FILE)) ^ ".dat"
    val timestamp = HOLFileSys.modTime path
    val thydata = 
      TheoryReader.load_thydata {
        thyname = "RoundedHeight",
        hash = "de67efcd0c445a8a6d37ffca0b444b023ef8f0d7",
        path = path
      }
    fun find s = #1 (valOf (Symtab.lookup thydata s))
  end
  val () = Theory.record_metadata
    "RoundedHeight" {timestamp=TDB.timestamp, path=TDB.path}
  
  fun op rounded_index _ = ()
  val op rounded_index = TDB.find "rounded_index"
  fun op closed_height_restrict _ = ()
  val op closed_height_restrict = TDB.find "closed_height_restrict"
  
val _ = if !Globals.print_thy_loads then TextIO.print "done\n" else ()
val _ = Theory.load_complete "RoundedHeight"

end
