structure LargeTerminalTheory :> LargeTerminalTheory =
struct
  
  val _ = if !Globals.print_thy_loads
    then TextIO.print "Loading LargeTerminalTheory ... "
    else ()
  
  open Type Term Thm
  local open cv_primTheory in end;
  
  structure TDB = struct
    val path =
      OS.Path.base (#(FILE)) ^ ".dat"
    val timestamp = HOLFileSys.modTime path
    val thydata = 
      TheoryReader.load_thydata {
        thyname = "LargeTerminal",
        hash = "bb73e423b6101e7f2761cdb2acb53c73bbd7296e",
        path = path
      }
    fun find s = #1 (valOf (Symtab.lookup thydata s))
  end
  val () = Theory.record_metadata
    "LargeTerminal" {timestamp=TDB.timestamp, path=TDB.path}
  
  fun op verified_ind _ = () val op verified_ind = TDB.find "verified_ind"
  fun op verified_def _ = () val op verified_def = TDB.find "verified_def"
  fun op trial_def _ = () val op trial_def = TDB.find "trial_def"
  fun op times_def _ = () val op times_def = TDB.find "times_def"
  fun op times_compute _ = ()
  val op times_compute = TDB.find "times_compute"
  fun op skim_ind _ = () val op skim_ind = TDB.find "skim_ind"
  fun op skim_def _ = () val op skim_def = TDB.find "skim_def"
  fun op sink_def _ = () val op sink_def = TDB.find "sink_def"
  fun op score_def _ = () val op score_def = TDB.find "score_def"
  fun op packet_ind _ = () val op packet_ind = TDB.find "packet_ind"
  fun op packet_def _ = () val op packet_def = TDB.find "packet_def"
  fun op cv_verified_thm _ = ()
  val op cv_verified_thm = TDB.find "cv_verified_thm"
  fun op cv_verified_def _ = ()
  val op cv_verified_def = TDB.find "cv_verified_def"
  fun op cv_trial_thm _ = () val op cv_trial_thm = TDB.find "cv_trial_thm"
  fun op cv_trial_def _ = () val op cv_trial_def = TDB.find "cv_trial_def"
  fun op cv_times_thm _ = () val op cv_times_thm = TDB.find "cv_times_thm"
  fun op cv_times_def _ = () val op cv_times_def = TDB.find "cv_times_def"
  fun op cv_skim_thm _ = () val op cv_skim_thm = TDB.find "cv_skim_thm"
  fun op cv_skim_def _ = () val op cv_skim_def = TDB.find "cv_skim_def"
  fun op cv_sink_thm _ = () val op cv_sink_thm = TDB.find "cv_sink_thm"
  fun op cv_sink_def _ = () val op cv_sink_def = TDB.find "cv_sink_def"
  fun op cv_score_thm _ = () val op cv_score_thm = TDB.find "cv_score_thm"
  fun op cv_score_def _ = () val op cv_score_def = TDB.find "cv_score_def"
  fun op cv_rep_pair_datatype _ = ()
  val op cv_rep_pair_datatype = TDB.find "cv_rep_pair_datatype"
  fun op cv_rep_option_datatype _ = ()
  val op cv_rep_option_datatype = TDB.find "cv_rep_option_datatype"
  fun op cv_rep_list_datatype _ = ()
  val op cv_rep_list_datatype = TDB.find "cv_rep_list_datatype"
  fun op cv_packet_thm _ = ()
  val op cv_packet_thm = TDB.find "cv_packet_thm"
  fun op cv_packet_ind _ = ()
  val op cv_packet_ind = TDB.find "cv_packet_ind"
  fun op cv_packet_def _ = ()
  val op cv_packet_def = TDB.find "cv_packet_def"
  fun op cv_checked_thm _ = ()
  val op cv_checked_thm = TDB.find "cv_checked_thm"
  fun op cv_checked_def _ = ()
  val op cv_checked_def = TDB.find "cv_checked_def"
  fun op cv_ABS_thm _ = () val op cv_ABS_thm = TDB.find "cv_ABS_thm"
  fun op cv_ABS_def _ = () val op cv_ABS_def = TDB.find "cv_ABS_def"
  fun op checked_def _ = () val op checked_def = TDB.find "checked_def"
  
val _ = if !Globals.print_thy_loads then TextIO.print "done\n" else ()
val _ = Theory.load_complete "LargeTerminal"

end
