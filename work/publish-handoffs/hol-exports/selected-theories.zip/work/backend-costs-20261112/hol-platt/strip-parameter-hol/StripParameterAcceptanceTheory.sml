structure StripParameterAcceptanceTheory :> StripParameterAcceptanceTheory =
struct
  
  val _ = if !Globals.print_thy_loads
    then TextIO.print "Loading StripParameterAcceptanceTheory ... "
    else ()
  
  open Type Term Thm
  local open StripParameterTheory in end;
  
  structure TDB = struct
    val path =
      OS.Path.base (#(FILE)) ^ ".dat"
    val timestamp = HOLFileSys.modTime path
    val thydata = 
      TheoryReader.load_thydata {
        thyname = "StripParameterAcceptance",
        hash = "3ea76b4ff26ca03fa4b1aa8e3e83a40573148a01",
        path = path
      }
    fun find s = #1 (valOf (Symtab.lookup thydata s))
  end
  val () = Theory.record_metadata
    "StripParameterAcceptance" {timestamp=TDB.timestamp, path=TDB.path}
  
  fun op sp9_def _ = () val op sp9_def = TDB.find "sp9_def"
  fun op sp9_accepted _ = () val op sp9_accepted = TDB.find "sp9_accepted"
  fun op sp99_def _ = () val op sp99_def = TDB.find "sp99_def"
  fun op sp99_accepted _ = ()
  val op sp99_accepted = TDB.find "sp99_accepted"
  fun op sp98_def _ = () val op sp98_def = TDB.find "sp98_def"
  fun op sp98_accepted _ = ()
  val op sp98_accepted = TDB.find "sp98_accepted"
  fun op sp97_def _ = () val op sp97_def = TDB.find "sp97_def"
  fun op sp97_accepted _ = ()
  val op sp97_accepted = TDB.find "sp97_accepted"
  fun op sp96_def _ = () val op sp96_def = TDB.find "sp96_def"
  fun op sp96_accepted _ = ()
  val op sp96_accepted = TDB.find "sp96_accepted"
  fun op sp95_def _ = () val op sp95_def = TDB.find "sp95_def"
  fun op sp95_accepted _ = ()
  val op sp95_accepted = TDB.find "sp95_accepted"
  fun op sp94_def _ = () val op sp94_def = TDB.find "sp94_def"
  fun op sp94_accepted _ = ()
  val op sp94_accepted = TDB.find "sp94_accepted"
  fun op sp93_def _ = () val op sp93_def = TDB.find "sp93_def"
  fun op sp93_accepted _ = ()
  val op sp93_accepted = TDB.find "sp93_accepted"
  fun op sp92_def _ = () val op sp92_def = TDB.find "sp92_def"
  fun op sp92_accepted _ = ()
  val op sp92_accepted = TDB.find "sp92_accepted"
  fun op sp91_def _ = () val op sp91_def = TDB.find "sp91_def"
  fun op sp91_accepted _ = ()
  val op sp91_accepted = TDB.find "sp91_accepted"
  fun op sp90_def _ = () val op sp90_def = TDB.find "sp90_def"
  fun op sp90_accepted _ = ()
  val op sp90_accepted = TDB.find "sp90_accepted"
  fun op sp8_def _ = () val op sp8_def = TDB.find "sp8_def"
  fun op sp8_accepted _ = () val op sp8_accepted = TDB.find "sp8_accepted"
  fun op sp89_def _ = () val op sp89_def = TDB.find "sp89_def"
  fun op sp89_accepted _ = ()
  val op sp89_accepted = TDB.find "sp89_accepted"
  fun op sp88_def _ = () val op sp88_def = TDB.find "sp88_def"
  fun op sp88_accepted _ = ()
  val op sp88_accepted = TDB.find "sp88_accepted"
  fun op sp87_def _ = () val op sp87_def = TDB.find "sp87_def"
  fun op sp87_accepted _ = ()
  val op sp87_accepted = TDB.find "sp87_accepted"
  fun op sp86_def _ = () val op sp86_def = TDB.find "sp86_def"
  fun op sp86_accepted _ = ()
  val op sp86_accepted = TDB.find "sp86_accepted"
  fun op sp85_def _ = () val op sp85_def = TDB.find "sp85_def"
  fun op sp85_accepted _ = ()
  val op sp85_accepted = TDB.find "sp85_accepted"
  fun op sp84_def _ = () val op sp84_def = TDB.find "sp84_def"
  fun op sp84_accepted _ = ()
  val op sp84_accepted = TDB.find "sp84_accepted"
  fun op sp83_def _ = () val op sp83_def = TDB.find "sp83_def"
  fun op sp83_accepted _ = ()
  val op sp83_accepted = TDB.find "sp83_accepted"
  fun op sp82_def _ = () val op sp82_def = TDB.find "sp82_def"
  fun op sp82_accepted _ = ()
  val op sp82_accepted = TDB.find "sp82_accepted"
  fun op sp81_def _ = () val op sp81_def = TDB.find "sp81_def"
  fun op sp81_accepted _ = ()
  val op sp81_accepted = TDB.find "sp81_accepted"
  fun op sp80_def _ = () val op sp80_def = TDB.find "sp80_def"
  fun op sp80_accepted _ = ()
  val op sp80_accepted = TDB.find "sp80_accepted"
  fun op sp7_def _ = () val op sp7_def = TDB.find "sp7_def"
  fun op sp7_accepted _ = () val op sp7_accepted = TDB.find "sp7_accepted"
  fun op sp79_def _ = () val op sp79_def = TDB.find "sp79_def"
  fun op sp79_accepted _ = ()
  val op sp79_accepted = TDB.find "sp79_accepted"
  fun op sp78_def _ = () val op sp78_def = TDB.find "sp78_def"
  fun op sp78_accepted _ = ()
  val op sp78_accepted = TDB.find "sp78_accepted"
  fun op sp77_def _ = () val op sp77_def = TDB.find "sp77_def"
  fun op sp77_accepted _ = ()
  val op sp77_accepted = TDB.find "sp77_accepted"
  fun op sp76_def _ = () val op sp76_def = TDB.find "sp76_def"
  fun op sp76_accepted _ = ()
  val op sp76_accepted = TDB.find "sp76_accepted"
  fun op sp75_def _ = () val op sp75_def = TDB.find "sp75_def"
  fun op sp75_accepted _ = ()
  val op sp75_accepted = TDB.find "sp75_accepted"
  fun op sp74_def _ = () val op sp74_def = TDB.find "sp74_def"
  fun op sp74_accepted _ = ()
  val op sp74_accepted = TDB.find "sp74_accepted"
  fun op sp73_def _ = () val op sp73_def = TDB.find "sp73_def"
  fun op sp73_accepted _ = ()
  val op sp73_accepted = TDB.find "sp73_accepted"
  fun op sp72_def _ = () val op sp72_def = TDB.find "sp72_def"
  fun op sp72_accepted _ = ()
  val op sp72_accepted = TDB.find "sp72_accepted"
  fun op sp71_def _ = () val op sp71_def = TDB.find "sp71_def"
  fun op sp71_accepted _ = ()
  val op sp71_accepted = TDB.find "sp71_accepted"
  fun op sp70_def _ = () val op sp70_def = TDB.find "sp70_def"
  fun op sp70_accepted _ = ()
  val op sp70_accepted = TDB.find "sp70_accepted"
  fun op sp6_def _ = () val op sp6_def = TDB.find "sp6_def"
  fun op sp6_accepted _ = () val op sp6_accepted = TDB.find "sp6_accepted"
  fun op sp69_def _ = () val op sp69_def = TDB.find "sp69_def"
  fun op sp69_accepted _ = ()
  val op sp69_accepted = TDB.find "sp69_accepted"
  fun op sp68_def _ = () val op sp68_def = TDB.find "sp68_def"
  fun op sp68_accepted _ = ()
  val op sp68_accepted = TDB.find "sp68_accepted"
  fun op sp67_def _ = () val op sp67_def = TDB.find "sp67_def"
  fun op sp67_accepted _ = ()
  val op sp67_accepted = TDB.find "sp67_accepted"
  fun op sp66_def _ = () val op sp66_def = TDB.find "sp66_def"
  fun op sp66_accepted _ = ()
  val op sp66_accepted = TDB.find "sp66_accepted"
  fun op sp65_def _ = () val op sp65_def = TDB.find "sp65_def"
  fun op sp65_accepted _ = ()
  val op sp65_accepted = TDB.find "sp65_accepted"
  fun op sp64_def _ = () val op sp64_def = TDB.find "sp64_def"
  fun op sp64_accepted _ = ()
  val op sp64_accepted = TDB.find "sp64_accepted"
  fun op sp63_def _ = () val op sp63_def = TDB.find "sp63_def"
  fun op sp63_accepted _ = ()
  val op sp63_accepted = TDB.find "sp63_accepted"
  fun op sp62_def _ = () val op sp62_def = TDB.find "sp62_def"
  fun op sp62_accepted _ = ()
  val op sp62_accepted = TDB.find "sp62_accepted"
  fun op sp61_def _ = () val op sp61_def = TDB.find "sp61_def"
  fun op sp61_accepted _ = ()
  val op sp61_accepted = TDB.find "sp61_accepted"
  fun op sp60_def _ = () val op sp60_def = TDB.find "sp60_def"
  fun op sp60_accepted _ = ()
  val op sp60_accepted = TDB.find "sp60_accepted"
  fun op sp5_def _ = () val op sp5_def = TDB.find "sp5_def"
  fun op sp5_accepted _ = () val op sp5_accepted = TDB.find "sp5_accepted"
  fun op sp59_def _ = () val op sp59_def = TDB.find "sp59_def"
  fun op sp59_accepted _ = ()
  val op sp59_accepted = TDB.find "sp59_accepted"
  fun op sp58_def _ = () val op sp58_def = TDB.find "sp58_def"
  fun op sp58_accepted _ = ()
  val op sp58_accepted = TDB.find "sp58_accepted"
  fun op sp57_def _ = () val op sp57_def = TDB.find "sp57_def"
  fun op sp57_accepted _ = ()
  val op sp57_accepted = TDB.find "sp57_accepted"
  fun op sp56_def _ = () val op sp56_def = TDB.find "sp56_def"
  fun op sp56_accepted _ = ()
  val op sp56_accepted = TDB.find "sp56_accepted"
  fun op sp55_def _ = () val op sp55_def = TDB.find "sp55_def"
  fun op sp55_accepted _ = ()
  val op sp55_accepted = TDB.find "sp55_accepted"
  fun op sp54_def _ = () val op sp54_def = TDB.find "sp54_def"
  fun op sp54_accepted _ = ()
  val op sp54_accepted = TDB.find "sp54_accepted"
  fun op sp53_def _ = () val op sp53_def = TDB.find "sp53_def"
  fun op sp53_accepted _ = ()
  val op sp53_accepted = TDB.find "sp53_accepted"
  fun op sp52_def _ = () val op sp52_def = TDB.find "sp52_def"
  fun op sp52_accepted _ = ()
  val op sp52_accepted = TDB.find "sp52_accepted"
  fun op sp51_def _ = () val op sp51_def = TDB.find "sp51_def"
  fun op sp51_accepted _ = ()
  val op sp51_accepted = TDB.find "sp51_accepted"
  fun op sp50_def _ = () val op sp50_def = TDB.find "sp50_def"
  fun op sp50_accepted _ = ()
  val op sp50_accepted = TDB.find "sp50_accepted"
  fun op sp4_def _ = () val op sp4_def = TDB.find "sp4_def"
  fun op sp4_accepted _ = () val op sp4_accepted = TDB.find "sp4_accepted"
  fun op sp49_def _ = () val op sp49_def = TDB.find "sp49_def"
  fun op sp49_accepted _ = ()
  val op sp49_accepted = TDB.find "sp49_accepted"
  fun op sp48_def _ = () val op sp48_def = TDB.find "sp48_def"
  fun op sp48_accepted _ = ()
  val op sp48_accepted = TDB.find "sp48_accepted"
  fun op sp47_def _ = () val op sp47_def = TDB.find "sp47_def"
  fun op sp47_accepted _ = ()
  val op sp47_accepted = TDB.find "sp47_accepted"
  fun op sp46_def _ = () val op sp46_def = TDB.find "sp46_def"
  fun op sp46_accepted _ = ()
  val op sp46_accepted = TDB.find "sp46_accepted"
  fun op sp45_def _ = () val op sp45_def = TDB.find "sp45_def"
  fun op sp45_accepted _ = ()
  val op sp45_accepted = TDB.find "sp45_accepted"
  fun op sp44_def _ = () val op sp44_def = TDB.find "sp44_def"
  fun op sp44_accepted _ = ()
  val op sp44_accepted = TDB.find "sp44_accepted"
  fun op sp43_def _ = () val op sp43_def = TDB.find "sp43_def"
  fun op sp43_accepted _ = ()
  val op sp43_accepted = TDB.find "sp43_accepted"
  fun op sp42_def _ = () val op sp42_def = TDB.find "sp42_def"
  fun op sp42_accepted _ = ()
  val op sp42_accepted = TDB.find "sp42_accepted"
  fun op sp41_def _ = () val op sp41_def = TDB.find "sp41_def"
  fun op sp41_accepted _ = ()
  val op sp41_accepted = TDB.find "sp41_accepted"
  fun op sp40_def _ = () val op sp40_def = TDB.find "sp40_def"
  fun op sp40_accepted _ = ()
  val op sp40_accepted = TDB.find "sp40_accepted"
  fun op sp3_def _ = () val op sp3_def = TDB.find "sp3_def"
  fun op sp3_accepted _ = () val op sp3_accepted = TDB.find "sp3_accepted"
  fun op sp39_def _ = () val op sp39_def = TDB.find "sp39_def"
  fun op sp39_accepted _ = ()
  val op sp39_accepted = TDB.find "sp39_accepted"
  fun op sp38_def _ = () val op sp38_def = TDB.find "sp38_def"
  fun op sp38_accepted _ = ()
  val op sp38_accepted = TDB.find "sp38_accepted"
  fun op sp37_def _ = () val op sp37_def = TDB.find "sp37_def"
  fun op sp37_accepted _ = ()
  val op sp37_accepted = TDB.find "sp37_accepted"
  fun op sp36_def _ = () val op sp36_def = TDB.find "sp36_def"
  fun op sp36_accepted _ = ()
  val op sp36_accepted = TDB.find "sp36_accepted"
  fun op sp35_def _ = () val op sp35_def = TDB.find "sp35_def"
  fun op sp35_accepted _ = ()
  val op sp35_accepted = TDB.find "sp35_accepted"
  fun op sp34_def _ = () val op sp34_def = TDB.find "sp34_def"
  fun op sp34_accepted _ = ()
  val op sp34_accepted = TDB.find "sp34_accepted"
  fun op sp33_def _ = () val op sp33_def = TDB.find "sp33_def"
  fun op sp33_accepted _ = ()
  val op sp33_accepted = TDB.find "sp33_accepted"
  fun op sp32_def _ = () val op sp32_def = TDB.find "sp32_def"
  fun op sp32_accepted _ = ()
  val op sp32_accepted = TDB.find "sp32_accepted"
  fun op sp31_def _ = () val op sp31_def = TDB.find "sp31_def"
  fun op sp31_accepted _ = ()
  val op sp31_accepted = TDB.find "sp31_accepted"
  fun op sp30_def _ = () val op sp30_def = TDB.find "sp30_def"
  fun op sp30_accepted _ = ()
  val op sp30_accepted = TDB.find "sp30_accepted"
  fun op sp2_def _ = () val op sp2_def = TDB.find "sp2_def"
  fun op sp2_accepted _ = () val op sp2_accepted = TDB.find "sp2_accepted"
  fun op sp29_def _ = () val op sp29_def = TDB.find "sp29_def"
  fun op sp29_accepted _ = ()
  val op sp29_accepted = TDB.find "sp29_accepted"
  fun op sp28_def _ = () val op sp28_def = TDB.find "sp28_def"
  fun op sp28_accepted _ = ()
  val op sp28_accepted = TDB.find "sp28_accepted"
  fun op sp27_def _ = () val op sp27_def = TDB.find "sp27_def"
  fun op sp27_accepted _ = ()
  val op sp27_accepted = TDB.find "sp27_accepted"
  fun op sp26_def _ = () val op sp26_def = TDB.find "sp26_def"
  fun op sp26_accepted _ = ()
  val op sp26_accepted = TDB.find "sp26_accepted"
  fun op sp269_def _ = () val op sp269_def = TDB.find "sp269_def"
  fun op sp269_accepted _ = ()
  val op sp269_accepted = TDB.find "sp269_accepted"
  fun op sp268_def _ = () val op sp268_def = TDB.find "sp268_def"
  fun op sp268_accepted _ = ()
  val op sp268_accepted = TDB.find "sp268_accepted"
  fun op sp267_def _ = () val op sp267_def = TDB.find "sp267_def"
  fun op sp267_accepted _ = ()
  val op sp267_accepted = TDB.find "sp267_accepted"
  fun op sp266_def _ = () val op sp266_def = TDB.find "sp266_def"
  fun op sp266_accepted _ = ()
  val op sp266_accepted = TDB.find "sp266_accepted"
  fun op sp265_def _ = () val op sp265_def = TDB.find "sp265_def"
  fun op sp265_accepted _ = ()
  val op sp265_accepted = TDB.find "sp265_accepted"
  fun op sp264_def _ = () val op sp264_def = TDB.find "sp264_def"
  fun op sp264_accepted _ = ()
  val op sp264_accepted = TDB.find "sp264_accepted"
  fun op sp263_def _ = () val op sp263_def = TDB.find "sp263_def"
  fun op sp263_accepted _ = ()
  val op sp263_accepted = TDB.find "sp263_accepted"
  fun op sp262_def _ = () val op sp262_def = TDB.find "sp262_def"
  fun op sp262_accepted _ = ()
  val op sp262_accepted = TDB.find "sp262_accepted"
  fun op sp261_def _ = () val op sp261_def = TDB.find "sp261_def"
  fun op sp261_accepted _ = ()
  val op sp261_accepted = TDB.find "sp261_accepted"
  fun op sp260_def _ = () val op sp260_def = TDB.find "sp260_def"
  fun op sp260_accepted _ = ()
  val op sp260_accepted = TDB.find "sp260_accepted"
  fun op sp25_def _ = () val op sp25_def = TDB.find "sp25_def"
  fun op sp25_accepted _ = ()
  val op sp25_accepted = TDB.find "sp25_accepted"
  fun op sp259_def _ = () val op sp259_def = TDB.find "sp259_def"
  fun op sp259_accepted _ = ()
  val op sp259_accepted = TDB.find "sp259_accepted"
  fun op sp258_def _ = () val op sp258_def = TDB.find "sp258_def"
  fun op sp258_accepted _ = ()
  val op sp258_accepted = TDB.find "sp258_accepted"
  fun op sp257_def _ = () val op sp257_def = TDB.find "sp257_def"
  fun op sp257_accepted _ = ()
  val op sp257_accepted = TDB.find "sp257_accepted"
  fun op sp256_def _ = () val op sp256_def = TDB.find "sp256_def"
  fun op sp256_accepted _ = ()
  val op sp256_accepted = TDB.find "sp256_accepted"
  fun op sp255_def _ = () val op sp255_def = TDB.find "sp255_def"
  fun op sp255_accepted _ = ()
  val op sp255_accepted = TDB.find "sp255_accepted"
  fun op sp254_def _ = () val op sp254_def = TDB.find "sp254_def"
  fun op sp254_accepted _ = ()
  val op sp254_accepted = TDB.find "sp254_accepted"
  fun op sp253_def _ = () val op sp253_def = TDB.find "sp253_def"
  fun op sp253_accepted _ = ()
  val op sp253_accepted = TDB.find "sp253_accepted"
  fun op sp252_def _ = () val op sp252_def = TDB.find "sp252_def"
  fun op sp252_accepted _ = ()
  val op sp252_accepted = TDB.find "sp252_accepted"
  fun op sp251_def _ = () val op sp251_def = TDB.find "sp251_def"
  fun op sp251_accepted _ = ()
  val op sp251_accepted = TDB.find "sp251_accepted"
  fun op sp250_def _ = () val op sp250_def = TDB.find "sp250_def"
  fun op sp250_accepted _ = ()
  val op sp250_accepted = TDB.find "sp250_accepted"
  fun op sp24_def _ = () val op sp24_def = TDB.find "sp24_def"
  fun op sp24_accepted _ = ()
  val op sp24_accepted = TDB.find "sp24_accepted"
  fun op sp249_def _ = () val op sp249_def = TDB.find "sp249_def"
  fun op sp249_accepted _ = ()
  val op sp249_accepted = TDB.find "sp249_accepted"
  fun op sp248_def _ = () val op sp248_def = TDB.find "sp248_def"
  fun op sp248_accepted _ = ()
  val op sp248_accepted = TDB.find "sp248_accepted"
  fun op sp247_def _ = () val op sp247_def = TDB.find "sp247_def"
  fun op sp247_accepted _ = ()
  val op sp247_accepted = TDB.find "sp247_accepted"
  fun op sp246_def _ = () val op sp246_def = TDB.find "sp246_def"
  fun op sp246_accepted _ = ()
  val op sp246_accepted = TDB.find "sp246_accepted"
  fun op sp245_def _ = () val op sp245_def = TDB.find "sp245_def"
  fun op sp245_accepted _ = ()
  val op sp245_accepted = TDB.find "sp245_accepted"
  fun op sp244_def _ = () val op sp244_def = TDB.find "sp244_def"
  fun op sp244_accepted _ = ()
  val op sp244_accepted = TDB.find "sp244_accepted"
  fun op sp243_def _ = () val op sp243_def = TDB.find "sp243_def"
  fun op sp243_accepted _ = ()
  val op sp243_accepted = TDB.find "sp243_accepted"
  fun op sp242_def _ = () val op sp242_def = TDB.find "sp242_def"
  fun op sp242_accepted _ = ()
  val op sp242_accepted = TDB.find "sp242_accepted"
  fun op sp241_def _ = () val op sp241_def = TDB.find "sp241_def"
  fun op sp241_accepted _ = ()
  val op sp241_accepted = TDB.find "sp241_accepted"
  fun op sp240_def _ = () val op sp240_def = TDB.find "sp240_def"
  fun op sp240_accepted _ = ()
  val op sp240_accepted = TDB.find "sp240_accepted"
  fun op sp23_def _ = () val op sp23_def = TDB.find "sp23_def"
  fun op sp23_accepted _ = ()
  val op sp23_accepted = TDB.find "sp23_accepted"
  fun op sp239_def _ = () val op sp239_def = TDB.find "sp239_def"
  fun op sp239_accepted _ = ()
  val op sp239_accepted = TDB.find "sp239_accepted"
  fun op sp238_def _ = () val op sp238_def = TDB.find "sp238_def"
  fun op sp238_accepted _ = ()
  val op sp238_accepted = TDB.find "sp238_accepted"
  fun op sp237_def _ = () val op sp237_def = TDB.find "sp237_def"
  fun op sp237_accepted _ = ()
  val op sp237_accepted = TDB.find "sp237_accepted"
  fun op sp236_def _ = () val op sp236_def = TDB.find "sp236_def"
  fun op sp236_accepted _ = ()
  val op sp236_accepted = TDB.find "sp236_accepted"
  fun op sp235_def _ = () val op sp235_def = TDB.find "sp235_def"
  fun op sp235_accepted _ = ()
  val op sp235_accepted = TDB.find "sp235_accepted"
  fun op sp234_def _ = () val op sp234_def = TDB.find "sp234_def"
  fun op sp234_accepted _ = ()
  val op sp234_accepted = TDB.find "sp234_accepted"
  fun op sp233_def _ = () val op sp233_def = TDB.find "sp233_def"
  fun op sp233_accepted _ = ()
  val op sp233_accepted = TDB.find "sp233_accepted"
  fun op sp232_def _ = () val op sp232_def = TDB.find "sp232_def"
  fun op sp232_accepted _ = ()
  val op sp232_accepted = TDB.find "sp232_accepted"
  fun op sp231_def _ = () val op sp231_def = TDB.find "sp231_def"
  fun op sp231_accepted _ = ()
  val op sp231_accepted = TDB.find "sp231_accepted"
  fun op sp230_def _ = () val op sp230_def = TDB.find "sp230_def"
  fun op sp230_accepted _ = ()
  val op sp230_accepted = TDB.find "sp230_accepted"
  fun op sp22_def _ = () val op sp22_def = TDB.find "sp22_def"
  fun op sp22_accepted _ = ()
  val op sp22_accepted = TDB.find "sp22_accepted"
  fun op sp229_def _ = () val op sp229_def = TDB.find "sp229_def"
  fun op sp229_accepted _ = ()
  val op sp229_accepted = TDB.find "sp229_accepted"
  fun op sp228_def _ = () val op sp228_def = TDB.find "sp228_def"
  fun op sp228_accepted _ = ()
  val op sp228_accepted = TDB.find "sp228_accepted"
  fun op sp227_def _ = () val op sp227_def = TDB.find "sp227_def"
  fun op sp227_accepted _ = ()
  val op sp227_accepted = TDB.find "sp227_accepted"
  fun op sp226_def _ = () val op sp226_def = TDB.find "sp226_def"
  fun op sp226_accepted _ = ()
  val op sp226_accepted = TDB.find "sp226_accepted"
  fun op sp225_def _ = () val op sp225_def = TDB.find "sp225_def"
  fun op sp225_accepted _ = ()
  val op sp225_accepted = TDB.find "sp225_accepted"
  fun op sp224_def _ = () val op sp224_def = TDB.find "sp224_def"
  fun op sp224_accepted _ = ()
  val op sp224_accepted = TDB.find "sp224_accepted"
  fun op sp223_def _ = () val op sp223_def = TDB.find "sp223_def"
  fun op sp223_accepted _ = ()
  val op sp223_accepted = TDB.find "sp223_accepted"
  fun op sp222_def _ = () val op sp222_def = TDB.find "sp222_def"
  fun op sp222_accepted _ = ()
  val op sp222_accepted = TDB.find "sp222_accepted"
  fun op sp221_def _ = () val op sp221_def = TDB.find "sp221_def"
  fun op sp221_accepted _ = ()
  val op sp221_accepted = TDB.find "sp221_accepted"
  fun op sp220_def _ = () val op sp220_def = TDB.find "sp220_def"
  fun op sp220_accepted _ = ()
  val op sp220_accepted = TDB.find "sp220_accepted"
  fun op sp21_def _ = () val op sp21_def = TDB.find "sp21_def"
  fun op sp21_accepted _ = ()
  val op sp21_accepted = TDB.find "sp21_accepted"
  fun op sp219_def _ = () val op sp219_def = TDB.find "sp219_def"
  fun op sp219_accepted _ = ()
  val op sp219_accepted = TDB.find "sp219_accepted"
  fun op sp218_def _ = () val op sp218_def = TDB.find "sp218_def"
  fun op sp218_accepted _ = ()
  val op sp218_accepted = TDB.find "sp218_accepted"
  fun op sp217_def _ = () val op sp217_def = TDB.find "sp217_def"
  fun op sp217_accepted _ = ()
  val op sp217_accepted = TDB.find "sp217_accepted"
  fun op sp216_def _ = () val op sp216_def = TDB.find "sp216_def"
  fun op sp216_accepted _ = ()
  val op sp216_accepted = TDB.find "sp216_accepted"
  fun op sp215_def _ = () val op sp215_def = TDB.find "sp215_def"
  fun op sp215_accepted _ = ()
  val op sp215_accepted = TDB.find "sp215_accepted"
  fun op sp214_def _ = () val op sp214_def = TDB.find "sp214_def"
  fun op sp214_accepted _ = ()
  val op sp214_accepted = TDB.find "sp214_accepted"
  fun op sp213_def _ = () val op sp213_def = TDB.find "sp213_def"
  fun op sp213_accepted _ = ()
  val op sp213_accepted = TDB.find "sp213_accepted"
  fun op sp212_def _ = () val op sp212_def = TDB.find "sp212_def"
  fun op sp212_accepted _ = ()
  val op sp212_accepted = TDB.find "sp212_accepted"
  fun op sp211_def _ = () val op sp211_def = TDB.find "sp211_def"
  fun op sp211_accepted _ = ()
  val op sp211_accepted = TDB.find "sp211_accepted"
  fun op sp210_def _ = () val op sp210_def = TDB.find "sp210_def"
  fun op sp210_accepted _ = ()
  val op sp210_accepted = TDB.find "sp210_accepted"
  fun op sp20_def _ = () val op sp20_def = TDB.find "sp20_def"
  fun op sp20_accepted _ = ()
  val op sp20_accepted = TDB.find "sp20_accepted"
  fun op sp209_def _ = () val op sp209_def = TDB.find "sp209_def"
  fun op sp209_accepted _ = ()
  val op sp209_accepted = TDB.find "sp209_accepted"
  fun op sp208_def _ = () val op sp208_def = TDB.find "sp208_def"
  fun op sp208_accepted _ = ()
  val op sp208_accepted = TDB.find "sp208_accepted"
  fun op sp207_def _ = () val op sp207_def = TDB.find "sp207_def"
  fun op sp207_accepted _ = ()
  val op sp207_accepted = TDB.find "sp207_accepted"
  fun op sp206_def _ = () val op sp206_def = TDB.find "sp206_def"
  fun op sp206_accepted _ = ()
  val op sp206_accepted = TDB.find "sp206_accepted"
  fun op sp205_def _ = () val op sp205_def = TDB.find "sp205_def"
  fun op sp205_accepted _ = ()
  val op sp205_accepted = TDB.find "sp205_accepted"
  fun op sp204_def _ = () val op sp204_def = TDB.find "sp204_def"
  fun op sp204_accepted _ = ()
  val op sp204_accepted = TDB.find "sp204_accepted"
  fun op sp203_def _ = () val op sp203_def = TDB.find "sp203_def"
  fun op sp203_accepted _ = ()
  val op sp203_accepted = TDB.find "sp203_accepted"
  fun op sp202_def _ = () val op sp202_def = TDB.find "sp202_def"
  fun op sp202_accepted _ = ()
  val op sp202_accepted = TDB.find "sp202_accepted"
  fun op sp201_def _ = () val op sp201_def = TDB.find "sp201_def"
  fun op sp201_accepted _ = ()
  val op sp201_accepted = TDB.find "sp201_accepted"
  fun op sp200_def _ = () val op sp200_def = TDB.find "sp200_def"
  fun op sp200_accepted _ = ()
  val op sp200_accepted = TDB.find "sp200_accepted"
  fun op sp1_def _ = () val op sp1_def = TDB.find "sp1_def"
  fun op sp1_accepted _ = () val op sp1_accepted = TDB.find "sp1_accepted"
  fun op sp19_def _ = () val op sp19_def = TDB.find "sp19_def"
  fun op sp19_accepted _ = ()
  val op sp19_accepted = TDB.find "sp19_accepted"
  fun op sp199_def _ = () val op sp199_def = TDB.find "sp199_def"
  fun op sp199_accepted _ = ()
  val op sp199_accepted = TDB.find "sp199_accepted"
  fun op sp198_def _ = () val op sp198_def = TDB.find "sp198_def"
  fun op sp198_accepted _ = ()
  val op sp198_accepted = TDB.find "sp198_accepted"
  fun op sp197_def _ = () val op sp197_def = TDB.find "sp197_def"
  fun op sp197_accepted _ = ()
  val op sp197_accepted = TDB.find "sp197_accepted"
  fun op sp196_def _ = () val op sp196_def = TDB.find "sp196_def"
  fun op sp196_accepted _ = ()
  val op sp196_accepted = TDB.find "sp196_accepted"
  fun op sp195_def _ = () val op sp195_def = TDB.find "sp195_def"
  fun op sp195_accepted _ = ()
  val op sp195_accepted = TDB.find "sp195_accepted"
  fun op sp194_def _ = () val op sp194_def = TDB.find "sp194_def"
  fun op sp194_accepted _ = ()
  val op sp194_accepted = TDB.find "sp194_accepted"
  fun op sp193_def _ = () val op sp193_def = TDB.find "sp193_def"
  fun op sp193_accepted _ = ()
  val op sp193_accepted = TDB.find "sp193_accepted"
  fun op sp192_def _ = () val op sp192_def = TDB.find "sp192_def"
  fun op sp192_accepted _ = ()
  val op sp192_accepted = TDB.find "sp192_accepted"
  fun op sp191_def _ = () val op sp191_def = TDB.find "sp191_def"
  fun op sp191_accepted _ = ()
  val op sp191_accepted = TDB.find "sp191_accepted"
  fun op sp190_def _ = () val op sp190_def = TDB.find "sp190_def"
  fun op sp190_accepted _ = ()
  val op sp190_accepted = TDB.find "sp190_accepted"
  fun op sp18_def _ = () val op sp18_def = TDB.find "sp18_def"
  fun op sp18_accepted _ = ()
  val op sp18_accepted = TDB.find "sp18_accepted"
  fun op sp189_def _ = () val op sp189_def = TDB.find "sp189_def"
  fun op sp189_accepted _ = ()
  val op sp189_accepted = TDB.find "sp189_accepted"
  fun op sp188_def _ = () val op sp188_def = TDB.find "sp188_def"
  fun op sp188_accepted _ = ()
  val op sp188_accepted = TDB.find "sp188_accepted"
  fun op sp187_def _ = () val op sp187_def = TDB.find "sp187_def"
  fun op sp187_accepted _ = ()
  val op sp187_accepted = TDB.find "sp187_accepted"
  fun op sp186_def _ = () val op sp186_def = TDB.find "sp186_def"
  fun op sp186_accepted _ = ()
  val op sp186_accepted = TDB.find "sp186_accepted"
  fun op sp185_def _ = () val op sp185_def = TDB.find "sp185_def"
  fun op sp185_accepted _ = ()
  val op sp185_accepted = TDB.find "sp185_accepted"
  fun op sp184_def _ = () val op sp184_def = TDB.find "sp184_def"
  fun op sp184_accepted _ = ()
  val op sp184_accepted = TDB.find "sp184_accepted"
  fun op sp183_def _ = () val op sp183_def = TDB.find "sp183_def"
  fun op sp183_accepted _ = ()
  val op sp183_accepted = TDB.find "sp183_accepted"
  fun op sp182_def _ = () val op sp182_def = TDB.find "sp182_def"
  fun op sp182_accepted _ = ()
  val op sp182_accepted = TDB.find "sp182_accepted"
  fun op sp181_def _ = () val op sp181_def = TDB.find "sp181_def"
  fun op sp181_accepted _ = ()
  val op sp181_accepted = TDB.find "sp181_accepted"
  fun op sp180_def _ = () val op sp180_def = TDB.find "sp180_def"
  fun op sp180_accepted _ = ()
  val op sp180_accepted = TDB.find "sp180_accepted"
  fun op sp17_def _ = () val op sp17_def = TDB.find "sp17_def"
  fun op sp17_accepted _ = ()
  val op sp17_accepted = TDB.find "sp17_accepted"
  fun op sp179_def _ = () val op sp179_def = TDB.find "sp179_def"
  fun op sp179_accepted _ = ()
  val op sp179_accepted = TDB.find "sp179_accepted"
  fun op sp178_def _ = () val op sp178_def = TDB.find "sp178_def"
  fun op sp178_accepted _ = ()
  val op sp178_accepted = TDB.find "sp178_accepted"
  fun op sp177_def _ = () val op sp177_def = TDB.find "sp177_def"
  fun op sp177_accepted _ = ()
  val op sp177_accepted = TDB.find "sp177_accepted"
  fun op sp176_def _ = () val op sp176_def = TDB.find "sp176_def"
  fun op sp176_accepted _ = ()
  val op sp176_accepted = TDB.find "sp176_accepted"
  fun op sp175_def _ = () val op sp175_def = TDB.find "sp175_def"
  fun op sp175_accepted _ = ()
  val op sp175_accepted = TDB.find "sp175_accepted"
  fun op sp174_def _ = () val op sp174_def = TDB.find "sp174_def"
  fun op sp174_accepted _ = ()
  val op sp174_accepted = TDB.find "sp174_accepted"
  fun op sp173_def _ = () val op sp173_def = TDB.find "sp173_def"
  fun op sp173_accepted _ = ()
  val op sp173_accepted = TDB.find "sp173_accepted"
  fun op sp172_def _ = () val op sp172_def = TDB.find "sp172_def"
  fun op sp172_accepted _ = ()
  val op sp172_accepted = TDB.find "sp172_accepted"
  fun op sp171_def _ = () val op sp171_def = TDB.find "sp171_def"
  fun op sp171_accepted _ = ()
  val op sp171_accepted = TDB.find "sp171_accepted"
  fun op sp170_def _ = () val op sp170_def = TDB.find "sp170_def"
  fun op sp170_accepted _ = ()
  val op sp170_accepted = TDB.find "sp170_accepted"
  fun op sp16_def _ = () val op sp16_def = TDB.find "sp16_def"
  fun op sp16_accepted _ = ()
  val op sp16_accepted = TDB.find "sp16_accepted"
  fun op sp169_def _ = () val op sp169_def = TDB.find "sp169_def"
  fun op sp169_accepted _ = ()
  val op sp169_accepted = TDB.find "sp169_accepted"
  fun op sp168_def _ = () val op sp168_def = TDB.find "sp168_def"
  fun op sp168_accepted _ = ()
  val op sp168_accepted = TDB.find "sp168_accepted"
  fun op sp167_def _ = () val op sp167_def = TDB.find "sp167_def"
  fun op sp167_accepted _ = ()
  val op sp167_accepted = TDB.find "sp167_accepted"
  fun op sp166_def _ = () val op sp166_def = TDB.find "sp166_def"
  fun op sp166_accepted _ = ()
  val op sp166_accepted = TDB.find "sp166_accepted"
  fun op sp165_def _ = () val op sp165_def = TDB.find "sp165_def"
  fun op sp165_accepted _ = ()
  val op sp165_accepted = TDB.find "sp165_accepted"
  fun op sp164_def _ = () val op sp164_def = TDB.find "sp164_def"
  fun op sp164_accepted _ = ()
  val op sp164_accepted = TDB.find "sp164_accepted"
  fun op sp163_def _ = () val op sp163_def = TDB.find "sp163_def"
  fun op sp163_accepted _ = ()
  val op sp163_accepted = TDB.find "sp163_accepted"
  fun op sp162_def _ = () val op sp162_def = TDB.find "sp162_def"
  fun op sp162_accepted _ = ()
  val op sp162_accepted = TDB.find "sp162_accepted"
  fun op sp161_def _ = () val op sp161_def = TDB.find "sp161_def"
  fun op sp161_accepted _ = ()
  val op sp161_accepted = TDB.find "sp161_accepted"
  fun op sp160_def _ = () val op sp160_def = TDB.find "sp160_def"
  fun op sp160_accepted _ = ()
  val op sp160_accepted = TDB.find "sp160_accepted"
  fun op sp15_def _ = () val op sp15_def = TDB.find "sp15_def"
  fun op sp15_accepted _ = ()
  val op sp15_accepted = TDB.find "sp15_accepted"
  fun op sp159_def _ = () val op sp159_def = TDB.find "sp159_def"
  fun op sp159_accepted _ = ()
  val op sp159_accepted = TDB.find "sp159_accepted"
  fun op sp158_def _ = () val op sp158_def = TDB.find "sp158_def"
  fun op sp158_accepted _ = ()
  val op sp158_accepted = TDB.find "sp158_accepted"
  fun op sp157_def _ = () val op sp157_def = TDB.find "sp157_def"
  fun op sp157_accepted _ = ()
  val op sp157_accepted = TDB.find "sp157_accepted"
  fun op sp156_def _ = () val op sp156_def = TDB.find "sp156_def"
  fun op sp156_accepted _ = ()
  val op sp156_accepted = TDB.find "sp156_accepted"
  fun op sp155_def _ = () val op sp155_def = TDB.find "sp155_def"
  fun op sp155_accepted _ = ()
  val op sp155_accepted = TDB.find "sp155_accepted"
  fun op sp154_def _ = () val op sp154_def = TDB.find "sp154_def"
  fun op sp154_accepted _ = ()
  val op sp154_accepted = TDB.find "sp154_accepted"
  fun op sp153_def _ = () val op sp153_def = TDB.find "sp153_def"
  fun op sp153_accepted _ = ()
  val op sp153_accepted = TDB.find "sp153_accepted"
  fun op sp152_def _ = () val op sp152_def = TDB.find "sp152_def"
  fun op sp152_accepted _ = ()
  val op sp152_accepted = TDB.find "sp152_accepted"
  fun op sp151_def _ = () val op sp151_def = TDB.find "sp151_def"
  fun op sp151_accepted _ = ()
  val op sp151_accepted = TDB.find "sp151_accepted"
  fun op sp150_def _ = () val op sp150_def = TDB.find "sp150_def"
  fun op sp150_accepted _ = ()
  val op sp150_accepted = TDB.find "sp150_accepted"
  fun op sp14_def _ = () val op sp14_def = TDB.find "sp14_def"
  fun op sp14_accepted _ = ()
  val op sp14_accepted = TDB.find "sp14_accepted"
  fun op sp149_def _ = () val op sp149_def = TDB.find "sp149_def"
  fun op sp149_accepted _ = ()
  val op sp149_accepted = TDB.find "sp149_accepted"
  fun op sp148_def _ = () val op sp148_def = TDB.find "sp148_def"
  fun op sp148_accepted _ = ()
  val op sp148_accepted = TDB.find "sp148_accepted"
  fun op sp147_def _ = () val op sp147_def = TDB.find "sp147_def"
  fun op sp147_accepted _ = ()
  val op sp147_accepted = TDB.find "sp147_accepted"
  fun op sp146_def _ = () val op sp146_def = TDB.find "sp146_def"
  fun op sp146_accepted _ = ()
  val op sp146_accepted = TDB.find "sp146_accepted"
  fun op sp145_def _ = () val op sp145_def = TDB.find "sp145_def"
  fun op sp145_accepted _ = ()
  val op sp145_accepted = TDB.find "sp145_accepted"
  fun op sp144_def _ = () val op sp144_def = TDB.find "sp144_def"
  fun op sp144_accepted _ = ()
  val op sp144_accepted = TDB.find "sp144_accepted"
  fun op sp143_def _ = () val op sp143_def = TDB.find "sp143_def"
  fun op sp143_accepted _ = ()
  val op sp143_accepted = TDB.find "sp143_accepted"
  fun op sp142_def _ = () val op sp142_def = TDB.find "sp142_def"
  fun op sp142_accepted _ = ()
  val op sp142_accepted = TDB.find "sp142_accepted"
  fun op sp141_def _ = () val op sp141_def = TDB.find "sp141_def"
  fun op sp141_accepted _ = ()
  val op sp141_accepted = TDB.find "sp141_accepted"
  fun op sp140_def _ = () val op sp140_def = TDB.find "sp140_def"
  fun op sp140_accepted _ = ()
  val op sp140_accepted = TDB.find "sp140_accepted"
  fun op sp13_def _ = () val op sp13_def = TDB.find "sp13_def"
  fun op sp13_accepted _ = ()
  val op sp13_accepted = TDB.find "sp13_accepted"
  fun op sp139_def _ = () val op sp139_def = TDB.find "sp139_def"
  fun op sp139_accepted _ = ()
  val op sp139_accepted = TDB.find "sp139_accepted"
  fun op sp138_def _ = () val op sp138_def = TDB.find "sp138_def"
  fun op sp138_accepted _ = ()
  val op sp138_accepted = TDB.find "sp138_accepted"
  fun op sp137_def _ = () val op sp137_def = TDB.find "sp137_def"
  fun op sp137_accepted _ = ()
  val op sp137_accepted = TDB.find "sp137_accepted"
  fun op sp136_def _ = () val op sp136_def = TDB.find "sp136_def"
  fun op sp136_accepted _ = ()
  val op sp136_accepted = TDB.find "sp136_accepted"
  fun op sp135_def _ = () val op sp135_def = TDB.find "sp135_def"
  fun op sp135_accepted _ = ()
  val op sp135_accepted = TDB.find "sp135_accepted"
  fun op sp134_def _ = () val op sp134_def = TDB.find "sp134_def"
  fun op sp134_accepted _ = ()
  val op sp134_accepted = TDB.find "sp134_accepted"
  fun op sp133_def _ = () val op sp133_def = TDB.find "sp133_def"
  fun op sp133_accepted _ = ()
  val op sp133_accepted = TDB.find "sp133_accepted"
  fun op sp132_def _ = () val op sp132_def = TDB.find "sp132_def"
  fun op sp132_accepted _ = ()
  val op sp132_accepted = TDB.find "sp132_accepted"
  fun op sp131_def _ = () val op sp131_def = TDB.find "sp131_def"
  fun op sp131_accepted _ = ()
  val op sp131_accepted = TDB.find "sp131_accepted"
  fun op sp130_def _ = () val op sp130_def = TDB.find "sp130_def"
  fun op sp130_accepted _ = ()
  val op sp130_accepted = TDB.find "sp130_accepted"
  fun op sp12_def _ = () val op sp12_def = TDB.find "sp12_def"
  fun op sp12_accepted _ = ()
  val op sp12_accepted = TDB.find "sp12_accepted"
  fun op sp129_def _ = () val op sp129_def = TDB.find "sp129_def"
  fun op sp129_accepted _ = ()
  val op sp129_accepted = TDB.find "sp129_accepted"
  fun op sp128_def _ = () val op sp128_def = TDB.find "sp128_def"
  fun op sp128_accepted _ = ()
  val op sp128_accepted = TDB.find "sp128_accepted"
  fun op sp127_def _ = () val op sp127_def = TDB.find "sp127_def"
  fun op sp127_accepted _ = ()
  val op sp127_accepted = TDB.find "sp127_accepted"
  fun op sp126_def _ = () val op sp126_def = TDB.find "sp126_def"
  fun op sp126_accepted _ = ()
  val op sp126_accepted = TDB.find "sp126_accepted"
  fun op sp125_def _ = () val op sp125_def = TDB.find "sp125_def"
  fun op sp125_accepted _ = ()
  val op sp125_accepted = TDB.find "sp125_accepted"
  fun op sp124_def _ = () val op sp124_def = TDB.find "sp124_def"
  fun op sp124_accepted _ = ()
  val op sp124_accepted = TDB.find "sp124_accepted"
  fun op sp123_def _ = () val op sp123_def = TDB.find "sp123_def"
  fun op sp123_accepted _ = ()
  val op sp123_accepted = TDB.find "sp123_accepted"
  fun op sp122_def _ = () val op sp122_def = TDB.find "sp122_def"
  fun op sp122_accepted _ = ()
  val op sp122_accepted = TDB.find "sp122_accepted"
  fun op sp121_def _ = () val op sp121_def = TDB.find "sp121_def"
  fun op sp121_accepted _ = ()
  val op sp121_accepted = TDB.find "sp121_accepted"
  fun op sp120_def _ = () val op sp120_def = TDB.find "sp120_def"
  fun op sp120_accepted _ = ()
  val op sp120_accepted = TDB.find "sp120_accepted"
  fun op sp11_def _ = () val op sp11_def = TDB.find "sp11_def"
  fun op sp11_accepted _ = ()
  val op sp11_accepted = TDB.find "sp11_accepted"
  fun op sp119_def _ = () val op sp119_def = TDB.find "sp119_def"
  fun op sp119_accepted _ = ()
  val op sp119_accepted = TDB.find "sp119_accepted"
  fun op sp118_def _ = () val op sp118_def = TDB.find "sp118_def"
  fun op sp118_accepted _ = ()
  val op sp118_accepted = TDB.find "sp118_accepted"
  fun op sp117_def _ = () val op sp117_def = TDB.find "sp117_def"
  fun op sp117_accepted _ = ()
  val op sp117_accepted = TDB.find "sp117_accepted"
  fun op sp116_def _ = () val op sp116_def = TDB.find "sp116_def"
  fun op sp116_accepted _ = ()
  val op sp116_accepted = TDB.find "sp116_accepted"
  fun op sp115_def _ = () val op sp115_def = TDB.find "sp115_def"
  fun op sp115_accepted _ = ()
  val op sp115_accepted = TDB.find "sp115_accepted"
  fun op sp114_def _ = () val op sp114_def = TDB.find "sp114_def"
  fun op sp114_accepted _ = ()
  val op sp114_accepted = TDB.find "sp114_accepted"
  fun op sp113_def _ = () val op sp113_def = TDB.find "sp113_def"
  fun op sp113_accepted _ = ()
  val op sp113_accepted = TDB.find "sp113_accepted"
  fun op sp112_def _ = () val op sp112_def = TDB.find "sp112_def"
  fun op sp112_accepted _ = ()
  val op sp112_accepted = TDB.find "sp112_accepted"
  fun op sp111_def _ = () val op sp111_def = TDB.find "sp111_def"
  fun op sp111_accepted _ = ()
  val op sp111_accepted = TDB.find "sp111_accepted"
  fun op sp110_def _ = () val op sp110_def = TDB.find "sp110_def"
  fun op sp110_accepted _ = ()
  val op sp110_accepted = TDB.find "sp110_accepted"
  fun op sp10_def _ = () val op sp10_def = TDB.find "sp10_def"
  fun op sp10_accepted _ = ()
  val op sp10_accepted = TDB.find "sp10_accepted"
  fun op sp109_def _ = () val op sp109_def = TDB.find "sp109_def"
  fun op sp109_accepted _ = ()
  val op sp109_accepted = TDB.find "sp109_accepted"
  fun op sp108_def _ = () val op sp108_def = TDB.find "sp108_def"
  fun op sp108_accepted _ = ()
  val op sp108_accepted = TDB.find "sp108_accepted"
  fun op sp107_def _ = () val op sp107_def = TDB.find "sp107_def"
  fun op sp107_accepted _ = ()
  val op sp107_accepted = TDB.find "sp107_accepted"
  fun op sp106_def _ = () val op sp106_def = TDB.find "sp106_def"
  fun op sp106_accepted _ = ()
  val op sp106_accepted = TDB.find "sp106_accepted"
  fun op sp105_def _ = () val op sp105_def = TDB.find "sp105_def"
  fun op sp105_accepted _ = ()
  val op sp105_accepted = TDB.find "sp105_accepted"
  fun op sp104_def _ = () val op sp104_def = TDB.find "sp104_def"
  fun op sp104_accepted _ = ()
  val op sp104_accepted = TDB.find "sp104_accepted"
  fun op sp103_def _ = () val op sp103_def = TDB.find "sp103_def"
  fun op sp103_accepted _ = ()
  val op sp103_accepted = TDB.find "sp103_accepted"
  fun op sp102_def _ = () val op sp102_def = TDB.find "sp102_def"
  fun op sp102_accepted _ = ()
  val op sp102_accepted = TDB.find "sp102_accepted"
  fun op sp101_def _ = () val op sp101_def = TDB.find "sp101_def"
  fun op sp101_accepted _ = ()
  val op sp101_accepted = TDB.find "sp101_accepted"
  fun op sp100_def _ = () val op sp100_def = TDB.find "sp100_def"
  fun op sp100_accepted _ = ()
  val op sp100_accepted = TDB.find "sp100_accepted"
  fun op sp0_def _ = () val op sp0_def = TDB.find "sp0_def"
  fun op sp0_accepted _ = () val op sp0_accepted = TDB.find "sp0_accepted"
  fun op sm8_ok _ = () val op sm8_ok = TDB.find "sm8_ok"
  fun op sm8_def _ = () val op sm8_def = TDB.find "sm8_def"
  fun op sm52_ok _ = () val op sm52_ok = TDB.find "sm52_ok"
  fun op sm52_def _ = () val op sm52_def = TDB.find "sm52_def"
  fun op sm4_ok _ = () val op sm4_ok = TDB.find "sm4_ok"
  fun op sm4_def _ = () val op sm4_def = TDB.find "sm4_def"
  fun op sm48_ok _ = () val op sm48_ok = TDB.find "sm48_ok"
  fun op sm48_def _ = () val op sm48_def = TDB.find "sm48_def"
  fun op sm44_ok _ = () val op sm44_ok = TDB.find "sm44_ok"
  fun op sm44_def _ = () val op sm44_def = TDB.find "sm44_def"
  fun op sm40_ok _ = () val op sm40_ok = TDB.find "sm40_ok"
  fun op sm40_def _ = () val op sm40_def = TDB.find "sm40_def"
  fun op sm36_ok _ = () val op sm36_ok = TDB.find "sm36_ok"
  fun op sm36_def _ = () val op sm36_def = TDB.find "sm36_def"
  fun op sm32_ok _ = () val op sm32_ok = TDB.find "sm32_ok"
  fun op sm32_def _ = () val op sm32_def = TDB.find "sm32_def"
  fun op sm28_ok _ = () val op sm28_ok = TDB.find "sm28_ok"
  fun op sm28_def _ = () val op sm28_def = TDB.find "sm28_def"
  fun op sm24_ok _ = () val op sm24_ok = TDB.find "sm24_ok"
  fun op sm24_def _ = () val op sm24_def = TDB.find "sm24_def"
  fun op sm20_ok _ = () val op sm20_ok = TDB.find "sm20_ok"
  fun op sm20_def _ = () val op sm20_def = TDB.find "sm20_def"
  fun op sm16_ok _ = () val op sm16_ok = TDB.find "sm16_ok"
  fun op sm16_def _ = () val op sm16_def = TDB.find "sm16_def"
  fun op sm12_ok _ = () val op sm12_ok = TDB.find "sm12_ok"
  fun op sm12_def _ = () val op sm12_def = TDB.find "sm12_def"
  fun op sm0_ok _ = () val op sm0_ok = TDB.find "sm0_ok"
  fun op sm0_def _ = () val op sm0_def = TDB.find "sm0_def"
  fun op sg9_ok _ = () val op sg9_ok = TDB.find "sg9_ok"
  fun op sg9_def _ = () val op sg9_def = TDB.find "sg9_def"
  fun op sg8_ok _ = () val op sg8_ok = TDB.find "sg8_ok"
  fun op sg8_def _ = () val op sg8_def = TDB.find "sg8_def"
  fun op sg7_ok _ = () val op sg7_ok = TDB.find "sg7_ok"
  fun op sg7_def _ = () val op sg7_def = TDB.find "sg7_def"
  fun op sg6_ok _ = () val op sg6_ok = TDB.find "sg6_ok"
  fun op sg6_def _ = () val op sg6_def = TDB.find "sg6_def"
  fun op sg5_ok _ = () val op sg5_ok = TDB.find "sg5_ok"
  fun op sg5_def _ = () val op sg5_def = TDB.find "sg5_def"
  fun op sg4_ok _ = () val op sg4_ok = TDB.find "sg4_ok"
  fun op sg4_def _ = () val op sg4_def = TDB.find "sg4_def"
  fun op sg3_ok _ = () val op sg3_ok = TDB.find "sg3_ok"
  fun op sg3_def _ = () val op sg3_def = TDB.find "sg3_def"
  fun op sg39_ok _ = () val op sg39_ok = TDB.find "sg39_ok"
  fun op sg39_def _ = () val op sg39_def = TDB.find "sg39_def"
  fun op sg38_ok _ = () val op sg38_ok = TDB.find "sg38_ok"
  fun op sg38_def _ = () val op sg38_def = TDB.find "sg38_def"
  fun op sg37_ok _ = () val op sg37_ok = TDB.find "sg37_ok"
  fun op sg37_def _ = () val op sg37_def = TDB.find "sg37_def"
  fun op sg36_ok _ = () val op sg36_ok = TDB.find "sg36_ok"
  fun op sg36_def _ = () val op sg36_def = TDB.find "sg36_def"
  fun op sg35_ok _ = () val op sg35_ok = TDB.find "sg35_ok"
  fun op sg35_def _ = () val op sg35_def = TDB.find "sg35_def"
  fun op sg34_ok _ = () val op sg34_ok = TDB.find "sg34_ok"
  fun op sg34_def _ = () val op sg34_def = TDB.find "sg34_def"
  fun op sg33_ok _ = () val op sg33_ok = TDB.find "sg33_ok"
  fun op sg33_def _ = () val op sg33_def = TDB.find "sg33_def"
  fun op sg32_ok _ = () val op sg32_ok = TDB.find "sg32_ok"
  fun op sg32_def _ = () val op sg32_def = TDB.find "sg32_def"
  fun op sg31_ok _ = () val op sg31_ok = TDB.find "sg31_ok"
  fun op sg31_def _ = () val op sg31_def = TDB.find "sg31_def"
  fun op sg30_ok _ = () val op sg30_ok = TDB.find "sg30_ok"
  fun op sg30_def _ = () val op sg30_def = TDB.find "sg30_def"
  fun op sg2_ok _ = () val op sg2_ok = TDB.find "sg2_ok"
  fun op sg2_def _ = () val op sg2_def = TDB.find "sg2_def"
  fun op sg29_ok _ = () val op sg29_ok = TDB.find "sg29_ok"
  fun op sg29_def _ = () val op sg29_def = TDB.find "sg29_def"
  fun op sg28_ok _ = () val op sg28_ok = TDB.find "sg28_ok"
  fun op sg28_def _ = () val op sg28_def = TDB.find "sg28_def"
  fun op sg27_ok _ = () val op sg27_ok = TDB.find "sg27_ok"
  fun op sg27_def _ = () val op sg27_def = TDB.find "sg27_def"
  fun op sg26_ok _ = () val op sg26_ok = TDB.find "sg26_ok"
  fun op sg26_def _ = () val op sg26_def = TDB.find "sg26_def"
  fun op sg25_ok _ = () val op sg25_ok = TDB.find "sg25_ok"
  fun op sg25_def _ = () val op sg25_def = TDB.find "sg25_def"
  fun op sg24_ok _ = () val op sg24_ok = TDB.find "sg24_ok"
  fun op sg24_def _ = () val op sg24_def = TDB.find "sg24_def"
  fun op sg23_ok _ = () val op sg23_ok = TDB.find "sg23_ok"
  fun op sg23_def _ = () val op sg23_def = TDB.find "sg23_def"
  fun op sg22_ok _ = () val op sg22_ok = TDB.find "sg22_ok"
  fun op sg22_def _ = () val op sg22_def = TDB.find "sg22_def"
  fun op sg21_ok _ = () val op sg21_ok = TDB.find "sg21_ok"
  fun op sg21_def _ = () val op sg21_def = TDB.find "sg21_def"
  fun op sg20_ok _ = () val op sg20_ok = TDB.find "sg20_ok"
  fun op sg20_def _ = () val op sg20_def = TDB.find "sg20_def"
  fun op sg1_ok _ = () val op sg1_ok = TDB.find "sg1_ok"
  fun op sg1_def _ = () val op sg1_def = TDB.find "sg1_def"
  fun op sg19_ok _ = () val op sg19_ok = TDB.find "sg19_ok"
  fun op sg19_def _ = () val op sg19_def = TDB.find "sg19_def"
  fun op sg18_ok _ = () val op sg18_ok = TDB.find "sg18_ok"
  fun op sg18_def _ = () val op sg18_def = TDB.find "sg18_def"
  fun op sg17_ok _ = () val op sg17_ok = TDB.find "sg17_ok"
  fun op sg17_def _ = () val op sg17_def = TDB.find "sg17_def"
  fun op sg16_ok _ = () val op sg16_ok = TDB.find "sg16_ok"
  fun op sg16_def _ = () val op sg16_def = TDB.find "sg16_def"
  fun op sg15_ok _ = () val op sg15_ok = TDB.find "sg15_ok"
  fun op sg15_def _ = () val op sg15_def = TDB.find "sg15_def"
  fun op sg14_ok _ = () val op sg14_ok = TDB.find "sg14_ok"
  fun op sg14_def _ = () val op sg14_def = TDB.find "sg14_def"
  fun op sg13_ok _ = () val op sg13_ok = TDB.find "sg13_ok"
  fun op sg13_def _ = () val op sg13_def = TDB.find "sg13_def"
  fun op sg12_ok _ = () val op sg12_ok = TDB.find "sg12_ok"
  fun op sg12_def _ = () val op sg12_def = TDB.find "sg12_def"
  fun op sg11_ok _ = () val op sg11_ok = TDB.find "sg11_ok"
  fun op sg11_def _ = () val op sg11_def = TDB.find "sg11_def"
  fun op sg10_ok _ = () val op sg10_ok = TDB.find "sg10_ok"
  fun op sg10_def _ = () val op sg10_def = TDB.find "sg10_def"
  fun op sg0_ok _ = () val op sg0_ok = TDB.find "sg0_ok"
  fun op sg0_def _ = () val op sg0_def = TDB.find "sg0_def"
  
val _ = if !Globals.print_thy_loads then TextIO.print "done\n" else ()
val _ = Theory.load_complete "StripParameterAcceptance"

end
