structure StripParameterTheory :> StripParameterTheory =
struct
  
  val _ = if !Globals.print_thy_loads
    then TextIO.print "Loading StripParameterTheory ... "
    else ()
  
  open Type Term Thm
  local open OmegaTheory in end;
  
  structure TDB = struct
    val path =
      OS.Path.base (#(FILE)) ^ ".dat"
    val timestamp = HOLFileSys.modTime path
    val thydata = 
      TheoryReader.load_thydata {
        thyname = "StripParameter",
        hash = "47a6f36947bdd5d5a977aaa77bfb7fb63dc73204",
        path = path
      }
    fun find s = #1 (valOf (Symtab.lookup thydata s))
  end
  val () = Theory.record_metadata
    "StripParameter" {timestamp=TDB.timestamp, path=TDB.path}
  
  fun op row_def _ = () val op row_def = TDB.find "row_def"
  fun op prod_def _ = () val op prod_def = TDB.find "prod_def"
  fun op numerator_def _ = ()
  val op numerator_def = TDB.find "numerator_def"
  fun op mass_def _ = () val op mass_def = TDB.find "mass_def"
  fun op geometry_def _ = () val op geometry_def = TDB.find "geometry_def"
  fun op denominator_def _ = ()
  val op denominator_def = TDB.find "denominator_def"
  
val _ = if !Globals.print_thy_loads then TextIO.print "done\n" else ()
val _ = Theory.load_complete "StripParameter"

end
