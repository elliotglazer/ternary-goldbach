signature StripParameterTheory =
sig
  type thm = Thm.thm
  
  (*  Definitions  *)
    val denominator_def : thm
    val geometry_def : thm
    val mass_def : thm
    val numerator_def : thm
    val prod_def : thm
    val row_def : thm
end
