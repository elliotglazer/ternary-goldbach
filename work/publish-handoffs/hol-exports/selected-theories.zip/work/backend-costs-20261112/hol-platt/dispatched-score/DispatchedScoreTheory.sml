structure DispatchedScoreTheory :> DispatchedScoreTheory =
struct
  
  val _ = if !Globals.print_thy_loads
    then TextIO.print "Loading DispatchedScoreTheory ... "
    else ()
  
  open Type Term Thm
  local open FallbackScoreTheory SectorEnclosureTheory in end;
  
  structure TDB = struct
    val path =
      OS.Path.base (#(FILE)) ^ ".dat"
    val timestamp = HOLFileSys.modTime path
    val thydata = 
      TheoryReader.load_thydata {
        thyname = "DispatchedScore",
        hash = "2e89270aaec77715b984ff9cc2bcd44c396792ff",
        path = path
      }
    fun find s = #1 (valOf (Symtab.lookup thydata s))
  end
  val () = Theory.record_metadata
    "DispatchedScore" {timestamp=TDB.timestamp, path=TDB.path}
  
  fun op dispatched_sign _ = ()
  val op dispatched_sign = TDB.find "dispatched_sign"
  
val _ = if !Globals.print_thy_loads then TextIO.print "done\n" else ()
val _ = Theory.load_complete "DispatchedScore"

end
