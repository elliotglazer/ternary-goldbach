structure InclusiveBracketTheory :> InclusiveBracketTheory =
struct
  
  val _ = if !Globals.print_thy_loads
    then TextIO.print "Loading InclusiveBracketTheory ... "
    else ()
  
  open Type Term Thm
  local open ZeroFreeGapTheory in end;
  
  structure TDB = struct
    val path =
      OS.Path.base (#(FILE)) ^ ".dat"
    val timestamp = HOLFileSys.modTime path
    val thydata = 
      TheoryReader.load_thydata {
        thyname = "InclusiveBracket",
        hash = "96e44aeff5962cf925e1532c95ea32b72e52142d",
        path = path
      }
    fun find s = #1 (valOf (Symtab.lookup thydata s))
  end
  val () = Theory.record_metadata
    "InclusiveBracket" {timestamp=TDB.timestamp, path=TDB.path}
  
  fun op translated_sample_admissible _ = ()
  val op translated_sample_admissible = TDB.find
    "translated_sample_admissible"
  fun op translated_aux_weights _ = ()
  val op translated_aux_weights = TDB.find "translated_aux_weights"
  fun op shared_boundary_disjoint _ = ()
  val op shared_boundary_disjoint = TDB.find "shared_boundary_disjoint"
  fun op endpoint_flip_witness _ = ()
  val op endpoint_flip_witness = TDB.find "endpoint_flip_witness"
  fun op conservative_aux_weight _ = ()
  val op conservative_aux_weight = TDB.find "conservative_aux_weight"
  
val _ = if !Globals.print_thy_loads then TextIO.print "done\n" else ()
val _ = Theory.load_complete "InclusiveBracket"

end
