signature DispatchedFixtureTheory =
sig
  type thm = Thm.thm
  
  (*  Theorems  *)
    val fixture_10003_code : thm
    val fixture_10003_sign : thm
    val fixture_3_code : thm
    val fixture_3_sign : thm
end
