structure RepairAmplitudeTheory :> RepairAmplitudeTheory =
struct
  
  val _ = if !Globals.print_thy_loads
    then TextIO.print "Loading RepairAmplitudeTheory ... "
    else ()
  
  open Type Term Thm
  local open FallbackScoreTheory in end;
  
  structure TDB = struct
    val path =
      OS.Path.base (#(FILE)) ^ ".dat"
    val timestamp = HOLFileSys.modTime path
    val thydata = 
      TheoryReader.load_thydata {
        thyname = "RepairAmplitude",
        hash = "6be3ad277241da5c380ca4a9e999468c105441e2",
        path = path
      }
    fun find s = #1 (valOf (Symtab.lookup thydata s))
  end
  val () = Theory.record_metadata
    "RepairAmplitude" {timestamp=TDB.timestamp, path=TDB.path}
  
  fun op matches_score _ = ()
  val op matches_score = TDB.find "matches_score"
  fun op enclosed_amplitude _ = ()
  val op enclosed_amplitude = TDB.find "enclosed_amplitude"
  fun op ball_def _ = () val op ball_def = TDB.find "ball_def"
  
val _ = if !Globals.print_thy_loads then TextIO.print "done\n" else ()
val _ = Theory.load_complete "RepairAmplitude"

end
