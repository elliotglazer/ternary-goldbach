structure DispatchedFixtureTheory :> DispatchedFixtureTheory =
struct
  
  val _ = if !Globals.print_thy_loads
    then TextIO.print "Loading DispatchedFixtureTheory ... "
    else ()
  
  open Type Term Thm
  local open DispatchedScoreTheory in end;
  
  structure TDB = struct
    val path =
      OS.Path.base (#(FILE)) ^ ".dat"
    val timestamp = HOLFileSys.modTime path
    val thydata = 
      TheoryReader.load_thydata {
        thyname = "DispatchedFixture",
        hash = "427b49dab942b40a96f50f367bf30151e89aba64",
        path = path
      }
    fun find s = #1 (valOf (Symtab.lookup thydata s))
  end
  val () = Theory.record_metadata
    "DispatchedFixture" {timestamp=TDB.timestamp, path=TDB.path}
  
  fun op fixture_3_sign _ = ()
  val op fixture_3_sign = TDB.find "fixture_3_sign"
  fun op fixture_3_code _ = ()
  val op fixture_3_code = TDB.find "fixture_3_code"
  fun op fixture_10003_sign _ = ()
  val op fixture_10003_sign = TDB.find "fixture_10003_sign"
  fun op fixture_10003_code _ = ()
  val op fixture_10003_code = TDB.find "fixture_10003_code"
  
val _ = if !Globals.print_thy_loads then TextIO.print "done\n" else ()
val _ = Theory.load_complete "DispatchedFixture"

end
