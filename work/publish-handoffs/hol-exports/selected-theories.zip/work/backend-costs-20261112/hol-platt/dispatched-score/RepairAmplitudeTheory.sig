signature RepairAmplitudeTheory =
sig
  type thm = Thm.thm
  
  (*  Definitions  *)
    val ball_def : thm
  
  (*  Theorems  *)
    val enclosed_amplitude : thm
    val matches_score : thm
end
