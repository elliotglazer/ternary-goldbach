signature InclusiveBracketTheory =
sig
  type thm = Thm.thm
  
  (*  Theorems  *)
    val conservative_aux_weight : thm
    val endpoint_flip_witness : thm
    val shared_boundary_disjoint : thm
    val translated_aux_weights : thm
    val translated_sample_admissible : thm
end
