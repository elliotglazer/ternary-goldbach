signature DispatchedScoreTheory =
sig
  type thm = Thm.thm
  
  (*  Theorems  *)
    val dispatched_sign : thm
end
