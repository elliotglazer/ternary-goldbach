structure ArchiveLoaderTheory :> ArchiveLoaderTheory =
struct
  
  val _ = if !Globals.print_thy_loads
    then TextIO.print "Loading ArchiveLoaderTheory ... "
    else ()
  
  open Type Term Thm
  local open CountReceiptTheory in end;
  
  structure TDB = struct
    val path =
      OS.Path.base (#(FILE)) ^ ".dat"
    val timestamp = HOLFileSys.modTime path
    val thydata = 
      TheoryReader.load_thydata {
        thyname = "ArchiveLoader",
        hash = "8cc1c0f4e509bb8d955ba949a05b87de512f460b",
        path = path
      }
    fun find s = #1 (valOf (Symtab.lookup thydata s))
  end
  val () = Theory.record_metadata
    "ArchiveLoader" {timestamp=TDB.timestamp, path=TDB.path}
  
  
val _ = if !Globals.print_thy_loads then TextIO.print "done\n" else ()
val _ = Theory.load_complete "ArchiveLoader"

end
