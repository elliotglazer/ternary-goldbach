signature ArchiveLoaderTheory =
sig
  type thm = Thm.thm
end
