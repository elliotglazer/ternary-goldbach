signature FallbackScoreTheory =
sig
  type thm = Thm.thm
  
  (*  Theorems  *)
    val cast_abs : thm
    val margin_code : thm
    val pair_radii : thm
    val phase_radii : thm
    val product_radius : thm
    val projected_radius : thm
    val score_sign : thm
end
