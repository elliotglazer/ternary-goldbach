structure FallbackScoreTheory :> FallbackScoreTheory =
struct
  
  val _ = if !Globals.print_thy_loads
    then TextIO.print "Loading FallbackScoreTheory ... "
    else ()
  
  open Type Term Thm
  local open LargeTerminalTheory RealFieldContextTheory intrealTheory
  in end;
  
  structure TDB = struct
    val path =
      OS.Path.base (#(FILE)) ^ ".dat"
    val timestamp = HOLFileSys.modTime path
    val thydata = 
      TheoryReader.load_thydata {
        thyname = "FallbackScore",
        hash = "dcef1f1f185b340eaf6d663a619c0494e3b0157d",
        path = path
      }
    fun find s = #1 (valOf (Symtab.lookup thydata s))
  end
  val () = Theory.record_metadata
    "FallbackScore" {timestamp=TDB.timestamp, path=TDB.path}
  
  fun op score_sign _ = () val op score_sign = TDB.find "score_sign"
  fun op projected_radius _ = ()
  val op projected_radius = TDB.find "projected_radius"
  fun op product_radius _ = ()
  val op product_radius = TDB.find "product_radius"
  fun op phase_radii _ = () val op phase_radii = TDB.find "phase_radii"
  fun op pair_radii _ = () val op pair_radii = TDB.find "pair_radii"
  fun op margin_code _ = () val op margin_code = TDB.find "margin_code"
  fun op cast_abs _ = () val op cast_abs = TDB.find "cast_abs"
  
val _ = if !Globals.print_thy_loads then TextIO.print "done\n" else ()
val _ = Theory.load_complete "FallbackScore"

end
