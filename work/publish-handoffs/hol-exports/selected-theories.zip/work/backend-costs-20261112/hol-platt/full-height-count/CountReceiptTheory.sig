signature CountReceiptTheory =
sig
  type thm = Thm.thm
  
  (*  Definitions  *)
    val cv_pair_test_def : thm
    val pair_test_def : thm
    val runs_000_def : thm
    val runs_001_def : thm
    val runs_010_def : thm
    val runs_011_def : thm
    val runs_100_def : thm
    val runs_101_def : thm
    val runs_110_def : thm
    val runs_111_def : thm
  
  (*  Theorems  *)
    val cv_pair_test_thm : thm
    val pair0_full_count_test : thm
    val pair1_full_count_test : thm
    val runs_000_checked : thm
    val runs_001_checked : thm
    val runs_010_checked : thm
    val runs_011_checked : thm
    val runs_100_checked : thm
    val runs_101_checked : thm
    val runs_110_checked : thm
    val runs_111_checked : thm
end
