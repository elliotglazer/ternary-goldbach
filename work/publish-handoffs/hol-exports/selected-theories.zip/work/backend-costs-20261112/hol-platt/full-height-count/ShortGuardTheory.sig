signature ShortGuardTheory =
sig
  type thm = Thm.thm
  
  (*  Definitions  *)
    val aux25_11_def : thm
    val aux25_3_def : thm
    val aux25_6667_def : thm
    val aux25_9091_def : thm
    val cv_parity_test_def : thm
    val parity_test_def : thm
  
  (*  Theorems  *)
    val cv_parity_test_thm : thm
    val exact_pair_count : thm
    val parity_width25_even : thm
    val parity_width25_odd : thm
end
