signature GuardChoiceTheory =
sig
  type thm = Thm.thm
  
  (*  Theorems  *)
    val some_width_exact_count : thm
end
