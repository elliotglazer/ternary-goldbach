structure ShortGuardTheory :> ShortGuardTheory =
struct
  
  val _ = if !Globals.print_thy_loads
    then TextIO.print "Loading ShortGuardTheory ... "
    else ()
  
  open Type Term Thm
  local open CountReceiptTheory in end;
  
  structure TDB = struct
    val path =
      OS.Path.base (#(FILE)) ^ ".dat"
    val timestamp = HOLFileSys.modTime path
    val thydata = 
      TheoryReader.load_thydata {
        thyname = "ShortGuard",
        hash = "8cf0d6f57551a68a2b64378f0e2e45e12eb3330e",
        path = path
      }
    fun find s = #1 (valOf (Symtab.lookup thydata s))
  end
  val () = Theory.record_metadata
    "ShortGuard" {timestamp=TDB.timestamp, path=TDB.path}
  
  fun op parity_width25_odd _ = ()
  val op parity_width25_odd = TDB.find "parity_width25_odd"
  fun op parity_width25_even _ = ()
  val op parity_width25_even = TDB.find "parity_width25_even"
  fun op parity_test_def _ = ()
  val op parity_test_def = TDB.find "parity_test_def"
  fun op exact_pair_count _ = ()
  val op exact_pair_count = TDB.find "exact_pair_count"
  fun op cv_parity_test_thm _ = ()
  val op cv_parity_test_thm = TDB.find "cv_parity_test_thm"
  fun op cv_parity_test_def _ = ()
  val op cv_parity_test_def = TDB.find "cv_parity_test_def"
  fun op aux25_9091_def _ = ()
  val op aux25_9091_def = TDB.find "aux25_9091_def"
  fun op aux25_6667_def _ = ()
  val op aux25_6667_def = TDB.find "aux25_6667_def"
  fun op aux25_3_def _ = () val op aux25_3_def = TDB.find "aux25_3_def"
  fun op aux25_11_def _ = () val op aux25_11_def = TDB.find "aux25_11_def"
  
val _ = if !Globals.print_thy_loads then TextIO.print "done\n" else ()
val _ = Theory.load_complete "ShortGuard"

end
