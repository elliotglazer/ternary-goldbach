structure OffLinePairTheory :> OffLinePairTheory =
struct
  
  val _ = if !Globals.print_thy_loads
    then TextIO.print "Loading OffLinePairTheory ... "
    else ()
  
  open Type Term Thm
  local open holTheory in end;
  
  structure TDB = struct
    val path =
      OS.Path.base (#(FILE)) ^ ".dat"
    val timestamp = HOLFileSys.modTime path
    val thydata = 
      TheoryReader.load_thydata {
        thyname = "OffLinePair",
        hash = "b2185e06910a96580527eeab42ab6c7f9e885193",
        path = path
      }
    fun find s = #1 (valOf (Symtab.lookup thydata s))
  end
  val () = Theory.record_metadata
    "OffLinePair" {timestamp=TDB.timestamp, path=TDB.path}
  
  fun op reflected_multiplicity_sum _ = ()
  val op reflected_multiplicity_sum = TDB.find "reflected_multiplicity_sum"
  
val _ = if !Globals.print_thy_loads then TextIO.print "done\n" else ()
val _ = Theory.load_complete "OffLinePair"

end
