signature Rumely167Theory =
sig
  type thm = Thm.thm
  
  (*  Definitions  *)
    val strict167_def : thm
  
  (*  Theorems  *)
    val fixed_even_167 : thm
    val fixed_odd_167 : thm
end
