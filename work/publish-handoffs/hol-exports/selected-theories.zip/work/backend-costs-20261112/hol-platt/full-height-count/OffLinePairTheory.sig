signature OffLinePairTheory =
sig
  type thm = Thm.thm
  
  (*  Theorems  *)
    val reflected_multiplicity_sum : thm
end
