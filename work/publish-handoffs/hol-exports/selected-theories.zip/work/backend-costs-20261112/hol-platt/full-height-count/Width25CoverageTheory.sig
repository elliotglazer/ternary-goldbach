signature Width25CoverageTheory =
sig
  type thm = Thm.thm
  
  (*  Theorems  *)
    val exact_count_from_coverage : thm
end
