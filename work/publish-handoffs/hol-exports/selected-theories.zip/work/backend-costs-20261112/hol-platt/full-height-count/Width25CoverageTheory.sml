structure Width25CoverageTheory :> Width25CoverageTheory =
struct
  
  val _ = if !Globals.print_thy_loads
    then TextIO.print "Loading Width25CoverageTheory ... "
    else ()
  
  open Type Term Thm
  local open OffLinePairTheory ShortGuardTheory in end;
  
  structure TDB = struct
    val path =
      OS.Path.base (#(FILE)) ^ ".dat"
    val timestamp = HOLFileSys.modTime path
    val thydata = 
      TheoryReader.load_thydata {
        thyname = "Width25Coverage",
        hash = "cd75b46e8da4a5e9d24f13f529a099d0246b6d04",
        path = path
      }
    fun find s = #1 (valOf (Symtab.lookup thydata s))
  end
  val () = Theory.record_metadata
    "Width25Coverage" {timestamp=TDB.timestamp, path=TDB.path}
  
  fun op exact_count_from_coverage _ = ()
  val op exact_count_from_coverage = TDB.find "exact_count_from_coverage"
  
val _ = if !Globals.print_thy_loads then TextIO.print "done\n" else ()
val _ = Theory.load_complete "Width25Coverage"

end
