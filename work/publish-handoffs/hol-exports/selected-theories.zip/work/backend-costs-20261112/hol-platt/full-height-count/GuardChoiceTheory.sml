structure GuardChoiceTheory :> GuardChoiceTheory =
struct
  
  val _ = if !Globals.print_thy_loads
    then TextIO.print "Loading GuardChoiceTheory ... "
    else ()
  
  open Type Term Thm
  local open FullCountTheory in end;
  
  structure TDB = struct
    val path =
      OS.Path.base (#(FILE)) ^ ".dat"
    val timestamp = HOLFileSys.modTime path
    val thydata = 
      TheoryReader.load_thydata {
        thyname = "GuardChoice",
        hash = "ba60b0529f19f60929c03898c392d2bb6c4dbeea",
        path = path
      }
    fun find s = #1 (valOf (Symtab.lookup thydata s))
  end
  val () = Theory.record_metadata
    "GuardChoice" {timestamp=TDB.timestamp, path=TDB.path}
  
  fun op some_width_exact_count _ = ()
  val op some_width_exact_count = TDB.find "some_width_exact_count"
  
val _ = if !Globals.print_thy_loads then TextIO.print "done\n" else ()
val _ = Theory.load_complete "GuardChoice"

end
