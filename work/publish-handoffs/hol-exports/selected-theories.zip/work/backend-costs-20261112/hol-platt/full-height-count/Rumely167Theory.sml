structure Rumely167Theory :> Rumely167Theory =
struct
  
  val _ = if !Globals.print_thy_loads
    then TextIO.print "Loading Rumely167Theory ... "
    else ()
  
  open Type Term Thm
  local open holTheory in end;
  
  structure TDB = struct
    val path =
      OS.Path.base (#(FILE)) ^ ".dat"
    val timestamp = HOLFileSys.modTime path
    val thydata = 
      TheoryReader.load_thydata {
        thyname = "Rumely167",
        hash = "2e93480cb23aa6e92c925a2804ad95703e833ad8",
        path = path
      }
    fun find s = #1 (valOf (Symtab.lookup thydata s))
  end
  val () = Theory.record_metadata
    "Rumely167" {timestamp=TDB.timestamp, path=TDB.path}
  
  fun op strict167_def _ = ()
  val op strict167_def = TDB.find "strict167_def"
  fun op fixed_odd_167 _ = ()
  val op fixed_odd_167 = TDB.find "fixed_odd_167"
  fun op fixed_even_167 _ = ()
  val op fixed_even_167 = TDB.find "fixed_even_167"
  
val _ = if !Globals.print_thy_loads then TextIO.print "done\n" else ()
val _ = Theory.load_complete "Rumely167"

end
