structure CountReceiptTheory :> CountReceiptTheory =
struct
  
  val _ = if !Globals.print_thy_loads
    then TextIO.print "Loading CountReceiptTheory ... "
    else ()
  
  open Type Term Thm
  local open FullCountTheory in end;
  
  structure TDB = struct
    val path =
      OS.Path.base (#(FILE)) ^ ".dat"
    val timestamp = HOLFileSys.modTime path
    val thydata = 
      TheoryReader.load_thydata {
        thyname = "CountReceipt",
        hash = "dc53a142ad9548cbd870e28bcea1b1e0b7904e81",
        path = path
      }
    fun find s = #1 (valOf (Symtab.lookup thydata s))
  end
  val () = Theory.record_metadata
    "CountReceipt" {timestamp=TDB.timestamp, path=TDB.path}
  
  fun op runs_111_def _ = () val op runs_111_def = TDB.find "runs_111_def"
  fun op runs_111_checked _ = ()
  val op runs_111_checked = TDB.find "runs_111_checked"
  fun op runs_110_def _ = () val op runs_110_def = TDB.find "runs_110_def"
  fun op runs_110_checked _ = ()
  val op runs_110_checked = TDB.find "runs_110_checked"
  fun op runs_101_def _ = () val op runs_101_def = TDB.find "runs_101_def"
  fun op runs_101_checked _ = ()
  val op runs_101_checked = TDB.find "runs_101_checked"
  fun op runs_100_def _ = () val op runs_100_def = TDB.find "runs_100_def"
  fun op runs_100_checked _ = ()
  val op runs_100_checked = TDB.find "runs_100_checked"
  fun op runs_011_def _ = () val op runs_011_def = TDB.find "runs_011_def"
  fun op runs_011_checked _ = ()
  val op runs_011_checked = TDB.find "runs_011_checked"
  fun op runs_010_def _ = () val op runs_010_def = TDB.find "runs_010_def"
  fun op runs_010_checked _ = ()
  val op runs_010_checked = TDB.find "runs_010_checked"
  fun op runs_001_def _ = () val op runs_001_def = TDB.find "runs_001_def"
  fun op runs_001_checked _ = ()
  val op runs_001_checked = TDB.find "runs_001_checked"
  fun op runs_000_def _ = () val op runs_000_def = TDB.find "runs_000_def"
  fun op runs_000_checked _ = ()
  val op runs_000_checked = TDB.find "runs_000_checked"
  fun op pair_test_def _ = ()
  val op pair_test_def = TDB.find "pair_test_def"
  fun op pair1_full_count_test _ = ()
  val op pair1_full_count_test = TDB.find "pair1_full_count_test"
  fun op pair0_full_count_test _ = ()
  val op pair0_full_count_test = TDB.find "pair0_full_count_test"
  fun op cv_pair_test_thm _ = ()
  val op cv_pair_test_thm = TDB.find "cv_pair_test_thm"
  fun op cv_pair_test_def _ = ()
  val op cv_pair_test_def = TDB.find "cv_pair_test_def"
  
val _ = if !Globals.print_thy_loads then TextIO.print "done\n" else ()
val _ = Theory.load_complete "CountReceipt"

end
