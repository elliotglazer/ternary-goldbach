structure PeriodicKernelTheory :> PeriodicKernelTheory =
struct
  
  val _ = if !Globals.print_thy_loads
    then TextIO.print "Loading PeriodicKernelTheory ... "
    else ()
  
  open Type Term Thm
  local open BernoulliPhaseTheory PhaseMassTheory complexTheory
  intrealTheory
  in end;
  
  structure TDB = struct
    val path =
      OS.Path.base (#(FILE)) ^ ".dat"
    val timestamp = HOLFileSys.modTime path
    val thydata = 
      TheoryReader.load_thydata {
        thyname = "PeriodicKernel",
        hash = "f7c45e724dafac76e7876a7578c8602039d44dd9",
        path = path
      }
    fun find s = #1 (valOf (Symtab.lookup thydata s))
  end
  val () = Theory.record_metadata
    "PeriodicKernel" {timestamp=TDB.timestamp, path=TDB.path}
  
  fun op translated_fourth_power _ = ()
  val op translated_fourth_power = TDB.find "translated_fourth_power"
  fun op periodic_kernel_majorant _ = ()
  val op periodic_kernel_majorant = TDB.find "periodic_kernel_majorant"
  fun op periodic_kernel_def _ = ()
  val op periodic_kernel_def = TDB.find "periodic_kernel_def"
  fun op periodic_B4_abs _ = ()
  val op periodic_B4_abs = TDB.find "periodic_B4_abs"
  fun op finite_modulus_upper _ = ()
  val op finite_modulus_upper = TDB.find "finite_modulus_upper"
  fun op finite_channel_upper _ = ()
  val op finite_channel_upper = TDB.find "finite_channel_upper"
  
val _ = if !Globals.print_thy_loads then TextIO.print "done\n" else ()
val _ = Theory.load_complete "PeriodicKernel"

end
