structure ComplexRemainderTheory :> ComplexRemainderTheory =
struct
  
  val _ = if !Globals.print_thy_loads
    then TextIO.print "Loading ComplexRemainderTheory ... "
    else ()
  
  open Type Term Thm
  local open PeriodicMassTheory in end;
  
  structure TDB = struct
    val path =
      OS.Path.base (#(FILE)) ^ ".dat"
    val timestamp = HOLFileSys.modTime path
    val thydata = 
      TheoryReader.load_thydata {
        thyname = "ComplexRemainder",
        hash = "a15d4e3151532442c8f62b218687f3c4bd29bab2",
        path = path
      }
    fun find s = #1 (valOf (Symtab.lookup thydata s))
  end
  val () = Theory.record_metadata
    "ComplexRemainder" {timestamp=TDB.timestamp, path=TDB.path}
  
  fun op cr_poly_components _ = ()
  val op cr_poly_components = TDB.find "cr_poly_components"
  fun op cr_norm_integral _ = ()
  val op cr_norm_integral = TDB.find "cr_norm_integral"
  fun op cr_integral_dot _ = ()
  val op cr_integral_dot = TDB.find "cr_integral_dot"
  fun op cr_int_def _ = () val op cr_int_def = TDB.find "cr_int_def"
  fun op cr_finite_kernel_norm _ = ()
  val op cr_finite_kernel_norm = TDB.find "cr_finite_kernel_norm"
  fun op cr_dot_def _ = () val op cr_dot_def = TDB.find "cr_dot_def"
  fun op cr_dot_bound _ = () val op cr_dot_bound = TDB.find "cr_dot_bound"
  fun op cr_component_integrals _ = ()
  val op cr_component_integrals = TDB.find "cr_component_integrals"
  fun op cr_component_cont _ = ()
  val op cr_component_cont = TDB.find "cr_component_cont"
  
val _ = if !Globals.print_thy_loads then TextIO.print "done\n" else ()
val _ = Theory.load_complete "ComplexRemainder"

end
