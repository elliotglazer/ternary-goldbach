signature PeriodicKernelTheory =
sig
  type thm = Thm.thm
  
  (*  Definitions  *)
    val periodic_kernel_def : thm
  
  (*  Theorems  *)
    val finite_channel_upper : thm
    val finite_modulus_upper : thm
    val periodic_B4_abs : thm
    val periodic_kernel_majorant : thm
    val translated_fourth_power : thm
end
