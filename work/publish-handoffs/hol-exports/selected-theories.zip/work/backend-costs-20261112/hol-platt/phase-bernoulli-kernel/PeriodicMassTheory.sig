signature PeriodicMassTheory =
sig
  type thm = Thm.thm
  
  (*  Definitions  *)
    val periodic_cutoff_def : thm
  
  (*  Theorems  *)
    val modulus_contl : thm
    val modulus_finite : thm
    val modulus_scalar : thm
    val periodic_B4_chart : thm
    val periodic_B4_continuous : thm
    val periodic_cutoff_bound : thm
    val periodic_cutoff_mono : thm
    val periodic_modulus_improper : thm
    val phase_B4_reflect : thm
end
