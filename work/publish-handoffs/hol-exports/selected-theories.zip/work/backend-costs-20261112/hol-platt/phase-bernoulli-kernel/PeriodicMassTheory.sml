structure PeriodicMassTheory :> PeriodicMassTheory =
struct
  
  val _ = if !Globals.print_thy_loads
    then TextIO.print "Loading PeriodicMassTheory ... "
    else ()
  
  open Type Term Thm
  local open PeriodicKernelTheory in end;
  
  structure TDB = struct
    val path =
      OS.Path.base (#(FILE)) ^ ".dat"
    val timestamp = HOLFileSys.modTime path
    val thydata = 
      TheoryReader.load_thydata {
        thyname = "PeriodicMass",
        hash = "c32fa5d72940c210ec0a7d201a12ddaaea41b39a",
        path = path
      }
    fun find s = #1 (valOf (Symtab.lookup thydata s))
  end
  val () = Theory.record_metadata
    "PeriodicMass" {timestamp=TDB.timestamp, path=TDB.path}
  
  fun op phase_B4_reflect _ = ()
  val op phase_B4_reflect = TDB.find "phase_B4_reflect"
  fun op periodic_modulus_improper _ = ()
  val op periodic_modulus_improper = TDB.find "periodic_modulus_improper"
  fun op periodic_cutoff_mono _ = ()
  val op periodic_cutoff_mono = TDB.find "periodic_cutoff_mono"
  fun op periodic_cutoff_def _ = ()
  val op periodic_cutoff_def = TDB.find "periodic_cutoff_def"
  fun op periodic_cutoff_bound _ = ()
  val op periodic_cutoff_bound = TDB.find "periodic_cutoff_bound"
  fun op periodic_B4_continuous _ = ()
  val op periodic_B4_continuous = TDB.find "periodic_B4_continuous"
  fun op periodic_B4_chart _ = ()
  val op periodic_B4_chart = TDB.find "periodic_B4_chart"
  fun op modulus_scalar _ = ()
  val op modulus_scalar = TDB.find "modulus_scalar"
  fun op modulus_finite _ = ()
  val op modulus_finite = TDB.find "modulus_finite"
  fun op modulus_contl _ = ()
  val op modulus_contl = TDB.find "modulus_contl"
  
val _ = if !Globals.print_thy_loads then TextIO.print "done\n" else ()
val _ = Theory.load_complete "PeriodicMass"

end
