signature ComplexRemainderTheory =
sig
  type thm = Thm.thm
  
  (*  Definitions  *)
    val cr_dot_def : thm
    val cr_int_def : thm
  
  (*  Theorems  *)
    val cr_component_cont : thm
    val cr_component_integrals : thm
    val cr_dot_bound : thm
    val cr_finite_kernel_norm : thm
    val cr_integral_dot : thm
    val cr_norm_integral : thm
    val cr_poly_components : thm
end
