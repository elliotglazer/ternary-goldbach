structure TuringScheduleTheory :> TuringScheduleTheory =
struct
  
  val _ = if !Globals.print_thy_loads
    then TextIO.print "Loading TuringScheduleTheory ... "
    else ()
  
  open Type Term Thm
  local open SourceLogTailTheory in end;
  
  structure TDB = struct
    val path =
      OS.Path.base (#(FILE)) ^ ".dat"
    val timestamp = HOLFileSys.modTime path
    val thydata = 
      TheoryReader.load_thydata {
        thyname = "TuringSchedule",
        hash = "98ecd62e12bcc230c053cb2c5c9dac13af8d316a",
        path = path
      }
    fun find s = #1 (valOf (Symtab.lookup thydata s))
  end
  val () = Theory.record_metadata
    "TuringSchedule" {timestamp=TDB.timestamp, path=TDB.path}
  
  fun op schedule_log _ = () val op schedule_log = TDB.find "schedule_log"
  fun op schedule_allowances _ = ()
  val op schedule_allowances = TDB.find "schedule_allowances"
  fun op log_two_cheap _ = ()
  val op log_two_cheap = TDB.find "log_two_cheap"
  fun op conductor_height_domain _ = ()
  val op conductor_height_domain = TDB.find "conductor_height_domain"
  
val _ = if !Globals.print_thy_loads then TextIO.print "done\n" else ()
val _ = Theory.load_complete "TuringSchedule"

end
