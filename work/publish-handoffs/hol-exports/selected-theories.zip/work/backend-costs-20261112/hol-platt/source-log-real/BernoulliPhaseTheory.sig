signature BernoulliPhaseTheory =
sig
  type thm = Thm.thm
  
  (*  Definitions  *)
    val phase_B4_def : thm
  
  (*  Theorems  *)
    val phase_B4_absolute : thm
    val phase_B4_bounds : thm
    val phase_B4_sharp : thm
    val scaled_stirling_remainder : thm
end
