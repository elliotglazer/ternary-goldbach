signature TuringScheduleTheory =
sig
  type thm = Thm.thm
  
  (*  Theorems  *)
    val conductor_height_domain : thm
    val log_two_cheap : thm
    val schedule_allowances : thm
    val schedule_log : thm
end
