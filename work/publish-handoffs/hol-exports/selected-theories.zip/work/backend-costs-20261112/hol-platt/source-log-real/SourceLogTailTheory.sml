structure SourceLogTailTheory :> SourceLogTailTheory =
struct
  
  val _ = if !Globals.print_thy_loads
    then TextIO.print "Loading SourceLogTailTheory ... "
    else ()
  
  open Type Term Thm
  local open transcTheory in end;
  
  structure TDB = struct
    val path =
      OS.Path.base (#(FILE)) ^ ".dat"
    val timestamp = HOLFileSys.modTime path
    val thydata = 
      TheoryReader.load_thydata {
        thyname = "SourceLogTail",
        hash = "55d421a6b79d15be19cabdca787efa3e8fdfb9f6",
        path = path
      }
    fun find s = #1 (valOf (Symtab.lookup thydata s))
  end
  val () = Theory.record_metadata
    "SourceLogTail" {timestamp=TDB.timestamp, path=TDB.path}
  
  fun op sl_remainder_zero _ = ()
  val op sl_remainder_zero = TDB.find "sl_remainder_zero"
  fun op sl_remainder_suc _ = ()
  val op sl_remainder_suc = TDB.find "sl_remainder_suc"
  fun op sl_remainder_mvt _ = ()
  val op sl_remainder_mvt = TDB.find "sl_remainder_mvt"
  fun op sl_remainder_diff _ = ()
  val op sl_remainder_diff = TDB.find "sl_remainder_diff"
  fun op sl_remainder_derivative_bound _ = ()
  val op sl_remainder_derivative_bound = TDB.find
    "sl_remainder_derivative_bound"
  fun op sl_remainder_def _ = ()
  val op sl_remainder_def = TDB.find "sl_remainder_def"
  fun op sl_remainder_bound _ = ()
  val op sl_remainder_bound = TDB.find "sl_remainder_bound"
  fun op sl_odd_term_diff _ = ()
  val op sl_odd_term_diff = TDB.find "sl_odd_term_diff"
  fun op sl_log_two45_error _ = ()
  val op sl_log_two45_error = TDB.find "sl_log_two45_error"
  fun op sl_log_partial_zero _ = ()
  val op sl_log_partial_zero = TDB.find "sl_log_partial_zero"
  fun op sl_log_partial_error _ = ()
  val op sl_log_partial_error = TDB.find "sl_log_partial_error"
  fun op sl_log_partial_def _ = ()
  val op sl_log_partial_def = TDB.find "sl_log_partial_def"
  fun op sl_log_partial_compute _ = ()
  val op sl_log_partial_compute = TDB.find "sl_log_partial_compute"
  fun op sl_log_partial45_error _ = ()
  val op sl_log_partial45_error = TDB.find "sl_log_partial45_error"
  fun op sl_log_difference_diff _ = ()
  val op sl_log_difference_diff = TDB.find "sl_log_difference_diff"
  
val _ = if !Globals.print_thy_loads then TextIO.print "done\n" else ()
val _ = Theory.load_complete "SourceLogTail"

end
