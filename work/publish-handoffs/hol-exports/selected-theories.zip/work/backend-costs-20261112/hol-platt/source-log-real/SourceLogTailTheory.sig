signature SourceLogTailTheory =
sig
  type thm = Thm.thm
  
  (*  Definitions  *)
    val sl_log_partial_def : thm
    val sl_remainder_def : thm
  
  (*  Theorems  *)
    val sl_log_difference_diff : thm
    val sl_log_partial45_error : thm
    val sl_log_partial_compute : thm
    val sl_log_partial_error : thm
    val sl_log_partial_zero : thm
    val sl_log_two45_error : thm
    val sl_odd_term_diff : thm
    val sl_remainder_bound : thm
    val sl_remainder_derivative_bound : thm
    val sl_remainder_diff : thm
    val sl_remainder_mvt : thm
    val sl_remainder_suc : thm
    val sl_remainder_zero : thm
end
