structure BernoulliPhaseTheory :> BernoulliPhaseTheory =
struct
  
  val _ = if !Globals.print_thy_loads
    then TextIO.print "Loading BernoulliPhaseTheory ... "
    else ()
  
  open Type Term Thm
  local open RealFieldContextTheory in end;
  
  structure TDB = struct
    val path =
      OS.Path.base (#(FILE)) ^ ".dat"
    val timestamp = HOLFileSys.modTime path
    val thydata = 
      TheoryReader.load_thydata {
        thyname = "BernoulliPhase",
        hash = "b441c336a6293b577ce99b2176a0947e3556e825",
        path = path
      }
    fun find s = #1 (valOf (Symtab.lookup thydata s))
  end
  val () = Theory.record_metadata
    "BernoulliPhase" {timestamp=TDB.timestamp, path=TDB.path}
  
  fun op scaled_stirling_remainder _ = ()
  val op scaled_stirling_remainder = TDB.find "scaled_stirling_remainder"
  fun op phase_B4_sharp _ = ()
  val op phase_B4_sharp = TDB.find "phase_B4_sharp"
  fun op phase_B4_def _ = () val op phase_B4_def = TDB.find "phase_B4_def"
  fun op phase_B4_bounds _ = ()
  val op phase_B4_bounds = TDB.find "phase_B4_bounds"
  fun op phase_B4_absolute _ = ()
  val op phase_B4_absolute = TDB.find "phase_B4_absolute"
  
val _ = if !Globals.print_thy_loads then TextIO.print "done\n" else ()
val _ = Theory.load_complete "BernoulliPhase"

end
