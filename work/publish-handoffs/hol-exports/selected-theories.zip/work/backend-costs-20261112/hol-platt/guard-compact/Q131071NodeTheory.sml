structure Q131071NodeTheory :> Q131071NodeTheory =
struct
  
  val _ = if !Globals.print_thy_loads
    then TextIO.print "Loading Q131071NodeTheory ... "
    else ()
  
  open Type Term Thm
  local open SpectralNodeTheory in end;
  
  structure TDB = struct
    val path =
      OS.Path.base (#(FILE)) ^ ".dat"
    val timestamp = HOLFileSys.modTime path
    val thydata = 
      TheoryReader.load_thydata {
        thyname = "Q131071Node",
        hash = "bb20c02e278f9a31647a8df12b81dce509f2f0eb",
        path = path
      }
    fun find s = #1 (valOf (Symtab.lookup thydata s))
  end
  val () = Theory.record_metadata
    "Q131071Node" {timestamp=TDB.timestamp, path=TDB.path}
  
  fun op q131071_phase_gain _ = ()
  val op q131071_phase_gain = TDB.find "q131071_phase_gain"
  fun op q131071_full_gain_one _ = ()
  val op q131071_full_gain_one = TDB.find "q131071_full_gain_one"
  fun op q131071_compact_node _ = ()
  val op q131071_compact_node = TDB.find "q131071_compact_node"
  fun op midpoint_11389_2_positive _ = ()
  val op midpoint_11389_2_positive = TDB.find "midpoint_11389_2_positive"
  
val _ = if !Globals.print_thy_loads then TextIO.print "done\n" else ()
val _ = Theory.load_complete "Q131071Node"

end
