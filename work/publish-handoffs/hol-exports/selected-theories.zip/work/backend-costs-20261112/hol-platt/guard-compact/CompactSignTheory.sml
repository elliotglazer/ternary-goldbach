structure CompactSignTheory :> CompactSignTheory =
struct
  
  val _ = if !Globals.print_thy_loads
    then TextIO.print "Loading CompactSignTheory ... "
    else ()
  
  open Type Term Thm
  local open FallbackScoreTheory in end;
  
  structure TDB = struct
    val path =
      OS.Path.base (#(FILE)) ^ ".dat"
    val timestamp = HOLFileSys.modTime path
    val thydata = 
      TheoryReader.load_thydata {
        thyname = "CompactSign",
        hash = "5f05972c76c83b8ba6ab4129f7650d8231e0e648",
        path = path
      }
    fun find s = #1 (valOf (Symtab.lookup thydata s))
  end
  val () = Theory.record_metadata
    "CompactSign" {timestamp=TDB.timestamp, path=TDB.path}
  
  fun op vnorm_ind _ = () val op vnorm_ind = TDB.find "vnorm_ind"
  fun op vnorm_def_primitive _ = ()
  val op vnorm_def_primitive = TDB.find "vnorm_def_primitive"
  fun op vnorm_def _ = () val op vnorm_def = TDB.find "vnorm_def"
  fun op stencil_sign _ = () val op stencil_sign = TDB.find "stencil_sign"
  fun op rounding_sum _ = () val op rounding_sum = TDB.find "rounding_sum"
  fun op rounding_one _ = () val op rounding_one = TDB.find "rounding_one"
  fun op margin_def _ = () val op margin_def = TDB.find "margin_def"
  fun op knorm_ind _ = () val op knorm_ind = TDB.find "knorm_ind"
  fun op knorm_def_primitive _ = ()
  val op knorm_def_primitive = TDB.find "knorm_def_primitive"
  fun op knorm_def _ = () val op knorm_def = TDB.find "knorm_def"
  fun op idot_ind _ = () val op idot_ind = TDB.find "idot_ind"
  fun op idot_def_primitive _ = ()
  val op idot_def_primitive = TDB.find "idot_def_primitive"
  fun op idot_def _ = () val op idot_def = TDB.find "idot_def"
  fun op ideal_ind _ = () val op ideal_ind = TDB.find "ideal_ind"
  fun op ideal_def_primitive _ = ()
  val op ideal_def_primitive = TDB.find "ideal_def_primitive"
  fun op ideal_def _ = () val op ideal_def = TDB.find "ideal_def"
  fun op cast_abs _ = () val op cast_abs = TDB.find "cast_abs"
  fun op admitted_ind _ = () val op admitted_ind = TDB.find "admitted_ind"
  fun op admitted_def _ = () val op admitted_def = TDB.find "admitted_def"
  
val _ = if !Globals.print_thy_loads then TextIO.print "done\n" else ()
val _ = Theory.load_complete "CompactSign"

end
