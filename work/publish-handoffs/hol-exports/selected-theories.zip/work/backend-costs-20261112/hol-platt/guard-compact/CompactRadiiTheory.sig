signature CompactRadiiTheory =
sig
  type thm = Thm.thm
  
  (*  Definitions  *)
    val nodes_def_primitive : thm
    val rmargin_def : thm
    val values_def_primitive : thm
    val weighted_def_primitive : thm
  
  (*  Theorems  *)
    val admitted_r_def : thm
    val admitted_r_ind : thm
    val nodes_def : thm
    val nodes_ind : thm
    val rounding_r_one : thm
    val rounding_r_sum : thm
    val stencil_r_sign : thm
    val target_error : thm
    val values_def : thm
    val values_ind : thm
    val weighted_def : thm
    val weighted_ind : thm
end
