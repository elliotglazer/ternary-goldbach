structure SpectralNodeTheory :> SpectralNodeTheory =
struct
  
  val _ = if !Globals.print_thy_loads
    then TextIO.print "Loading SpectralNodeTheory ... "
    else ()
  
  open Type Term Thm
  local open CompactRadiiTheory in end;
  
  structure TDB = struct
    val path =
      OS.Path.base (#(FILE)) ^ ".dat"
    val timestamp = HOLFileSys.modTime path
    val thydata = 
      TheoryReader.load_thydata {
        thyname = "SpectralNode",
        hash = "7847411e9fa748df9624bf572904393cdbf7938b",
        path = path
      }
    fun find s = #1 (valOf (Symtab.lookup thydata s))
  end
  val () = Theory.record_metadata
    "SpectralNode" {timestamp=TDB.timestamp, path=TDB.path}
  
  fun op unit_transfer _ = ()
  val op unit_transfer = TDB.find "unit_transfer"
  fun op spectral_raw _ = () val op spectral_raw = TDB.find "spectral_raw"
  fun op spectral_node _ = ()
  val op spectral_node = TDB.find "spectral_node"
  fun op spectral_admit_cons _ = ()
  val op spectral_admit_cons = TDB.find "spectral_admit_cons"
  fun op scaled_table_cons _ = ()
  val op scaled_table_cons = TDB.find "scaled_table_cons"
  fun op raw_radius_def _ = ()
  val op raw_radius_def = TDB.find "raw_radius_def"
  fun op raw_center_def _ = ()
  val op raw_center_def = TDB.find "raw_center_def"
  fun op node_radius_def _ = ()
  val op node_radius_def = TDB.find "node_radius_def"
  fun op node_center_def _ = ()
  val op node_center_def = TDB.find "node_center_def"
  fun op nearest_tie _ = () val op nearest_tie = TDB.find "nearest_tie"
  fun op nearest_error _ = ()
  val op nearest_error = TDB.find "nearest_error"
  fun op nearest_def _ = () val op nearest_def = TDB.find "nearest_def"
  fun op midpoint_error _ = ()
  val op midpoint_error = TDB.find "midpoint_error"
  fun op midpoint_def _ = () val op midpoint_def = TDB.find "midpoint_def"
  fun op halfwidth_def _ = ()
  val op halfwidth_def = TDB.find "halfwidth_def"
  
val _ = if !Globals.print_thy_loads then TextIO.print "done\n" else ()
val _ = Theory.load_complete "SpectralNode"

end
