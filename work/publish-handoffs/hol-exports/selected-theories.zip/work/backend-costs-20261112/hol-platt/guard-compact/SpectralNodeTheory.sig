signature SpectralNodeTheory =
sig
  type thm = Thm.thm
  
  (*  Definitions  *)
    val halfwidth_def : thm
    val midpoint_def : thm
    val nearest_def : thm
    val node_center_def : thm
    val node_radius_def : thm
    val raw_center_def : thm
    val raw_radius_def : thm
  
  (*  Theorems  *)
    val midpoint_error : thm
    val nearest_error : thm
    val nearest_tie : thm
    val scaled_table_cons : thm
    val spectral_admit_cons : thm
    val spectral_node : thm
    val spectral_raw : thm
    val unit_transfer : thm
end
