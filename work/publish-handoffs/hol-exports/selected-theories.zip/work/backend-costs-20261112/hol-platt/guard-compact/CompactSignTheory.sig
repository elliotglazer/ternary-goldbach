signature CompactSignTheory =
sig
  type thm = Thm.thm
  
  (*  Definitions  *)
    val ideal_def_primitive : thm
    val idot_def_primitive : thm
    val knorm_def_primitive : thm
    val margin_def : thm
    val vnorm_def_primitive : thm
  
  (*  Theorems  *)
    val admitted_def : thm
    val admitted_ind : thm
    val cast_abs : thm
    val ideal_def : thm
    val ideal_ind : thm
    val idot_def : thm
    val idot_ind : thm
    val knorm_def : thm
    val knorm_ind : thm
    val rounding_one : thm
    val rounding_sum : thm
    val stencil_sign : thm
    val vnorm_def : thm
    val vnorm_ind : thm
end
