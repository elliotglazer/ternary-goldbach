structure CompactRadiiTheory :> CompactRadiiTheory =
struct
  
  val _ = if !Globals.print_thy_loads
    then TextIO.print "Loading CompactRadiiTheory ... "
    else ()
  
  open Type Term Thm
  local open CompactSignTheory in end;
  
  structure TDB = struct
    val path =
      OS.Path.base (#(FILE)) ^ ".dat"
    val timestamp = HOLFileSys.modTime path
    val thydata = 
      TheoryReader.load_thydata {
        thyname = "CompactRadii",
        hash = "c151d64401e15aa6c3b03238f91558b6d51853b7",
        path = path
      }
    fun find s = #1 (valOf (Symtab.lookup thydata s))
  end
  val () = Theory.record_metadata
    "CompactRadii" {timestamp=TDB.timestamp, path=TDB.path}
  
  fun op weighted_ind _ = () val op weighted_ind = TDB.find "weighted_ind"
  fun op weighted_def_primitive _ = ()
  val op weighted_def_primitive = TDB.find "weighted_def_primitive"
  fun op weighted_def _ = () val op weighted_def = TDB.find "weighted_def"
  fun op values_ind _ = () val op values_ind = TDB.find "values_ind"
  fun op values_def_primitive _ = ()
  val op values_def_primitive = TDB.find "values_def_primitive"
  fun op values_def _ = () val op values_def = TDB.find "values_def"
  fun op target_error _ = () val op target_error = TDB.find "target_error"
  fun op stencil_r_sign _ = ()
  val op stencil_r_sign = TDB.find "stencil_r_sign"
  fun op rounding_r_sum _ = ()
  val op rounding_r_sum = TDB.find "rounding_r_sum"
  fun op rounding_r_one _ = ()
  val op rounding_r_one = TDB.find "rounding_r_one"
  fun op rmargin_def _ = () val op rmargin_def = TDB.find "rmargin_def"
  fun op nodes_ind _ = () val op nodes_ind = TDB.find "nodes_ind"
  fun op nodes_def_primitive _ = ()
  val op nodes_def_primitive = TDB.find "nodes_def_primitive"
  fun op nodes_def _ = () val op nodes_def = TDB.find "nodes_def"
  fun op admitted_r_ind _ = ()
  val op admitted_r_ind = TDB.find "admitted_r_ind"
  fun op admitted_r_def _ = ()
  val op admitted_r_def = TDB.find "admitted_r_def"
  
val _ = if !Globals.print_thy_loads then TextIO.print "done\n" else ()
val _ = Theory.load_complete "CompactRadii"

end
