signature Q131071NodeTheory =
sig
  type thm = Thm.thm
  
  (*  Theorems  *)
    val midpoint_11389_2_positive : thm
    val q131071_compact_node : thm
    val q131071_full_gain_one : thm
    val q131071_phase_gain : thm
end
